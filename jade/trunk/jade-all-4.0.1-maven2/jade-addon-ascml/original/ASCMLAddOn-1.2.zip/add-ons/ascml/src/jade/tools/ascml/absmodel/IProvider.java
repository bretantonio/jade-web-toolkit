package jade.tools.ascml.absmodel;

/**
 * 
 */
public interface IProvider extends IAgentID
{
}
