package jade.tools.ascml.absmodel;

/**
 * 
 */
public interface ILauncher extends IAgentID
{
}
