
README - DistilledStateChartBehaviour (v 01-10-2010)

G. Fortino, F. Rango



For all the informations about how to install, compile and use this JADE add-on, read the user's guide contained in the "doc" directory.