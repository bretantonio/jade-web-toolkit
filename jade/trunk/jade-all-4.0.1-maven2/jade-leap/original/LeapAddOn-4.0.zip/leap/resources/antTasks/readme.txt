This directory contains jar files including additional ANT tasks.
These jar files must be copied into the ANT_HOME/lib directory.

1) StampysoftAntTasks.jar
- from Josh Eckels (jeckels@stampysoft.com) the "Stampysoft Ant Tasks" distributed under the MIT licence (see mit.txt)

2) leapTools.jar
