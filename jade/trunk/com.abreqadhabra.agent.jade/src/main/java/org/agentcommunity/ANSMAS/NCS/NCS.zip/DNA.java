package org.agentcommunity.ANSMAS.NCS;

import java.io.InterruptedIOException;
import java.io.IOException;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;

import jade.domain.FIPANames.InteractionProtocol;


import jade.proto.SimpleAchieveREResponder;

import java.util.Vector;
import java.util.Enumeration;


public class DNA extends Agent {

     static class MarriageResponder extends SimpleAchieveREResponder{

	 public MarriageResponder(Agent agent){
	     //this only recieves messages which are appropriate for
	     //the FIPA-REQUEST protocol
	     super(agent,
		   createMessageTemplate(InteractionProtocol.FIPA_REQUEST));
	     
	 }
	 

	 protected  ACLMessage   prepareResponse(ACLMessage msg) {

	     ACLMessage response = msg.createReply();
	     
	     //we only understand "Marry Me!" messages. it is necesary
	     //to reply with not-undestood if this was the case.
	     if(msg.getContent()!=null && 
		msg.getContent().equals("Marry Me!")){
		 System.out.println(myAgent.getLocalName() + ":" + 
				    msg.getSender().getLocalName() + 
				    " has asked me to marry them!");
		 AID sender; 
		 sender = msg.getSender();

		 if(sender.getLocalName().equals("DNA")){
		     //we only have eyes for baz
		    
		     response.setPerformative(ACLMessage.AGREE);
		     System.out.println(myAgent.getLocalName() + 
					":I'm going to agree.");
		 }else{
		     ACLMessage refuse = msg.createReply();
		     //i'm not easy i won't marry just anybody 
		     response.setPerformative(ACLMessage.REFUSE);
		     System.out.println(myAgent.getLocalName() + 
					":I'm going to turn them down.");
		 }
	     }else{
		 response.setPerformative(ACLMessage.NOT_UNDERSTOOD);
		 System.out.println(myAgent.getLocalName() + 
				    ":I didn't understand what " + 
				    msg.getSender().getLocalName() +
				    " just said to me.");
		     
	     }
	     return response;
	 }
	 
	 protected  ACLMessage   prepareResultNotification(ACLMessage inmsg,
							   ACLMessage outmsg) {
	     //this callback happens if we sent a positive reply to
	     //the original request (i.e. an AGREE) if we have aggreed
	     //to be married, we have to inform the other agent that
	     //what they have asked is now complete (or if it failed)

	     //insert code for marrying agents here. 

	     ACLMessage msg = inmsg.createReply();
	     
	     msg.setContent("I Do!");
	     return msg;
	     
	 }
     }
    
    protected void setup() {
	System.out.println(getLocalName() +
			   ": I wonder if anybody wants to marry me?");

	addBehaviour(new MarriageResponder(this));

	
    }
}
