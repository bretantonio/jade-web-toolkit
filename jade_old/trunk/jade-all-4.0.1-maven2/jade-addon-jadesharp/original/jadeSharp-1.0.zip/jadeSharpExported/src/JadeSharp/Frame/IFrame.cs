using System;

namespace JadeSharp
{
    /// <summary>
    /// Interface used for all Frames.
    /// </summary>
    public interface IFrame
    {
        string TypeName { get; }
    }
}
