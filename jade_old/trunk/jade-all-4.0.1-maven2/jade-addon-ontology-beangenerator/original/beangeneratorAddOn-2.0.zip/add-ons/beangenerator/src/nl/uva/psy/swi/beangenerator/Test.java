package nl.uva.psy.swi.beangenerator;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Test {
  public Test() {

  }


public static void main(String[] args) {
  new Test();
}
}