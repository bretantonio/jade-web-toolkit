/**
 * Title:       ABITS_Messenger_HTTP.java
 * Copyright:   Copyright (c) 2003-2005 The ABITS Group, UCD. All rights reserved.
 * Licence:     This file is free software; you can redistribute it and/or modify
 *              it under the terms of the GNU Lesser General Public License as published by
 *              the Free Software Foundation; either version 2.1, or (at your option)
 *              any later version.
 *
 *              This file is distributed in the hope that it will be useful,
 *              but WITHOUT ANY WARRANTY; without even the implied warranty of
 *              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *              GNU Lesser General Public License for more details.
 *
 *              You should have received a copy of the GNU Lesser General Public License
 *              along with Agent Factory; see the file COPYING.  If not, write to
 *              the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *              Boston, MA 02111-1307, USA.
 */
package ie.ucd.cs.abits.fipa.messenger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public final class ABITS_Messenger_HTTP extends ABITS_Messenger_AbsClass
{
 private static final String CACHECONTROL   = "Cache-Control: no-cache";
 private static final String CONLIFE        = "Connection: Keep-Alive";
 private static final String CONLEN         = "Content-Length: ";
 private static final String CONTYPEXML     = "Content-Type: application/xml";
 private static final String CONTYPETXT     = "Content-Type: application/text";
 private static final String CONTYPEMIX     = "Content-Type: multipart/mixed ;";
 private static final String DDASH          = "--";
 private static final String MIMEVER        = "Mime-Version: 1.0";
 private static final String MIMEMESG       = "This is not part of the MIME multipart encoded message.";
 private static final String NEWLINE        = "\r\n";
 
 private final String        recipientAgentName;
 private final String        destinationMAS;
 private final String        ACLMessage;
 private final boolean       debug;
 private String              fullQualifiedDomainName;
 private String              boundaryStr;
 private String              envelopeStr;
 private int                 portNumber;
 private int                 ACLPayloadSize = 0;
 
 public ABITS_Messenger_HTTP(String destMAS, String destAgent, String mesg,
   boolean status)
 {
  this.destinationMAS = destMAS;
  this.recipientAgentName = destAgent;
  this.ACLMessage = mesg;
  this.debug = status;
  strip();
 }
 
 public boolean getDispatchStatus()
 {
  return true;
 }
 
 public void dispatchMesg()
 {
  boundaryStr = genBoundaryStr();
  ACLPayloadSize = ACLMessage.length();
  envelopeStr = genEnvelopeStr();
  
  try
  {
   if (debug)
   {
    System.out.println("-----------------------------------------------------");
    System.out.println("                        Debug                        ");
    System.out.println("-----------------------------------------------------");
    System.out.println(" Destination MAS is : " + destinationMAS);
    System.out.println(" Destination IA is : " + recipientAgentName);
    System.out.println(" FQDN is : " + fullQualifiedDomainName);
    System.out.println(" Port number is : " + portNumber);
    System.out.println(" Envelopse is : " + envelopeStr);
    System.out.println(" Envelopse size is : " + envelopeStr.length());
    System.out.println(" ACL is : " + ACLMessage);
    System.out.println(" ACL size is : " + ACLPayloadSize);
    System.out.println(" Boundary is : " + boundaryStr);
   }

   Socket mesgTransport = new Socket(fullQualifiedDomainName, portNumber);
   PrintWriter out = new PrintWriter(mesgTransport.getOutputStream(), true);
   BufferedReader in = new BufferedReader(new InputStreamReader(mesgTransport
     .getInputStream()));
   
   out.print(genHTTPHeaderStr());
   out.print(DDASH + boundaryStr+NEWLINE);
   out.print(CONTYPEXML+NEWLINE);
   out.print(NEWLINE);
   out.print(envelopeStr+NEWLINE);
   out.print(DDASH + boundaryStr+NEWLINE);
   out.print(CONTYPETXT+NEWLINE);
   out.print(NEWLINE);
   out.print(ACLMessage+NEWLINE);
   out.print(DDASH + boundaryStr + DDASH+NEWLINE);
   out.print(NEWLINE);
   
   out.flush();
   String line;
   boolean exitCondition = false;
   
   while (((line = in.readLine()) != null) && !(exitCondition))
   {
    if (line.contains("200 OK"))
    {
     exitCondition = true;
     if (debug)
     {
      System.out.println(" Server received okay. Closing.");
      System.out
      .println("-----------------------------------------------------");
     }
    }
   }
   in.close();
   mesgTransport.close();
  }
  catch (UnknownHostException uhe)
  {
   System.err.println("Error : Unknownhost!");
   System.err.println("Error : " + fullQualifiedDomainName);
   uhe.printStackTrace();
  }
  catch (IOException ioe)
  {
   System.err.println("Error : IO!");
   System.out.println("Error : " + ioe);
   ioe.printStackTrace();
  }
 }
 
 private String generateDateStamp()
 {
  Date rightNow = new Date();
  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmssSSS");
  dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
  return (dateFormat.format(rightNow) + "Z");
 }
 
 private void strip()
 {
  String tmpStr = destinationMAS;
  int start = 0;
  int middle = 0;
  int end = 0;
  int endCond = tmpStr.length();
  for (int i = 0; i < endCond; i++)
  {
   if (tmpStr.startsWith(":", i))
   {
    middle = i;
   }
   if (tmpStr.startsWith("/", i))
   {
    if ((i + 2) < tmpStr.length() && (tmpStr.charAt(i + 1) == '/'))
    {
     start = i + 2;
    }
    else
    {
     end = i;
    }
   }
  }
  portNumber = Integer.parseInt(tmpStr.substring(middle + 1, end));
  fullQualifiedDomainName = tmpStr.substring(start, middle);
 }
 
 private String genEnvelopeStr()
 {
  StringBuilder s = new StringBuilder(750);
  s.append("<?xml version=\"1.0\"?>");
  s.append("<envelope><params index=\"1\"><to><agent-identifier><name>");
  s.append(recipientAgentName);
  s.append("</name><addresses><url>");
  s.append(destinationMAS);
  s.append("</url></addresses></agent-identifier></to><from><agent-identifier><name>da0@unknown:1099/JADE</name><addresses><url>http://unknown:7778/acc</url></addresses></agent-identifier></from><acl-representation>fipa.acl.rep.string.std</acl-representation><payload-length>");
  s.append(ACLPayloadSize);
  s.append("</payload-length><date>");
  s.append(generateDateStamp());
  s.append("</date><intended-receiver><agent-identifier><name>");
  s.append(recipientAgentName);
  s.append("</name><addresses><url>");
  s.append(destinationMAS);
  s
  .append("</url></addresses></agent-identifier></intended-receiver></params></envelope>");
  return (s.toString());
 }
 
 private String genHTTPHeaderStr()
 {
  StringBuilder s = new StringBuilder(350);
  s.append("POST ");
  s.append(destinationMAS);
  s.append(" HTTP/1.1");
  s.append(NEWLINE);
  s.append(CACHECONTROL);
  s.append(NEWLINE);
  s.append("Host: ");
  s.append(fullQualifiedDomainName);
  s.append(NEWLINE);
  s.append(MIMEVER);
  s.append(NEWLINE);
  s.append(CONTYPEMIX);
  s.append(" boundary=\"");
  s.append(boundaryStr);
  s.append("\"");
  s.append(NEWLINE);
  s.append(CONLEN);
  s.append(calcContentLength());
  s.append(NEWLINE);
  s.append(CONLIFE);
  s.append(NEWLINE);
  s.append(NEWLINE);
  s.append(MIMEMESG);
  s.append(NEWLINE);
  return (s.toString());
 }
 
 private int calcContentLength()
 {
  StringBuilder s = new StringBuilder(1300);
  s.append(MIMEMESG);
  s.append(NEWLINE);
  s.append(NEWLINE);
  s.append(DDASH);
  s.append(boundaryStr);
  s.append(NEWLINE);
  s.append(CONTYPEXML);
  s.append(NEWLINE);
  s.append(envelopeStr);
  s.append(NEWLINE);
  s.append(DDASH);
  s.append(boundaryStr);
  s.append(NEWLINE);
  s.append(CONTYPETXT);
  s.append(NEWLINE);
  s.append(ACLMessage);
  s.append(NEWLINE);
  s.append(DDASH);
  s.append(boundaryStr);
  s.append(DDASH);
  s.append(NEWLINE);
  s.append(NEWLINE);
  return (s.toString().length());
 }
 
 private String genBoundaryStr()
 {
  Date tmpObj = new Date();
  StringBuilder s = new StringBuilder(30);
  s.append("bernard");
  s.append(tmpObj.getTime());
  s.append("roche");
  return (s.toString());
 }
 
}
