package webserviceontology.numberspeller;
public class ErrorPredicate implements jade.content.Predicate {
	private java.lang.String errorMessage;
	public void setErrorMessage(java.lang.String msg) { this.errorMessage = msg;}
	public java.lang.String getErrorMessage() { return this.errorMessage; }
}
