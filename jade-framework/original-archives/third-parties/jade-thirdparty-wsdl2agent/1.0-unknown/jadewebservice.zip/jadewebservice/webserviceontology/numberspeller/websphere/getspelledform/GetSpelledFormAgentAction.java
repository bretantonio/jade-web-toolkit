package webserviceontology.numberspeller.websphere.getspelledform;
public class GetSpelledFormAgentAction implements jade.content.AgentAction {
	private java.lang.String numberToConvert = null;
	public void setNumberToConvert (java.lang.String param) { this.numberToConvert = param; }
	public java.lang.String getNumberToConvert () { return this.numberToConvert; }
	public java.lang.String getNumberToConvert_SOAP () { 
		java.lang.String jadeSlot = this.numberToConvert; 
		String soapSlot = jadeSlot;
		return soapSlot;
	 }
	private java.lang.String encodedlocale = null;
	public void setEncodedlocale (java.lang.String param) { this.encodedlocale = param; }
	public java.lang.String getEncodedlocale () { return this.encodedlocale; }
	public java.lang.String getEncodedlocale_SOAP () { 
		java.lang.String jadeSlot = this.encodedlocale; 
		String soapSlot = jadeSlot;
		return soapSlot;
	 }
}
