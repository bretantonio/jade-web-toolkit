package webserviceontology.numberspeller;
public class WebServiceOntology extends jade.content.onto.Ontology {
	private static jade.content.onto.Ontology theInstance = new WebServiceOntology(jade.content.onto.BasicOntology.getInstance());
	public static jade.content.onto.Ontology getInstance() { return theInstance; }
	public  WebServiceOntology (jade.content.onto.Ontology base) {
		super("NumberSpellerWebServiceOntology", base);
		jade.content.schema.AgentActionSchema as = null;
		jade.content.schema.PredicateSchema ps = null;
		jade.content.schema.ConceptSchema cs = null;
		try {
			add (new jade.content.schema.PredicateSchema("NumberSpellerErrorPredicate"), webserviceontology.numberspeller.ErrorPredicate.class);
			ps = (jade.content.schema.PredicateSchema) getSchema("NumberSpellerErrorPredicate");
			ps.add("errorMessage", (jade.content.schema.PrimitiveSchema) getSchema(jade.content.onto.BasicOntology.STRING));

			add (new jade.content.schema.AgentActionSchema("WebSphereGetSpelledFormAgentAction"), webserviceontology.numberspeller.websphere.getspelledform.GetSpelledFormAgentAction.class);
			add (new jade.content.schema.PredicateSchema("WebSphereGetSpelledFormPredicate"), webserviceontology.numberspeller.websphere.getspelledform.GetSpelledFormPredicate.class);
			as = (jade.content.schema.AgentActionSchema) getSchema("WebSphereGetSpelledFormAgentAction");
			ps = (jade.content.schema.PredicateSchema) getSchema("WebSphereGetSpelledFormPredicate");

			as.add ("numberToConvert", (jade.content.schema.PrimitiveSchema) getSchema(jade.content.onto.BasicOntology.STRING), jade.content.schema.ObjectSchema.OPTIONAL);
			as.add ("encodedlocale", (jade.content.schema.PrimitiveSchema) getSchema(jade.content.onto.BasicOntology.STRING), jade.content.schema.ObjectSchema.OPTIONAL);
			ps.add ("outMsgText", (jade.content.schema.PrimitiveSchema) getSchema(jade.content.onto.BasicOntology.STRING), jade.content.schema.ObjectSchema.OPTIONAL);
		} catch (jade.content.onto.OntologyException oe) { throw new RuntimeException(oe.getMessage()); }
	}
}
