package webserviceontology.numberspeller.websphere.getspelledform;
public class GetSpelledFormPredicate implements jade.content.Predicate {
	private java.lang.String outMsgText;
	public void setOutMsgText (java.lang.String param) { this.outMsgText = param; }
	public java.lang.String getOutMsgText () { return this.outMsgText; }
	public void setOutMsgText_SOAP (java.lang.String soapSlot) { 
		String jadeSlot = soapSlot;
		this.outMsgText = jadeSlot;
	 }
}
