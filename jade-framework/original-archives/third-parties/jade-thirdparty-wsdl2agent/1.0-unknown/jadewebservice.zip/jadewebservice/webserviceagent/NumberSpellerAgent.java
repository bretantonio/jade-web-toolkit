package webserviceagent;
public class NumberSpellerAgent extends jade.core.Agent {
	private jade.content.ContentManager manager = (jade.content.ContentManager) getContentManager();
	private jade.content.lang.Codec codec = new jade.content.lang.sl.SLCodec();
	protected void setup() {
		manager.registerLanguage(codec);
		manager.registerOntology(webserviceontology.numberspeller.WebServiceOntology.getInstance());
		addBehaviour(new HandleRequestBehaviour(this));
	} // end setup
	public class HandleRequestBehaviour extends jade.core.behaviours.CyclicBehaviour {
		public HandleRequestBehaviour(jade.core.Agent a) { super(a); }
		public void action() {
		  try {
			jade.lang.acl.ACLMessage msg = receive(jade.lang.acl.MessageTemplate.MatchPerformative(jade.lang.acl.ACLMessage.REQUEST));
			if (msg != null) {
					jade.content.ContentElement ce = (jade.content.ContentElement) ((jade.content.onto.basic.Action) manager.extractContent(msg)).getAction();
					if (ce instanceof webserviceontology.numberspeller.websphere.getspelledform.GetSpelledFormAgentAction) {
						org.apache.axis.client.Service service = new org.apache.axis.client.Service();
						org.apache.axis.client.Call call    = (org.apache.axis.client.Call) service.createCall();
						call.setOperationName( new javax.xml.namespace.QName("urn:numberspeller", "getSpelledForm") );
						javax.xml.namespace.QName qn      = null;
						java.util.Vector params  = new java.util.Vector();
						params.add(((webserviceontology.numberspeller.websphere.getspelledform.GetSpelledFormAgentAction) ce).getNumberToConvert_SOAP());
						params.add(((webserviceontology.numberspeller.websphere.getspelledform.GetSpelledFormAgentAction) ce).getEncodedlocale_SOAP());
						Object[] paramsObject = new Object[params.size()];
						for (int i=0; i<params.size(); i++) paramsObject[i] = params.elementAt(i);
						Object resp;
						try {
							call.setTargetEndpointAddress( new java.net.URL("http://dwdemos.alphaworks.ibm.com/numspell/servlet/rpcrouter") );
							resp = call.invoke( paramsObject );
						} catch (org.apache.axis.AxisFault fault) {	
							jade.lang.acl.ACLMessage answerMsg = msg.createReply();
							answerMsg.setPerformative(jade.lang.acl.ACLMessage.INFORM);
							webserviceontology.numberspeller.ErrorPredicate result = new webserviceontology.numberspeller.ErrorPredicate();
							result.setErrorMessage(fault.getMessage());
							manager.fillContent(answerMsg, result);
							send(answerMsg);
							return;
						} // end SOAP exception
							webserviceontology.numberspeller.websphere.getspelledform.GetSpelledFormPredicate result = new webserviceontology.numberspeller.websphere.getspelledform.GetSpelledFormPredicate();
							result.setOutMsgText_SOAP((java.lang.String) resp);
							jade.lang.acl.ACLMessage answerMsg = msg.createReply();
							answerMsg.setPerformative(jade.lang.acl.ACLMessage.INFORM);
							manager.fillContent(answerMsg, result);
							send(answerMsg);
						}
			} else { block(); }
		  } catch(Exception e) { System.out.println(e); e.printStackTrace(); throw new RuntimeException(e.getMessage()); }
		} // end action
	} // end HandleRequestBehaviour
} // end Agent
