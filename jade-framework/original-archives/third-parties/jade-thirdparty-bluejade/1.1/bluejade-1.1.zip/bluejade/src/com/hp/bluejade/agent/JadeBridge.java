/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.agent;

import jade.lang.acl.*;

import java.net.*;
import java.io.*;

/**
 * Send an ACL message to the JADE socket proxy agent which is running on
 * a host system and listening on a particular port.
 */
public class JadeBridge {

    public static final String DEFAULT_AGENT_PROXY_HOST = "localhost";
    public static final int DEFAULT_AGENT_PROXY_PORT = 6789;

    private String host;
    private int port;

    /**
     * Constructor - uses default host and port number.
     */
    public JadeBridge() {
        this(DEFAULT_AGENT_PROXY_HOST, DEFAULT_AGENT_PROXY_PORT);
    }
    
    /**
     * Constructor with specified host name and port number.
     * @param aHost Name of host.
     * @param aPort Port number.
     */
    public JadeBridge(String aHost, int aPort) {
        host = aHost;
        port = aPort;
    }

    /**
     * Send an ACL message and return string form of ACL response.
     * @param aMsg The message to send.
     * @return The response as a string or error message if anything goes wrong.
     */
    public String sendMessage(String aMsg) {
        String response = null;
        try {
            response = sendACL(aMsg).toString();
        } catch (IOException e) {
            response = "Exception when sending ACL:" + e;
        }
        return response;
    }

    /**
     * Sends an ACLMessage (in String form) to gateway and returns the reply.
     * @param aMsg The message to send.
     * @return ACLMessage response from gateway.
     * @throws IOException If any error occurs during sending or receiving.
     * @throws SocketException If the socket can't be opened.
     * @throws UnknownHostException If we can't connect to the host.
     */
    public ACLMessage sendACL(String aMsg)
                    throws IOException, UnknownHostException, SocketException {
        int timeout = 60 * 1000;    // 60 seconds
        Socket socket = new Socket(host, port); // open socket to gateway

        socket.setSoTimeout(timeout);    //Wait before timing out

        ACLMessage response = null;
        PrintStream out = new PrintStream(socket.getOutputStream());
        DataInputStream in = new DataInputStream(socket.getInputStream());

        out.println(aMsg);  // send the message
        out.flush();        // flush it completely

        java.util.Date startTime = new java.util.Date();

        try {
            ACLParser parser = new ACLParser(in);  // parser works off input

            response = parser.Message();
        } catch (Throwable any) {

            // Unfortunately we get a ParseException for all errors (even
            // those caused by a timeout on the socket).  So do a check
            // ourselves to see if it likely a timeout caused the parse
            // exception.
            java.util.Date endTime = new java.util.Date();
            long millisecs = endTime.getTime() - startTime.getTime();

            if (millisecs > timeout * 95 / 100) {
                response = new ACLMessage(ACLMessage.FAILURE);

                response.setContent(
                    "( \"Timeout waiting for response from SocketProxy.\" )");
            } else {
                response = new ACLMessage(ACLMessage.FAILURE);

                response.setContent(
                    "( \"JadeBridge error in parsing ACL response from SocketProxy:"
                    + any + "\" )");
            }
        }

        socket.close();

        return response;
    }
}
