/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.service;

import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

import jade.util.BasicProperties;
import jade.util.ExpandedProperties;

import com.hp.bluejade.util.OutputGrabber;

/**
 * Capture and format raw println's to conform to same format
 * as the HPAS log.
 * @version 1.00
 * @author Dick Cowan - HP Labs
 */
public class SimpleLogger implements LogInterface, OutputGrabber.MessageWriter {

    PrintStream logFile = null;
    PrintStream originalSystemOut = null;
    PrintStream originalSystemErr = null;
    SimpleDateFormat dateFormatter;
    String simpleDateFormatString = null;
    OutputGrabber outGrabber = null;        
    OutputGrabber errGrabber = null;        

    /**
     * Simple logger implementation.
     * @param aProp Optional properties collection - may be null.
     */
    public SimpleLogger(BasicProperties aProp) {
        try {
            String logFileName = null;
            if (aProp != null) {
                logFileName = aProp.getProperty("log.name");
            }
            if (logFileName == null) {
                String tempDir = ExpandedProperties.getEnvironmentProperties().getPropertyIgnoreCase("temp");
                if (tempDir == null) {
                    tempDir = ExpandedProperties.getEnvironmentProperties().getPropertyIgnoreCase("tmp");
                }
                if (tempDir == null) {
                    tempDir = ".";  // current directory
                }
                logFileName = tempDir + "/jbossjade_log.txt";
            }                
            logFile = new PrintStream(new FileOutputStream(logFileName));
        } catch (Exception any) {
            // ignore
        }
        originalSystemOut = System.out;
        originalSystemErr = System.err;
        simpleDateFormatString = "MM/dd/yy HH:mm:ss";
        dateFormatter = new SimpleDateFormat(simpleDateFormatString);
        outGrabber = new OutputGrabber(this, false);
        errGrabber = new OutputGrabber(this, true);

        System.setOut(new PrintStream(outGrabber));
        System.setErr(new PrintStream(errGrabber));
    }

    /**
     * This method is called by the output grabbers. Those grabbers
     * will also capture the HPAS output when its being written to
     * the GUI console as well. So this method examines the start of
     * the message to see if it already has the header. If it doesn't
     * have the header, this method will construt one. In all cases,
     * it then sends the message to the original System.out.
     * @param isErr True if the message was captured by the outputgrabber
     * for System.err, false if it was captured by output grabber for System.out.
     * @param aMessage The output line.
     */
    public void writeMessage(boolean isErr, String aMessage) {
        StringBuffer sb = new StringBuffer();
        sb.append("[").append(dateFormatter.format(new Date())).append("]");
        int tsl = sb.length();
        boolean stamped = (aMessage.length() > tsl);
        for (int i = 0; (stamped && (i<tsl)); i++) {
            if (Character.getType(sb.charAt(i)) != Character.getType(aMessage.charAt(i))) {
                stamped = false;
                break;
            }
        }
        if (!stamped) {
            sb.append("[").append(Thread.currentThread().getName()).append("]");
            sb.append("[");
            sb.append((isErr) ? "E" : "S");
            sb.append("]: ").append(aMessage.trim());
            aMessage = sb.toString();
        }
        originalSystemOut.println(aMessage);
        logFile.println(aMessage);
        logFile.flush();
    }
        
    /**
     * Close the logger. Decrements its use count and if zero, close
     * the output grabbers, and restore System.out and System.err.
     */
    public void close() {
        System.setOut(originalSystemOut);
        System.setErr(originalSystemErr);
        outGrabber.close();
        errGrabber.close();
        if (logFile != null) {
            logFile.close();
        }
    }

    public void logInfo(String aMessage) {
        writeMessage(false, aMessage);
    }
    
    /**
     * Log an error. If CSF log channel exits, use it otherwise output to System.err.
     * @param aMethodName The name of the method containing the call.
     * @param aMessage The message to be logged.
     */
    public void logError(String aMessage) {
        writeMessage(true, aMessage);
    }

    public void logError(String aMessage, Throwable anError) {
        logError(aMessage + ":" + anError);
    }
}
