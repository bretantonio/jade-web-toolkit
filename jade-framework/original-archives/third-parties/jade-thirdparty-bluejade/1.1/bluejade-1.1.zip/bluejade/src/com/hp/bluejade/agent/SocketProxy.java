/**
 * JADE - Java Agent DEvelopment Framework is a framework to develop
 * multi-agent systems in compliance with the FIPA specifications.
 * Copyright (C) 2000 CSELT S.p.A.
 *
 * GNU Lesser General Public License
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation,
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 */

package com.hp.bluejade.agent;

import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.*;
import jade.core.behaviours.SimpleBehaviour;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Modified version of Jade's SocketProxyAgent to correct bug and
 * extend functionality. 
 * @author Fabio Bellifemine - CSELT S.p.A
 * @author Dick Cowan - HP Labs
 */
public class SocketProxy extends CoolAdapter {

    public final static int DEFAULT_PORT = 6789;
    int timeOutMillis = 60000;  // default value: 60 seconds
    Vector allowedNames = null; // null value implies all agent names accepted
    int portNumber;
    Server theServer = null;

    protected void setup() {
        super.setup();
        portNumber = getProperties().getIntProperty("port", DEFAULT_PORT);
        String agentNamesList = getProperties().getProperty("addressee", null);
        if (agentNamesList != null) {
            allowedNames = new Vector();
            StringTokenizer parser = new StringTokenizer(agentNamesList);
            //verify if the name of the agents have the hap or not. 
            //If not add the local hap (of the dfproxy agent).
            while (parser.hasMoreTokens()) {
                String name = parser.nextToken();
                if (name.equals("*")) {
                    // * allows all names. If its included with other names they are ignored.
                    allowedNames = null;
                    break;
                } else {
                    int atPos = name.lastIndexOf('@');
                    if (atPos == -1) {
                        name = name + "@" + getHap();
                    }
                    allowedNames.add(name);
                }
            }
            printInfo(1, "Allowed addressees: " + getAddressees());
        }
        theServer = new Server(portNumber, this);
    }

    /**
     * Return initial addressee list for inspection.
     * @return The original addressee list.
     */
    public String getAddressees() {
        if (allowedNames == null) {
            return "All agent names accepted.";
        } else {
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < allowedNames.size(); i++) {
                sb.append((String)allowedNames.elementAt(i));
                if (i < allowedNames.size()-1) {
                    sb.append(",");
                }
            }
            return sb.toString();
        }
    }

    /**
     * Return proxy port number for inspection.
     * @return The port number.
     */
    public int getPort() {
        return portNumber;
    }

    /**
     * Return time out value for inspection.
     * @return The time out (in seconds);
     */
    public int getTimeOutSeconds() {
        return timeOutMillis / 1000;
    }
    
    /**
     * Set time out value.
     * @param seconds Time out value - will be converted to milliseconds for internal usage.
     */
    public void setTimeOutSeconds(int seconds) {
        timeOutMillis = seconds * 1000;
        printInfo(1, "Timeout changed to " + seconds + " seconds.");
    }

    protected void takeDown() {
        printInfo(3, "Deregistering");
        if (theServer != null) {
            try {
                theServer.interrupt();
                theServer.close();
                theServer.join();
            } catch (Exception any) {
                // ignore
            }
        }
        super.takeDown();
    }

    class Server extends Thread {
        ServerSocket listen_socket = null;
        CoolAdapter myAgent = null;
        boolean closed = false;
        HashSet connections = null;

        /**
         * Constructor of the class.
         * It creates a ServerSocket to listen for connections on.
         * @param port is the port number to listen for. If 0, then it uses
         * the default port number.
         * @param a is the pointer to agent to be used to send messages.
         * @param receiver is the vector with the names of all the agents that
         * wish to receive messages through this proxy.
         */
        Server(int port, CoolAdapter anAgent) {
            myAgent = anAgent;
            setName(myAgent.getLocalName());
            try {
                listen_socket = new ServerSocket(port);
            } catch (IOException e) {
                e.printStackTrace();
                myAgent.doDelete();

                return;
            }
            connections = new HashSet();
            myAgent.printInfo(1, "Listening on port:" + port);
            start();
        }

        protected void finalize() {
            if (!closed) {
                close();
            }
        }

        public void close() {
            closed = true;
            // Stop listenting for new connections
            if (listen_socket != null) {
                try {
                    listen_socket.close();
                } catch (IOException ioe) {
                    // ignore
                }
                listen_socket = null;
            }
            // Shut down any open ones
            if (connections != null) {
                java.util.Iterator itor = connections.iterator();
                while (itor.hasNext()) {
                    Connection c = (Connection)itor.next();
                    c.close();
                }
                connections = null;
            }
        }

        /**
         * The body of the server thread. It is executed when the start() method
         * of the server object is called.
         * Loops forever, listening for and accepting connections from clients.
         * For each connection, creates a Connection object to handle communication
         * through the new Socket. Each Connection object is a new thread.
         * The maximum queue length for incoming connection indications
         * (a request to connect) is set to 50 (that is the default for the
         * ServerSocket constructor). If a connection indication
         * arrives when the queue is full, the connection is refused.
         */
        public void run() {
            while (!closed) {
                try {
                    Socket client_socket = listen_socket.accept();

                    myAgent.printInfo(1, "New Connection with "
                             + client_socket.getInetAddress().toString()
                             + " on remote port " + client_socket.getPort());

                    connections.add(new Connection(this, client_socket, myAgent));
                } catch (Exception any) {  // Could be IOException or InterruptedException
                    if (!closed) {
                        any.printStackTrace();
                        myAgent.doDelete();
                    }
                }
            }
        }
        
        public void connectionDone(Connection aConnection) {
            connections.remove(aConnection);
        }
    }

    class Connection extends Thread {
        Server server = null;
        CoolAdapter myAgent;
        Socket client;
        DataInputStream in;
        PrintStream out;
        boolean closed = false;

        Connection(Server theServer, Socket client_socket, CoolAdapter anAgent) {
            server = theServer;
            myAgent = anAgent;
            client = client_socket;
            setName(myAgent.getLocalName());

            try {
                in = new DataInputStream(client.getInputStream());
                out = new PrintStream(client.getOutputStream(), true);
            } catch (IOException e) {
                try {
                    client.close();
                    client = null;
                } catch (IOException e2) {}

                e.printStackTrace();

                return;
            }

            start();
        }

        protected void finalize() {
            if (!closed) {
                close();
            }
        }

        /**
         * Close all our stuff.
         */
        void close() {
            // Inform the server that this connection handler is done.
            server.connectionDone(this);
            
            try {
                if (client != null) {
                    client.close();
                    client = null;
                }
            } catch (Exception e) {}

            try {
                if (in != null) {
                    in.close();
                    in = null;
                }
            } catch (Exception e) {}

            try {
                if (out != null) {
                    out.close();
                    out = null;
                }
            } catch (Exception e) {}
            closed = true;
        }

        /**
         * Validate ALL the agent names of the recipients in the ACL message.
         * @param msg The ACL message which we wish to send.
         * @return True if they are all allowed, false otherwise.
         */
        private boolean allValidReceivers(ACLMessage msg) {
            if (allowedNames == null) {
                return true;
            }
            jade.util.leap.Iterator itor = msg.getAllReceiver();
            while (itor.hasNext()) {
                if (!isValidReceiver(((AID)itor.next()).getName())) {
                    return false;
                }
            }
            return true;
        }

        /**
         * Validate a single agent name.
         * @param aName The intended agent's name.
         * @return True if its allowed, false otherwise.
         */
        private boolean isValidReceiver(String aName) {
            if (allowedNames == null) {
                return true;
            }
            for (int i = 0; i < allowedNames.size(); i++) {
                String allowName = (String)allowedNames.elementAt(i);
                if (allowName.equalsIgnoreCase(aName)) {
                    return true;
                }
            }
            return false;
        }

        /**
         * Fix any receiver names which are missing the @ part.
         * @param msg The ACL message which we wish to send.
         */
        private void fixReceiverNames(ACLMessage msg) {
            jade.util.leap.Iterator itor = msg.getAllReceiver();
            while (itor.hasNext()) {
                AID receiverAID = (AID)itor.next();
                String receiverName = receiverAID.getName();
                if (receiverName.indexOf('@') < 0) {
                    msg.removeReceiver(receiverAID);
                    AID newAID = new AID(receiverName, AID.ISLOCALNAME);
                    msg.addReceiver(newAID);
                    myAgent.printInfo(1, "Changed receiver " + receiverName +
                                                   " to " + newAID.getName());
                }
            }
        }
       
        /**
         * Parses ACL messages from the input stream. It is written to
         * take multiple messages from the stream. For each message it
         * gets from the input stream it 1) sends it into the Jade world
         * and 2) starts a new behavior to wait for the response. When that
         * behavior gets the response (or times out) it will send a message
         * back out the socket.
         */
        public void run() {
            boolean gotOneMessage = false;
            ACLMessage msg = null;
            try {
                ACLParser parser = new ACLParser(in);

                while (true) {
                    // This may throw a parsing exception due to
                    // end of file (stream).
                    msg = parser.Message(); 
                    gotOneMessage = true;  // OK to ignore EOF now
                    myAgent.printInfo(3, "Received message:" + msg);
                    
                    fixReceiverNames(msg);
                    if (allValidReceivers(msg)) {
                        msg.setSender(myAgent.getAID());

                        if ((msg.getReplyWith() == null) || (msg.getReplyWith().length() < 1)) {
                            msg.setReplyWith(myAgent.getLocalName() + "."
                                             + getName() + "."
                                             + java.lang.System
                                                 .currentTimeMillis());
                        }
                    
                        if ( msg.getInReplyTo() == null ) {
                           msg.setInReplyTo( "noValue" );
                        }

                        if (getInfoLevel() >= 1) {
                            jade.util.leap.Iterator itor = msg.getAllReceiver();
                            StringBuffer sb = new StringBuffer();
                            while (itor.hasNext()) {
                                AID aid = (AID)itor.next();
                                sb.append(aid.getName());
                                if (itor.hasNext()) {
                                    sb.append(" ");
                                }
                            }
                            printInfo(1, "Sending message to:" + sb.toString());
                            printInfo(3, msg.toString());
                        }
                        myAgent.send(msg);
                        
                        myAgent.addBehaviour(new WaitAnswersBehaviour(myAgent, msg, out));
                    } else {
                        myAgent.printInfo(1, "Unauthorized recipient.");
                        out.println("(refuse :content unauthorised)");
                    	out.flush();
                        close();

                        return;
                    }
                }
            } catch (Throwable any) {

                // Jade puts "<EOF>" in the exception message
                if ( (gotOneMessage) && (any.getMessage() != null) && (any.getMessage().indexOf("<EOF>") >= 0) ) {
                    // ignore it
                } else {
                    msg = new ACLMessage(ACLMessage.FAILURE);
                    msg.setContent("( \"Error: " + any + "\" )");
                    myAgent.printInfo(1, "Writing error message to socket.");
                    myAgent.printInfo(3, msg.toString());
                    out.println(msg.toString());
                    out.flush();
                }
                close();
                return;
            }
        }
    }

    class WaitAnswersBehaviour extends SimpleBehaviour {
        ACLMessage msg;
        PrintStream out;
        long timeout;
        boolean finished;
        MessageTemplate mt;
        CoolAdapter myAgent=null;
    
        WaitAnswersBehaviour(CoolAdapter a, ACLMessage m, PrintStream o) {
            super(a);
            myAgent = a;
            out = o;

            try {
                mt = MessageTemplate
                    .and(MessageTemplate
                        .MatchSender((AID) m.getAllReceiver()
                        .next()), MessageTemplate
                            .MatchInReplyTo(m.getReplyWith()));
            } catch (Exception e) {
                mt = MessageTemplate.MatchInReplyTo(m.getReplyWith());
            }

            Date d = m.getReplyByDate();

            if (d != null) 
            {
                timeout = d.getTime() - (new Date()).getTime();
                if (timeout <= 1000)  // must be at least 1 second
                    timeout = 1000;
            }
            else
                timeout = timeOutMillis;

            finished = false;
        }

        /**
         * Method action - used by behavior.
         */
        public void action() {
            msg = myAgent.blockingReceive(mt, timeout);

            if (msg == null) {
                myAgent.printError("Reply was null");
                msg = new ACLMessage(ACLMessage.FAILURE);
                msg.setContent("( \"Timed-out after "+getTimeOutSeconds()+" seconds waiting for response from agent\" )");
            } else {
                printInfo(1, "Received reply from:" + msg.getSender().getName());
            }
            myAgent.printInfo(1, "Writing message to socket.");
            myAgent.printInfo(3, msg.toString());
            out.println(msg.toString());
            out.flush();
            finished = true;
        }

        /**
         * Method done, used by behavior.
         * @return boolean indicating if done or not.
         */
        public boolean done() {
            return finished;
        }
    }

}