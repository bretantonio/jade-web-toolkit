/*
 * (c) Copyright Hewlett-Packard Company 2001-2002 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.service;

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;

import java.awt.GraphicsEnvironment;  // Used to check if GUI agents should be allowed
import java.awt.GraphicsDevice;       // Used to check if GUI agents should be allowed

import org.w3c.dom.*;
import org.w3c.dom.traversal.*;
import javax.xml.parsers.*;

import jade.wrapper.*;

// The following import is required to create the agent platform.
// Ideally, it should not be required as it should be possible to create the
// platform using only those classes defined in the wrapper package.
import jade.BootProfileImpl;
// The following two provide more powerful property management
import jade.util.BasicProperties;
import jade.util.ExpandedProperties;

/**
 * Provides a base class which will be extended to provide management of 
 * the <a href="http://sharon.cselt.it/projects/jade/">JADE</a> agent
 * platform under specific J2EE servers.
 * @author Dick Cowan - HP Labs
 */
public class JadeServiceSupport
    implements
        JadeServiceInterface,  // Interface for this service
            // void setJNDIName(final String aName);
            // void setConfigDocName(final String aName);
            // String getNote();
            // void setNote(final String message);
            // createAgent(String agentName, String agentClass, String args);
            // killAgent(String agentName);
        
        PlatformController.Listener  // Interface to get JADE events
            // bornAgent(PlatformEvent anEvent);
            // deadAgent(PlatformEvent anEvent);
            // startedPlatform(PlatformEvent anEvent);
            // suspendedPlatform(PlatformEvent anEvent);
            // resumedPlatform(PlatformEvent anEvent);
            // killedPlatform(PlatformEvent anEvent);

{

    private static final String[] states = {"Stopped","Stopping","Starting","Started"};
    private static final int STOPPED  = 0;
    private static final int STOPPING = 1;
    private static final int STARTING = 2;
    private static final int STARTED  = 3;
    private int state = STOPPED;

    private boolean standAlone = false;
    LogInterface logger = null;
    
    private String m_jndiName;
    private String m_docName;
    
    private Document configDoc = null;

    private int infoLevel = 3;
    private Thread containerThread = null;
    private boolean containerActive = false;
    private PlatformController thePlatform = null;
    private BasicProperties commandLineProperties = null;
    private BasicProperties serviceProperties = null;
    private BasicProperties jadeProperties = null;
    private BootProfileImpl profile = null;
    private boolean isAgentContainer = false;
    private boolean guiAllowed = true;  // -nogui service argument will set it false
    
    private static final String version = "Version 1.1, June 2003";

    /** The agent controller class name. */
    private static final String AGENT_CONTROLLER = AgentController.class.getName ();

    /** The platform controller class name. */
    private static final String PLATFORM_CONTROLLER = PlatformController.class.getName ();

    /**
     * For testing - start agent system.
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        try {
            JadeServiceSupport service = new JadeServiceSupport(new ExpandedProperties(args));
            service.initService();
            service.startService();
        } catch (Throwable any) {
            System.out.println("Exception in main");
            any.printStackTrace(System.out);
        }
    }
       
    /**
     * Private constructor for testing.
     * @param props Command line properties
     */
    protected JadeServiceSupport(BasicProperties props) throws Exception {
        standAlone = (props != null);
        if (standAlone) {
            commandLineProperties = props;
            setConfigDocName(commandLineProperties.getProperty("config", "jade-service-config.xml"));
            Runtime.getRuntime().addShutdownHook(new Thread() {
                public void run() {
                    System.out.println("JadeService shutting down.");
                    stopService();
                }
            });
            setLogger(new SimpleLogger(commandLineProperties));
        }        
    }
        
    /**
     * Construct service instance. Creates empty command line properties
     * collection.
     */
    public JadeServiceSupport() throws Exception {
        this(null);
    }

    public int getState() {
        return state;
    }
    
    public String getStateString() {
        return states[state];
    }

    /**
     * Return state of stand alone flag. This is true when running with
     * no references to any J2EE implementation.
     */
    public boolean isStandAlone() {
        return standAlone;
    }
        
    public void setLogger(LogInterface aLogger) {
        logger = aLogger;
    }

    public void setJNDIName(String aName) {
        logInfo(1, "JadeService JNDI name:" + aName);
        m_jndiName = aName;
    }

    public String getJNDIName() {
        return (m_jndiName != null) ? m_jndiName : "JADE";
    }
    
    /**
     * Set file name of the configuration document.
     * @param aName The name of the file.
     */
    public void setConfigDocName(String aName) {
        logInfo(1, "JadeService config doc name:" + aName);
        m_docName = aName;
    }

    /**
     * Get file name of the configuration document.
     * This method is protected because it is not part of the exposed JMX interface.
     * @return String The name of the file.
     */
    public String getConfigDocName() {
        if (m_docName != null) {
            return m_docName;
        }
        if (commandLineProperties != null) {
            String name = commandLineProperties.getProperty("config");
            if (name != null) {
                return name;
            }
        }
        return "jade-service-config.xml";
    }

    public String getName() {
        return "JADE Service";
    }

    public Document getConfigDoc() {
        if (configDoc == null) {
            try {
                logInfo(1, "JadeService Reading " + getConfigDocName());
                // Step 1: create a DocumentBuilderFactory and setNamespaceAware
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                dbf.setNamespaceAware(true);

                // Step 2: create a DocumentBuilder
                DocumentBuilder db = dbf.newDocumentBuilder();

                // Step 3: parse the input file to get a Document object
                configDoc = db.parse(new File(getConfigDocName()));
                logInfo(2, "JadeService configuration document parsed.");
            } catch (Throwable any) {
                logError("Exception in getConfigDoc:", any);
            }
        }
        return configDoc;
    }
    
    /**
     * Get info level that controls level of detail shown in log.
     * @return The current info level.
     */
    public int getInfoLevel() {
        return infoLevel;
    }
    
    /**
     * Set the info level that controls level of detail shown in log.
     * @param aLevel The new info level.
     */
    public void setInfoLevel(int aLevel) {
        infoLevel = aLevel;
    }

    /**
     * Get the JADE platform controller.
     * @return The platform controller - may be null.
     */
    public PlatformController getPlatformController() {
        return thePlatform;
    }

    /**
     * Log a message. If CSF log channel exits, use it otherwise output to System.out.
     * @param aMessage The message to be logged.
     */
    public void logInfo(int aLevel, String aMessage) {
        if (getInfoLevel() >= aLevel) {
            logger.logInfo(aMessage);
        }
    }
    
    /**
     * Log an error.
     * @param aMessage The message to be logged.
     */
    public void logError(String aMessage) {
        logger.logError(aMessage);
    }

    /**
     * Log an error.
     * @param aMessage The message to be logged.
     * @param anError A Throwable item.
     */
    public void logError(String aMessage, Throwable anError) {
        logger.logError(aMessage, anError);
    }

    /**
     * Initialize this service. As long as the service is stopped, its OK
     * to call this method multiple times (as could be done from the management console).
     */
    public void initService() throws Exception {
        if (state != STOPPED) {
            throw new Exception("Service must be stopped first.");
        }
            
        serviceProperties = new ExpandedProperties(getInitializationArgs(getConfigDoc(), "serviceArgs"));
        if (commandLineProperties != null) {
            serviceProperties.copyProperties(commandLineProperties);
        }

        if (serviceProperties.getBooleanProperty("dump", false)) {
            showProperties(serviceProperties, "Service");
        }
        logInfo(1, getVersion());

        setAnySystemProperties(serviceProperties);
        if (serviceProperties.getBooleanProperty("nogui", false)) {
            guiAllowed = false;
        } else {
            // Lets see if we can support GUI agents
            guiAllowed = false;  // assume not
            try {
                GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
                GraphicsDevice dc = env.getDefaultScreenDevice();
                guiAllowed = true;  // ok
            } catch (Throwable any) {  // covers both Exceptions and Errors
                // guiAllowed already false
            }
        }
        logInfo(1, "guiAllowed=" + guiAllowed);

        jadeProperties = new ExpandedProperties(getInitializationArgs(getConfigDoc(), "jadeArgs"));
        if (jadeProperties.getBooleanProperty("dump", false)) {
            showProperties(jadeProperties, "JADE");
        }
    }

    public void destroyService() {
        stopService();
    }

    /**
     * Start the JADE service. Service must be in STOPPED state.
     * @throws Exception if anything goes wrong.
     */
    public void startService() throws Exception {
        if (state != STOPPED) {
            throw new Exception("Service must be stopped first.");
        }
        state = STARTING;
        
        setAnySystemProperties(jadeProperties);
        profile = new BootProfileImpl();
        profile.setArgProperties(jadeProperties);  // The profile will take just what it recognizes.
        isAgentContainer = profile.getArgProperties().getBooleanProperty(profile.CONTAINER_KEY, false);
        logInfo(1, "agentContainer=" + isAgentContainer);
        logInfo(1, "guiAllowed=" + guiAllowed); 

        // Create a thread to instantiate the JADE wrapper so that we
        // will have the proper classpath.  Each service has a service
        // context and each service context has a specific classloader.
        // The service context classloader carries with it the classpath
        // (<Archive>) list for that service.  Using the service context
        // to create a thread guarantees that the thread will have the proper
        // classloader associated with it.  Threads that do not install their
        // own classloader will "inherit" their classloader from the thread that
        // created them. 
        containerThread = new Thread(new Runnable() {    // BEGIN anonymous class

            public void run() {
                jade.core.Runtime jadeRuntime = jade.core.Runtime.instance();
                jadeRuntime.setCloseVM(false);  // so jade won't exit when last container is closed.
                // This syntax is a neat trick to refer to an instance
                // variable in the outer class from an anonymous inner
                // class.

                if (isAgentContainer) {
                    thePlatform = jadeRuntime.createAgentContainer(profile);
                } else {
                    thePlatform = jadeRuntime.createMainContainer(profile);       
                }
                containerActive = true;
                while (containerActive) {
                    try {
                        Thread.sleep(30000);  // 30 seconds
                    } catch (InterruptedException ie) {
                        containerActive = false;
                    }
                }
                logInfo(3, "Container thread ending.");
            }
        }, "JADE Container");
        
        // Although the following seems to be the default, we set it just to
        // be sure the proper class loader is used.
        containerThread.setContextClassLoader(Thread.currentThread().getContextClassLoader());        

        containerThread.start();  // invokes containerThread's run method
        logInfo(3, "Wait for container thread to initialize");
        while (!containerActive) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ie) {
                logError("Init thread was interrupted");
                state = STOPPED;
                throw new Exception("JadeService start interrupted");
            }
        }
        logInfo(3, "Container initialized");
        if (!isAgentContainer) {
            try {
                thePlatform.addPlatformListener(this);
            } catch (ControllerException ce) {
                logError("Unable to add platform listener.");
            }
            logInfo(3, "Added platform listener.");
        }
        startAgents(getAgentSet(getConfigDoc()), getConfigDoc());
        state = STARTED;
    }

    /**
     * Stop the service. If not started logs an error message and returns.
     */
    public void stopService() {
        if (state != STARTED) {
            logError("Service not started. Stop ignored");
            return;
        }
        state = STOPPING;
        //printThreads(null, null, 0);
        try {
            if (!isAgentContainer) {
                try {
                    thePlatform.removePlatformListener(this);
                } catch (ControllerException ce) {
                    logError("Unable to remove platform listener.");
                }
            }

            thePlatform.kill();
            containerThread.interrupt();
            containerThread.join();
            containerActive = false;
            thePlatform = null;
            configDoc = null;  // re-read jade-service-config.xml on start
        } catch (Throwable any) {
            logError("Exception while stopping", any);
        }
        state = STOPPED;
    }

    /**
     * An agent was born.
     * This method will be called by the platform controller. This is setup in
     * startService by calling PlatformController addPlatformListener method. 
     * @param agentName The name of the agent.
     */
    public void bornAgent(PlatformEvent anEvent) {
        String agentName = anEvent.getAgentGUID();
        int i = agentName.indexOf('@');
        if (i > 0) {
            agentName = agentName.substring(0, i);
        }
        logInfo(1, "Agent born:" + agentName);
    }

    /**
     * An agent died.
     * This method will be called by the platform controller. This is setup in
     * startService by calling PlatformController addPlatformListener method. 
     * @param agentName The name of the agent.
     */
    public void deadAgent(PlatformEvent anEvent) {
        String agentName = anEvent.getAgentGUID();
        int i = agentName.indexOf('@');
        if (i > 0) {
            agentName = agentName.substring(0, i);
        }
        logInfo(1, "Agent death:" + agentName);
        Set currentAgentSet = null;
        Set createAgentSet = null;
        try {
            Document configDoc = getConfigDoc();
            currentAgentSet = getAgentSet(configDoc);
            if (currentAgentSet.contains(agentName)) {
                Hashtable agentAttrs = getAgentAttributes(configDoc, agentName);
                // Get the restart flag, ignore case = true
                if (getBooleanAttribute(agentAttrs, "restart", false)) {
                        logInfo(1, "Agent restart:" + agentName);
                        createAgentSet = new HashSet();
                        createAgentSet.add(agentName);
                }
            }
            if (createAgentSet != null) {
                startAgents(createAgentSet, configDoc);
            }
        } catch (Throwable any) {
            logError("Exception in deadAgent:", any);
        }
    }

    /**
     * The platform was started.
     * This method will be called by the platform controller. This is setup in
     * startService by calling PlatformController addPlatformListener method. 
     * @param platformName The name of the platform (argument provided to
     * controllers constructor).
     */
    public void startedPlatform(PlatformEvent anEvent) {
        logInfo(1, "Platform stated:" + anEvent.getPlatformName());
    }

    /**
     * The platform was stopped.
     * This method will be called by the platform controller. This is setup in
     * startService by calling PlatformController addPlatformListener method. 
     * @param platformName The name of the platform (argument provided to
     * controllers constructor).
     */
    public void suspendedPlatform(PlatformEvent anEvent) {
        logInfo(1, "Platform suspended:" + anEvent.getPlatformName());
    }
    
    /**
     * Called when the platform is activated. PlatformEvent source is PlatformController.
     */
    public void resumedPlatform(PlatformEvent anEvent) {
        logInfo(1, "Platform resumed:" + anEvent.getPlatformName());
    }

    /**
     * The platform was destroyed.
     * This method will be called by the platform controller. This is setup in
     * startService by calling PlatformController addPlatformListener method. 
     * @param platformName The name of the platform (argument provided to
     * controllers constructor).
     */
    public void killedPlatform(PlatformEvent anEvent) {
        logInfo(1, "Platform killed:" + anEvent.getPlatformName());
    }
    
    /**
     * Take any properties whose key begins with "SYSTEM." and set them
     * (without the "SYSTEM." part) in the JVM's properties.
     * @param aProp The properties collection.
     */
    public void setAnySystemProperties(BasicProperties aProp) {
        for (Enumeration enum = aProp.keys() ; enum.hasMoreElements() ;) {
             String key = (String)enum.nextElement();
             if ((key.length() > 7) && (key.startsWith("SYSTEM."))) {
                String value = aProp.getProperty(key);
                System.setProperty(key.substring(7), value);  // drop the "SYSTEM." part
                logInfo(3, "Set system property:" + key.substring(7) + "=" + value);
             }
        }
    }

    /**
     * Show properties into log.
     * @param aProp The properties collection.
     * @param aHeader Header string.
     */
    public void showProperties(BasicProperties aProp, String aHeader) {
        jade.util.leap.ArrayList aList = new jade.util.leap.ArrayList();
        logInfo(3, "----- " + aHeader + " property values -----");
        for (Enumeration e = aProp.sortedKeys(); e.hasMoreElements(); ) {
            String key = (String) e.nextElement();
            Object o = aProp.get(key);
            if (o.getClass().isAssignableFrom(aList.getClass())) {
                jade.util.leap.ArrayList al = (jade.util.leap.ArrayList)o;
                jade.util.leap.Iterator itor = al.iterator();
                if (!itor.hasNext()) {
                    logInfo(3, key + "=<empty>");
                } else {
                    StringBuffer sb = new StringBuffer();
                    sb.append(key);
                    sb.append("=");
                    while (itor.hasNext()) {
                        sb.append(itor.next());
                        if (itor.hasNext()) {
                            sb.append(" ");
                        }
                    }
                    logInfo(3, sb.toString());
                }
            } else {
                logInfo(3, key + "=" + aProp.getProperty(key));
            }
        }
        logInfo(3, "----- End property values ----------");
    }

    public Set getAgentSet(Document doc) {
        Set agentSet = new HashSet();
        if (doc != null) {
            try {
                NodeList nodes = doc.getElementsByTagName("*");
                for (int i=0; i < nodes.getLength(); i++) {
                    Node node = nodes.item(i);
                    if ((node.getNodeType() == Node.ELEMENT_NODE) && (node.getNodeName().equalsIgnoreCase("agent"))) {
                        NamedNodeMap attributesMap = node.getAttributes();
                        Node x = attributesMap.getNamedItem("name");
                        if ((x != null) && (x.getNodeType() == Node.ATTRIBUTE_NODE)) {
                            agentSet.add(x.getNodeValue());
                        }
                    }
                }
            } catch (Throwable any) {
                logError("Exception in getAgentSet:", any);
            }
        }
        return agentSet;
    }

    /**
     * Method startAgents
     *
     *
     * @param agentSet - Set of agents to start. Declared with final modifier to enable
     * it to be referenced from within inner class.
     * @param configDoc
     *
     */
    public void startAgents(final Set agentSet, final Document configDoc) {
        logInfo(1, "Count of agents to be started=" + agentSet.size());
        Iterator itor = agentSet.iterator();
        while (itor.hasNext()) {
            String agentName = (String) (itor.next());
            logInfo(1, "Start agent name:" + agentName);
            Hashtable attrs = getAgentAttributes(configDoc, agentName);
            String agentClass = getAttribute(attrs, "class"); 
            String [] argArray = toStringArray(getAttribute(attrs, "args"));
            boolean gui = getBooleanAttribute(attrs, "gui", false);
            if (agentClass == null) {
                logError("No class specified for agent " + agentName);
            } else {
                logInfo(1, "Start agent class:" + agentClass);
                if (gui && (!guiAllowed)) {
                    logInfo(1, agentName + " not started as no GUI is available.");
                } else {
                    try {
                        AgentController newAgent = thePlatform.createNewAgent(agentName, agentClass,
                                                                              argArray);
                        logInfo(3, "Calling start on agent:" + agentName);
                        newAgent.start();
                    } catch (Throwable any) {
                        logError("Exception starting agent", any);
                    }
                }
            }
        }
    }

    public boolean getBooleanAttribute(Hashtable attrs, String attrName, boolean aDefaultValue) {
        String value = getAttribute(attrs, attrName);
        return (value == null) ? aDefaultValue : value.equalsIgnoreCase("true");
    }

    public int getIntAttribute(Hashtable attrs, String attrName, int aDefaultValue) {
        int result = aDefaultValue;
        try {
            result = Integer.parseInt(getAttribute(attrs, attrName));
        } catch (Throwable any) {
            // ignore
        }
        return result;
    }

    public String getAttribute(Hashtable attrs, String attrName) {
        if ((attrs != null) && (attrName != null)) {
            for (Enumeration enum = attrs.keys() ; enum.hasMoreElements() ;) {
                String key = (String)(enum.nextElement());
                if (key.equalsIgnoreCase(attrName)) {
                    return (String)(attrs.get(key));
                }
            }
        }
        return null;
    }

    public Hashtable getAgentAttributes(Document configDoc, String agentName) {
        Hashtable result = new Hashtable();
        if (configDoc != null) {
            try {
                NodeList nodes = configDoc.getElementsByTagName("*");
                for (int i=0; i < nodes.getLength(); i++) {
                    Node node = nodes.item(i);
                    if ((node.getNodeType() == Node.ELEMENT_NODE) && (node.getNodeName().equalsIgnoreCase("agent"))) {
                        NamedNodeMap attrMap = node.getAttributes();
                        if (attrMap != null) {                            
                            Node x = attrMap.getNamedItem("name");
                            if ((x != null) && (x.getNodeType() == Node.ATTRIBUTE_NODE)) {
                                if (x.getNodeValue().equalsIgnoreCase(agentName)) {
                                    for (int j = 0; j < attrMap.getLength(); j++) {
                                        result.put(attrMap.item(j).getNodeName(),
                                                  attrMap.item(j).getNodeValue());
                                    }
                                    return result;
                                }
                            }
                        }
                    }
                }
            } catch (Throwable any) {
                logError("Exception in getAgentAttributes:", any);
            }
        }
        return result;  // will be empty
    }

    public String getServiceAttribute(Document configDoc, String attributeName) {
        if (configDoc != null) {
            try {
                NodeList nodes = configDoc.getElementsByTagName("*");
                for (int i=0; i < nodes.getLength(); i++) {
                    Node node = nodes.item(i);
                    if ((node.getNodeType() == Node.ELEMENT_NODE) &&
                        (node.getNodeName().equalsIgnoreCase("jade-service"))) {
                        NamedNodeMap attrMap = node.getAttributes();
                        if (attrMap != null) {
                            for (int j = 0; j < attrMap.getLength(); j++) {
                                if (attrMap.item(j).getNodeName().equalsIgnoreCase(attributeName)) {
                                    return attrMap.item(j).getNodeValue();
                                }
                            }
                        }
                    }
                }
            } catch (Throwable any) {
                // ignore
            }
        }
        return null;
    }

    /**
     * Set the value of a service attribute.
     * @param configDoc The XML document.
     * @param attributeName The name of the attribute.
     * @param newValue The attributes new value.
     * @return boolean True of success, false otherwise.
     */
    public boolean setServiceAttribute(Document configDoc, String attributeName, String newValue) {
        if (configDoc != null) {
            try {
                NodeList nodes = configDoc.getElementsByTagName("*");
                for (int i=0; i < nodes.getLength(); i++) {
                    Node node = nodes.item(i);
                    if ((node.getNodeType() == Node.ELEMENT_NODE) &&
                        (node.getNodeName().equalsIgnoreCase("jade-service"))) {
                        NamedNodeMap attrMap = node.getAttributes();
                        if (attrMap != null) {
                            for (int j = 0; j < attrMap.getLength(); j++) {
                                if (attrMap.item(j).getNodeName().equalsIgnoreCase(attributeName)) {
                                    attrMap.item(j).setNodeValue(newValue);
                                    return true;
                                }
                            }
                        }
                    }
                }
            } catch (Throwable any) {
                // ignore
            }
        }
        return false;
    }

    // This method extracts the information from the XML config doc
    // for this service and produces an array of strings.
    public String[] getInitializationArgs(Document configDoc, String attributeName) {
        return toStringArray(getServiceAttribute(configDoc, attributeName));
    }

    /**
     * Convert a String[] to a single String with elements separated
     * by a single space. The resultant string will have each of the
     * string array elements enclosed in quotes if it contains one or
     * one or more spaces.
     * @param args The String[] to be converted.
     * @return String representation of String[].
     */
    protected String fromStringArray(String[] args) {
        StringBuffer sb = new StringBuffer();
        if (args != null) {
            for (int i=0; i<args.length; i++) {
                sb.append(quoteIt(args[i]));
                if (i < args.length-1) {
                    sb.append(' ');
                }
            }
        }
        return sb.toString();
    }

    /**
     * If the string contains one or more spaces, enclose it
     * within quotes, "like this". If quoted then escape any
     * occurance of a quote with the escape sequence \".
     * @param theString The string to be quoted.
     * @return String modified with quotes and escape as necessary.
     */
    protected String quoteIt(String theString) {
        StringBuffer sb = new StringBuffer();
        boolean hasSpace = (theString.indexOf(' ') >= 0);
        for (int i=0; i<theString.length(); i++) {
            char c = theString.charAt(i);
            if ( (c == '"') && (hasSpace) )  {
                sb.append('\\');
            }
            sb.append(c);
        }
        return (hasSpace) ? "\"" + sb.toString() + "\"" : sb.toString();
    }

    /**
     * Convert the string representation of a String[] from
     * a single String to a new String[].
     * @param theString The string representation of the String[].
     * @return String[] The newly created String[].
     */
    protected String[] toStringArray(String theString) {
        Vector elements = new Vector();
        int i = 0;
        if (theString != null) {
            while ((i = findOpening(theString, i)) < theString.length()) {
                int j = findClosing(theString, i);
                if (j <= theString.length()) {
                    elements.add(unquoteIt(theString.substring(i, j)));
                }
                i = j+1;
            }
        }
        String[] results = new String[elements.size()];
        for (i=0; i<elements.size(); i++) {
            results[i] = (String)elements.elementAt(i);
        }             
        return results;
    }

    /**
     * Move our scanning index to the start of the next array element.
     * This would be the first non space.
     * @param theString The string representation of the String[].
     * @return The next starting index or beyond end if none.
     */
    protected int findOpening(String theString, int i) {
        while ( (i < theString.length()) && (theString.charAt(i) == ' ') ) {
            i++;
        }
        return i;
    }

    /**
     * Move our scanning index to the end of the next array element.
     * This would be the ending quote (if it is quoted) or first space.
     * If the item is quoted, it will ignore internal escaped quotes.
     * @param theString The string representation of the String[].
     * @return The end of the next element.
     */
    protected int findClosing(String theString, int i) {
        char stopChar = ' ';
        boolean quoted = false;
        if (theString.charAt(i) == '"') {
            quoted = true;
            stopChar = '"';
            i++;
        }
        int j = i;
        while (i == j) {
            // Advance i until we find stop char
            while ( (i < theString.length()) && (theString.charAt(i) != stopChar) ) {
                i++;
            }
            if (quoted) {
                if ( (i < theString.length()) && (theString.charAt(i) == '\\') ) {  // this is an escaped termination
                    i++;     // skip it
                    j = i;   // keep outer loop going
                }
            }
        }
        if (quoted) {
            i++;
        }
        return i;
    }

    /**
     * Remove enclosing quotes (if present) and internally escaped
     * quotes.
     * @param aValue The single string element.
     * @return String The result.
     */
    protected String unquoteIt(String aValue) {
        StringBuffer sb = new StringBuffer();
        int len = aValue.length();
        if (len > 0) {
            boolean quoted = ( aValue.startsWith("\"") && aValue.endsWith("\"") );
            int i = 0;
            if (quoted) {
                i++;
                len--;
            }
            
            while (i < len) {
                char c = aValue.charAt(i);
                if (quoted) {
                    if ( (c == '\\') && (i<len-1) ) {
                        char nextCh = aValue.charAt(i+1);
                        if (nextCh == '"') {
                            c = nextCh;
                            i++;
                        }
                    }
                }
                sb.append(c);
                i++;
            }
        }
        return sb.toString();
    }

    /**
     * Create and start a new agent.
     * @param agentName The name of the agent.
     * @param agentClass The fully qualified class name of the the agent.
     * @param args Agents arguments. Will be converted to String[]. To group
     * arguments use quotes.
     * @return 0(OK), -1(service not started), -2(agent name is null),
     *                -3(agent class is null), -4(exception starting agent)
     */
    public int createAgent(String agentName, String agentClass, String args) {
        if (state != STARTED) {
            logError("Service not started. Creation ignored");
            return -1;
        }
        if (agentName == null) {
            logError("Agent name is null.");
            return -2;
        }
        if (agentClass == null) {
            logError("Agent class is null.");
            return -3;
        }
        try {
            AgentController newAgent = thePlatform.createNewAgent(agentName, agentClass,
                                                                  toStringArray(args));
            logInfo(3, "Calling start on agent:" + agentName);
            newAgent.start();
            return 0;
        } catch (Throwable any) {
            logError("Exception starting agent", any);
            return -4;
        }
    }

    /**
     * Kill an agent.
     * @param agentName The name of the agent.
     * @return 0(OK), -1(service not started), -2(agent name is null),
     *                -3(invalid agent name), -4(unable to kill agent)
     */
    public int killAgent(String agentName) {
        if (state != STARTED) {
            logError("Service not started. Kill ignored");
            return -1;
        }
        if (agentName == null) {
            logError("Agent name is null.");
            return -2;
        }
        AgentController target = null;
        try {
            target = thePlatform.getAgent(agentName);
        } catch (Exception any) {
            logError("Invalid agent name:" + agentName);
            return -3;
        }
        try {
            target.kill();
            return 0;
        } catch (Exception any) {
            logError("Unable to kill agent:" + agentName);
            return -4;
        }
    }

    /**
     * Fetch the value of the "note" attribute.
     */
    public String getNote() {
        String message = getServiceAttribute(getConfigDoc(), "note");
        return (message == null) ? "" : message;
    }

    /**
     * Set the value of the "note" attribute.
     * This method is invoked by the ModelMBean when the JMX Agent is
     * asked to update this attribute.  In order to update
     * configuration information CSF will require an
     * implementation of the ConfigurationModifier interface.  Such
     * an implementation is provided within this method as an anonymous
     * inner class.  Note the compiler's requirement that the "message"
     * parameter be declared final.
     *
     * @param message
     */
    public void setNote(final String message) {
        setServiceAttribute(getConfigDoc(), "note", message);
    }

   /**
    * Get version info about this service.
    */ 
    public String getVersion() {
        return version;
    }


}
