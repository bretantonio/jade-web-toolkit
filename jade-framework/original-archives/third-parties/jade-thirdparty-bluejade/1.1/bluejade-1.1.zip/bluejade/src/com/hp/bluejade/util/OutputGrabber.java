/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.util;

import java.io.*;

/**
 * Used to capture data which is written directly to standard out
 * or standard err. An independent instance of this class will be
 * used on each output. Here are the steps required for usage:
 * <ol>
 * <li> Create the output grabbers. You can choose to use only
 * one grabber to capture either standard out or standard err;
 * or two if you wish to capture both. In this example, since we
 * are passing "this" to the OutputGrabber, the class containing
 * this code must implement the interface OutputGrabber.MessageWriter.
 * <pre>
 *      // Set up two data grabbers.
 *      // Passing false indicates that this grabber will not be
 *      // used for standard err. i.e. it will be used for standard out.
 *      OutputGrabber outGrabber = new OutputGrabber(this, false);
 *      // Passing true indicates this will be used for standard err.
 *      OutputGrabber errGrabber = new OutputGrabber(this, true);
 * </pre>
 * <li> Redirect one or both of the standard output streams.
 * <pre>
 *      // Need to wrap them in a PrintStream.
 *      System.setOut(new PrintStream(outGrabber));
 *      System.setErr(new PrintStream(errGrabber));        
 * </pre>
 * <li> To satisfy the interface OutputGrabber.MessageWriter the class
 * which was passed as the first argument to the OutputGrabber's constructor
 * must implement the following method:
 * <pre>
 *      /**
 *       * Called when a line of output is available.
 *       * @param isErr This is the same value as was passed as the
 *       * second argument to OutputGrabber's constructor. It is used
 *       * to seperate the standard out vs standard err grabbers.
 *       * @param aMessage The data.
 *       *&#47;
 *      public void writeMessage(boolean isErr, String aMessage) {
 *          if (isErr) {
 *              // do here what you wish with a line of standard err data
 *          } else {
 *              // do here what you wish with a line of standard out data
 *          }
 *      }
 * </pre>
 * <li> To ensure that all data is written when shutting down, call the
 * output grabbers close() method which will cause any remaining data
 * to be passed to the writeMessage method.
 * </ol>
 * @author Dick Cowan - HP Labs
 */
public class OutputGrabber extends OutputStream {

    /**
     * Classes which use OutputGrabber should implement this interface.
     */
    public static interface MessageWriter {
        /**
         * Called when a line of output is available.
         * @param isErr This is the same value as was passed as the
         * second argument to OutputGrabber's constructor. It is used
         * to seperate the standard out vs standard err grabbers.
         * @param aMessage The data.
         */
        public void writeMessage(boolean isErr, String aMessage);
    }

    MessageWriter writer;
    boolean isErrOutput;
    StringBuffer sb;
    
    /**
     * Construct a data grabber.
     * @param aWriter Class implementing the MessageWriter interface. This class
     * will call the writeMessage method when data is available.
     * @param isErr Used to seperate standard out vs standard err grabbers.
     */
    public OutputGrabber(MessageWriter aWriter, boolean isErr) {
        writer = aWriter;
        isErrOutput = isErr;
        sb = new StringBuffer();
    }        

    /**
     * Flush any data still in buffer. If any data is available, the
     * writeMessage method will be called.
     */
    public void close() {
        if (sb.length() > 0) {
            writer.writeMessage(isErrOutput, sb.toString());
        }
        try {
            super.close();
        } catch (IOException ioe) {
            // ignore
        }
    }
                       
    /**
     * Called with each byte of output. CR's will be ignored;
     * LF's will cause output by calling the writeMessage method;
     * all other characters will be captured in buffer.
     * @param b The single byte to be written.
     */ 
    public void write(int b) {
        char ch = (char)b;
        if (ch == '\n') {  // LF
            if (sb.length() > 0) {
                writer.writeMessage(isErrOutput, sb.toString());
                sb.setLength(0);
            }
        } else {
            if (ch == '\r') { // CR
                // ignore it
            } else {
                sb.append(ch);  // everything else into buffer
            }
        }
    }
}

