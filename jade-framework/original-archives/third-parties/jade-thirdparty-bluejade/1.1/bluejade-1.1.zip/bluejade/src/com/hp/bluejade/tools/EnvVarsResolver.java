/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.tools;

import java.io.*;

import jade.util.BasicProperties;
import jade.util.ExpandedProperties;

/**
 * Environment variable resolver - replaces all occurances of ${XXX} with
 * the environment variable value of XXX. Reads standard in, writes standard
 * out.
 * @author Michael Li, Dick Cowan, Martin Griss (added special properties: CR, SP, EM)
 */
public class EnvVarsResolver {
    
    boolean allowUndefined=false;
    PrintStream output;
    BasicProperties props = null;

    public static void main(String[] args) {
        try {
            new EnvVarsResolver(new ExpandedProperties(args));
        } catch (Exception any) {
            System.err.println("EnvVarsResolver exception:" + any);
            any.printStackTrace(System.err);
            System.exit(-1);
        }
        
    }      
 
    public EnvVarsResolver(BasicProperties aProp) throws FileNotFoundException, IOException {
        props = aProp;        
        // Define special characters if they aren't already
        props.setPropertyIfNot("EM", "");
        props.setPropertyIfNot("SP", " ");
        props.setPropertyIfNot("CR", System.getProperties().getProperty("line.separator"));
        props.setPropertyIfNot("CM", "#");
        
        // pick up arguments
        
        allowUndefined = props.getBooleanProperty("allow", false);
        
        String inputName = props.getProperty("in", null);
        String outputName = props.getProperty("out", null);

        if (props.getBooleanProperty("help", false)) {
            printUsage();
        }
                
        output = null;
        if (outputName == null) {
            output = System.out;
        } else {
            output = new PrintStream(new FileOutputStream(outputName, false));
        }
            
        processInput(inputName);            
            
        output.close();
    }
    
   /**
    * Process one level of inputName file
    */
    protected void processInput(String inputName) throws FileNotFoundException, IOException {
        BufferedReader in = null;
        if (inputName == null) {
            in = new BufferedReader(new InputStreamReader(System.in));
        } else {
            in = new BufferedReader(new FileReader(inputName));
        }
        
        String line;
        //while ((line = in.readLine()) != null) {
        // Should handle CRLF correctly on WIN and Unix
        while ((line = getOneLine(in)) != null) {
        	String newline=props.doSubstitutions(line, allowUndefined);
        	String includer="include=";
        	if (newline.startsWith(includer)) {
            	String newInputName=newline.substring(includer.length());
            	System.out.println("   including: " + newInputName);
        	    processInput(newInputName);
            } else {
                output.println(newline);
            }
        }
    }

    boolean CRState = false;
  
    /**
     * Get a logical line. Any physical line ending in '\' is considered
     * to continue on the next line.
     * @param reader The input reader to read.
     * @return The resultant logical line which may have been constructed
     * from one or more physical lines.
     * @throws IOException if anything goes wrong.
     */
    protected String getOneLine(Reader reader) throws IOException {
        StringBuffer sb = null;
        String line = null;
        boolean continued;

        do {
            continued = false;

            try {
                line = readLine(reader);
                
                if (line != null) {
                    line = line.trim();

                    if ((sb != null) 
                            && ((line.startsWith("#")
                                 || line.startsWith("!")))) {
                        continued = true;

                        continue;
                    }

                    continued = line.endsWith("\\");

                    if (continued) {    // delete the ending slash
                        line = line.substring(0, line.length() - 1);
                    }
                    if (sb == null) {
                        sb = new StringBuffer();
                    }
                    sb.append(line);
                }
            } catch (EOFException eof) {
                continued = false;
            }
        } while (continued);

        return (sb == null) ? null : sb.toString();
    }

    /**
     * Read one line from the Reader. A line may be terminated
     * by a single CR or LF, or the pair CR LF.
     * @param aReader The Reader to read characters from.
     * @return Next physical line.
     * @throws IOException if anything goes wrong.
     */
   protected String readLine(Reader aReader) throws IOException {
        StringBuffer sb = new StringBuffer();
        // String CRState=false; ??
        boolean done = false;
        while (!done) {
            int result = aReader.read();
            if (result == -1) {
                if (sb.length() > 0) {
                    break;
                }
                throw new EOFException();
            } else {
                char ch = (char)result;
                if (ch == '\n') {  // LF
                    if (CRState) {
                        CRState = false;
                        continue;                  
                    }
                    break;
                } else {
                    if (ch == '\r') {
                        CRState = true;
                        break;
                    } else {
                        sb.append(ch);
                        CRState = false;
                    }
                }
            }
        }
        return sb.toString();
    }        
    
    /**
     * print usage instructions
     */
    private static void printUsage() {
        System.out.println("EnvVarsResolver is used to resolve environment variable references.");
        System.out.println("These are any string of the form of ${XXX}, where XXX");
        System.out.println("is the name of the environment variable.");
        System.out.println("Reads standard input, writes standard output.");
        System.out.println("Usage: java EnvVarsResolver [options]");
        System.out.println("where options include:");
        System.out.println("  -allow To allow undefined variables to pass through.");
        System.out.println("  in:file_name The name of the input file.");
        System.out.println("     If missing standard in will be read.");
        System.out.println("  out:file_name The name of the output file.");
        System.out.println("     If missing standard out will be written.");
        System.out.println("  import:file_name Property file to import first so as");
        System.out.println("     to be able to resolve definitions. Often same as input.");
        System.exit(1);
    }
}
