/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.service;

import jade.wrapper.AgentController;

/**
 * Interface definition for Jade Services.
 * JMX MBean interfaces extend this interface so only place
 * methods you wish exposed here.
 * @author Dick Cowan - HP Labs
 */
public interface JadeServiceInterface {

   /**
    * Get version info about this service.
    */ 
    public String getVersion();

   /**
    * Set the JNDI name under the java:/ namespace to which this service 
    * is bound.
    * @param aName The JNDI name.
    */
    public void setJNDIName(final String aName);

   /**
    * Get the JNDI name under the java:/ namespace to which this service 
    * is bound.
    * @return The JNDI name.
    */
    public String getJNDIName();

    /**
     * Set file name of the configuration document.
     * @param aName The name of the file.
     */
    public void setConfigDocName(final String aName);
    
    /**
     * Get the file name of the configuration document.
     * @return The name of the file.
     */
    public String getConfigDocName();

    /**
     * Fetch the value of the note attribute.
     */
    public String getNote();
    
    /**
     * Set the value of the note attribute.
     */
    public void setNote(final String message);
    
    /**
     * Create and start a new agent.
     * @param agentName The name of the agent.
     * @param agentClass The fully qualified class name of the the agent.
     * @param args Agents arguments. Will be converted to String[]. To group
     * arguments use quotes.
     * @return 0(OK), -1(service not started), -2(agent name is null),
     *                -3(agent class is null), -4(exception starting agent)
     */
    public int createAgent(String agentName, String agentClass, String args);
    
    /**
     * Kill an agent.
     * @param agentName The name of the agent.
     * @return 0(OK), -1(service not started), -2(agent name is null),
     *                -3(invalid agent name), -4(unable to kill agent)
     */
    public int killAgent(String agentName);
}
