/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package com.hp.bluejade.agent;

import java.util.*;
import java.io.*;

import jade.core.*;
import jade.util.BasicProperties;
import jade.util.ExpandedProperties;

/**
 * This class provides a base class for all agents by providing common, useful
 * functionality.
 */
public class CoolAdapter extends Agent {

    private BasicProperties properties = null;
    private ThreadGroup myGroup = null;
    private int infoLevel = 3;

    /**
     * Check if the current thread is really an agent thread.
     * Check is based on thread having same thread group as the one
     * created by the agent container for all its agents.
     * @return True if it is, false otherwise.
     */
    public boolean isAgentThread() {
        return ( (myGroup != null) && (Thread.currentThread().getThreadGroup().equals(myGroup)) );
    }

    /**
     * Sets the agents properties.
     * @param aProperties The properties to be used.
     */
    public void setProperties(BasicProperties aProperties) {
        properties = aProperties;
    }

    /**
     * Returns the agents properties.
     * If called and the properties are null, they will be initialized from
     * the properties file named "com/hp/bluejade/agent/setup.properties"
     * located as a resource by the same class loader which loaded this class.
     * In other words, check for the presence of that property file in
     * the jar and initialize from it if its found.
     */
    public BasicProperties getProperties() {
        if (properties == null) {
            // Initialize properties using default.
            String defaultPropName = "com/hp/bluejade/agent/setup.properties";
            properties = new ExpandedProperties();
            InputStream propertyStream = this.getClass().getClassLoader().getResourceAsStream(defaultPropName);
            if (propertyStream != null) {
                try {
                    properties.load(propertyStream);
                } catch (IOException ioe) {
                    printError("Error reading:" + defaultPropName);
                    System.exit(-1);
                }
            }
        }
        return properties;
    }

    /**
     * Jade calls this method on startup so we use it to initialize the
     * agents properties. If the properties contain "dump=true", the properties
     * will be listed to standard out.
     */
    protected void setup() {
        myGroup = Thread.currentThread().getThreadGroup();
        Object[] args = getArguments();  // JADE's getArguments
        if (args != null) {
            int len = args.length;
            String sargs[] = new String[len];
            for (int i=0;i<len;i++) {
                sargs[i] = args[i].toString();
            }
            ExpandedProperties newProperties = new ExpandedProperties();
            newProperties.copyProperties(getProperties());
            newProperties.parseArgs(sargs);
            setProperties(newProperties);
        }
        if (getProperties().getBooleanProperty("dump", false)) {
            System.out.println("----- " + getLocalName() + "'s properties:");
            getProperties().list(System.out);
            System.out.println("----- end of properties -----");
        }
        infoLevel = getProperties().getIntProperty("infoLevel", 2);
    }

    /**
     * Jade calls this method as part of agent termination.
     */
    protected void takeDown() {
        // Nothing currently needs to be done
        super.takeDown();  // just in case this class doesn't directly extend Agent.
    }

    /**
     * Returns level which controls which information messages are displayed.
     * The desired levels are as follows:
     * <pre>
     * 0 = Silent - show nothing.
     * 1 = Show only level 1 messages. These are major events which
     *     should be displayed in all demos.
     * 2 = Show level 1 and 2 messages. Level 2 messages are suitable
     *     for technical demonstrations.
     * 3 = Show level 1, 2, and 3 messages. Level 3 messages are suitable
     *     for demonstrations to programmers or detailed tracing.
     * </pre>
     * @return The current setting.
     */
    public int getInfoLevel() {
        return infoLevel;
    }

    /**
     * Sets level which controls which information messages are displayed.
     * @param aLevel The desired level.
     */
    public void setInfoLevel(int aLevel) {
        infoLevel = aLevel;
    }

    /**
     * Print a informational message depending on the desired info level.
     * @param aLevel The level of this message.
     * @param aMsg The message.
     */
    public void printInfo(int aLevel, String aMsg) {
        if (infoLevel >= aLevel) {
            System.out.println(getLocalName() + ":" + aMsg);
        }
    }

    /**
     * Print error message.
     * @param aMsg The error message.
     */
    public void printError(String aMsg) {
        System.err.println(getLocalName() + ":" + aMsg);
    }
}
