/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.service.jboss;

import com.hp.bluejade.service.LogInterface;

import org.jboss.logging.Logger;  // JBOSS_HOME/lib/jboss-common.jar

/**
 * Capture and format raw println's to conform to same format
 * as the HPAS log.
 * @version 1.00
 * @author Dick Cowan - HP Labs
 */
public class JBossLogger implements LogInterface {

    Logger log = null;
    
    public JBossLogger(Logger theLog) {
        log = theLog;
    }
        
    /**
     * Close the logger. Decrements its use count and if zero, close
     * the output grabbers, and restore System.out and System.err.
     */
    public void close() {
    }

    public void logInfo(String aMessage) {
        log.info(aMessage);
    }
    
    /**
     * Log an error. If CSF log channel exits, use it otherwise output to System.err.
     * @param aMethodName The name of the method containing the call.
     * @param aMessage The message to be logged.
     */
    public void logError(String aMessage) {
        log.error(aMessage);
    }

    public void logError(String aMessage, Throwable anError) {
        log.error(aMessage, anError);
    }
}
