/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.service.jboss;

import javax.naming.InitialContext;
import javax.naming.Reference;
import javax.naming.StringRefAddr;
import javax.naming.Name;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.NameNotFoundException;

import org.jboss.system.ServiceMBeanSupport;       // JBOSS_HOME/lib/jboss-system.jar
import org.jboss.naming.NonSerializableFactory;    // JBOSS_HOME/server/all/lib/jboss.jar

import jade.wrapper.*;

import com.hp.bluejade.service.JadeServiceSupport;

/**
 * Implementation to enable the management of JADE by JBoss.
 * Provides the ability to manage the <a href="http://sharon.cselt.it/projects/jade/">JADE</a>
 * (Java Agent DEvelopment Framework) using <a href="http://www.jboss.org/">JBoss Application Server</a>.
 *
 * @author Dick Cowan - HP Labs
 */
public class JadeService extends ServiceMBeanSupport
    implements
        JadeServiceMBean

{
    public static final String THIS_CLASS = JadeService.class.getName();

    JadeServiceSupport service = null;
    protected String m_bindName;
    protected Context m_context = null;
        
    /**
     * Construct service instance. Creates empty command line properties
     * collection.
     */
    public JadeService() throws Exception {
        service = new JadeServiceSupport();
        service.setLogger(new JBossLogger(log));
    }

    /**
     * Set file name of the configuration document.
     * @param aName The name of the file.
     */
    public void setConfigDocName(final String aName) {
        service.setConfigDocName(aName);
    }

    /**
     * Get the file name of the configuration document.
     * @return The name of the file.
     */
    public String getConfigDocName() {
        return service.getConfigDocName();
    }

   /**
    * Set the JNDI name under the java:/ namespace to which this service 
    * is bound.
    * @param aName The JNDI name.
    */
    public void setJNDIName(final String aName) {
        service.setJNDIName(aName);
    }

   /**
    * Get the JNDI name under the java:/ namespace to which this service 
    * is bound.
    * @return The JNDI name.
    */
    public String getJNDIName() {
        return service.getJNDIName();
    }

    public String getName() {
        return service.getName();
    }

    /**
     * Get the JADE platform controller.
     * @return The platform controller - may be null.
     */
    public PlatformController getPlatformController() {
        return service.getPlatformController();
    }

    /**
     * Initializes the agent container and associated facilities.
     */
    protected void createService() throws Exception {
        service.initService();
    }

    protected void destroyService() {
    }
    
    /**
     * Will be invoked by CSF to notify that service that it should perform its startup processing.
     * The framework prior to invoking this method will set the state of this service to STARTING.
     * If this method complete without throwing and exception the service's state will be set to RUNNING.
     * <p>
     * Required by Animatable (Startable) interface.
     * @throws Exception Bind failed.
     */
    protected void startService() throws Exception {
        service.startService();
        bind(this);
    }

    /**
     * Will be invoked by CSF to notify this service that it should transition from its current
     * state which will always be RUNNING. Prior to invoking this method CSF will set this services
     * states to STOPPING. When this method successfully completes CSF will set the service's state
     * to STOPPED. If an exception is thrown by this method CSF will set the state of this
     * service to FAILED.
     * <p>
     * Required by Animatable (Stoppable) interface.
     * @throws ServiceException Allows any exceptions encountered to be returned to CSF.
     */
    protected void stopService() {
        // Unbind from JNDI
        try {
            unbind();
        } catch (NamingException x) {
            service.logError("Unbind failure", x);
        }
        service.stopService();
    }


    public int createAgent(String agentName, String agentClass, String args) {
        return service.createAgent(agentName, agentClass, args);
    }

    public int killAgent(String agentName) {
        return service.killAgent(agentName);
    }

    /**
     * Fetch the value of the "note" attribute.
     */
    public String getNote() {
        return service.getNote();
    }

    /**
     * Set the value of the "note" attribute.
     * This method is invoked by the ModelMBean when the JMX Agent is
     * asked to update this attribute.  In order to update
     * configuration information CSF will require an
     * implementation of the ConfigurationModifier interface.  Such
     * an implementation is provided within this method as an anonymous
     * inner class.  Note the compiler's requirement that the "message"
     * parameter be declared final.
     *
     * @param message
     */
    public void setNote(String message) {
        service.setNote(message);
    }

    public String getVersion() {
        return service.getVersion();
    }

    void bind(JadeServiceMBean jadeService) throws NamingException {
        if (service.isStandAlone()) {
            return;
        }
        Context ctx = new InitialContext();
        String name = getJNDIName();
        if (name == null) {
            name = "java:/JADE";
        } else if (!name.startsWith("java:/")) {
            name = "java:/" + name;
        }
        m_bindName = name;
      
        // Ah ! Session isn't serializable, so we use a helper class
        NonSerializableFactory.bind(m_bindName, jadeService);
      
        Name n = ctx.getNameParser("").parse(m_bindName);
        while (n.size() > 1) {
            String ctxName = n.get(0);
            try {
                ctx = (Context)ctx.lookup(ctxName);
            } catch (NameNotFoundException e) {
                ctx = ctx.createSubcontext(ctxName);
            }
            n = n.getSuffix(1);
        }
      
        // The helper class NonSerializableFactory uses address type nns, we go on to
        // use the helper class to bind the javax.mail.Session object in JNDI
        StringRefAddr addr = new StringRefAddr("nns", m_bindName);
        Reference ref = new Reference(THIS_CLASS, addr, NonSerializableFactory.class.getName(), null);
        ctx.bind(n.get(0), ref);
        m_context = ctx;      
        service.logInfo(1, "Service '" + getJNDIName() + "' bound to " + m_bindName);
    }
   
    void unbind() throws NamingException {
        if (m_bindName != null) {
            new InitialContext().unbind(m_bindName);
            NonSerializableFactory.unbind(m_bindName);
            service.logInfo(1, "Service '" + getJNDIName() + "' removed from JNDI");
        }
    }

}
