/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

package com.hp.bluejade.tools;

import java.io.*;
import java.util.StringTokenizer;
import java.util.Enumeration;
import java.util.Vector;

import org.w3c.dom.*;
import org.w3c.dom.traversal.*;
import javax.xml.parsers.*;

import jade.util.ExpandedProperties;
import jade.util.BasicProperties;

/**
 * Adds entries from an update XML file to an existing XML file, producing a new XML file.
 * <pre>
 *  Usage: java com.hp.bluejade.tools.XMLUpdater in:in-file update:update-file out:out-file node:node-name
 *         [encoding:name] [indent:spaces] [verbose:verbosity]
 *  where:
 *    in-file Is the name of the existing XML file which you wish to update.
 *    update-file Is the name of the XML file containing the updates.
 *    out-file Is the name of the newly creates XML file which will be the in-file plus the updates.
 *    encoding Optional encoding name. Default is UTF-8.
 *    spaces Number of spaces to indent when producing output with nested levels. Default is 3.         
 *    verbosity setting
 *        0 => silent (default)
 *        1 => Major status only
 *        2 => full details
 *        3 => Details & debugging information
 *
 * </pre>
 * @version 1.00, 04-MAR-2002
 * @author Dick Cowan - HP Labs
 */
public class XMLUpdater {

    private static String PRINTWRITER_ENCODING = "UTF8";
    protected PrintWriter out = null;;
    int indent = 3;
    int verbose = 0;
    String encoding = null;
    BasicProperties props = null;
    boolean allowUndefined = false;
    Document originalDocument = null;
    Document updateDocument = null;    
    /**
     * Main application driver.
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        ExpandedProperties props = new ExpandedProperties(args);

        if ((args.length == 0) || (props.getBooleanProperty("help", false))) {
            System.out.println("Usage: java com.hp.bluejade.tools.XMLUpdater original:file update:file out:file node:name [attrigure:value]");
            System.exit(-1);
        }
        new XMLUpdater(props);
    } 

    /**
     * Constructor.
     * @param aPropertyCollection Configuration properties.
     */
    public XMLUpdater(BasicProperties aPropertyCollection) {
        props = aPropertyCollection;
        allowUndefined = props.getBooleanProperty("allow", false);
        String originalName = props.getProperty("in");
        String updateName = props.getProperty("update");

        String outputName = props.getProperty("out");
        indent = props.getIntProperty("indent", 3);
        verbose = props.getIntProperty("verbose", 0);
        encoding = props.getProperty("encoding");
        if ( encoding == null ) {
            encoding = "UTF-8";
        } else {
            if (encoding.equalsIgnoreCase("unicode")) {
                encoding = "UTF-16";
            }
        }
        try {
            if (outputName == null) {
                out = new PrintWriter(new OutputStreamWriter(System.out, encoding));
            } else {
                out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(outputName), encoding));
            }

        } catch (Exception any) {
            System.err.println("Exception while creating output: " + any);
            any.printStackTrace(System.err);
            System.exit(-1);
        }

        originalDocument = getDocument(originalName);
        updateDocument = getDocument(updateName);
        
        update();
        print(originalDocument);
    }

    Document getDocument(String originalName) {
        Document result = null;
        try {
            // Step 1: create a DocumentBuilderFactory and setNamespaceAware
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);

            // Step 2: create a DocumentBuilder
            DocumentBuilder db = dbf.newDocumentBuilder();

            // Step 3: parse the input file to get a Document object
            result = db.parse(originalName);
        } catch (Exception any) {
            System.err.println("Exception loading:" + originalName);
            any.printStackTrace(System.err);
            System.exit(-1);
        }
        return result;
    }

    /**
     * Update the original document usingt the update document.
     * @param original Original document.
     * @param updates Update document.
     */
    protected void update() {
        Element originalElement = originalDocument.getDocumentElement();
        Element updateElement = updateDocument.getDocumentElement();
        if (!updateElement.getNodeName().equalsIgnoreCase(originalElement.getNodeName())) {
            System.err.println("Top level items do not match.");
            System.exit(-1);
        }
        updateElement(originalElement, updateElement);
    }

    protected void updateElement(Element original, Element update) {
        if (verbose >= 3) {
            System.out.println("update Original element:" + original.getNodeName() + " Update element:" + update.getNodeName());        
        }
        NodeList updateNodes = update.getChildNodes();
        if (updateNodes != null) {
            for ( int i = 0; i < updateNodes.getLength(); i++ ) {
                Node updateNode = updateNodes.item(i);
                if (updateNode.getNodeType() == Node.ELEMENT_NODE) {
                    if (verbose >= 3) {
                        System.out.println("updateNode name=" + updateNode.getNodeName());
                    }
                    Node originalNode = findExistingNode(original, (Element)updateNode);
                    if (originalNode == null) {
                        if (verbose >= 1) {
                            System.out.println("Appending new node");
                        }
                        Node newNode = originalDocument.importNode(updateNode, true);  // true => deep clone ie all substructure
                        original.appendChild(newNode);
                    } else {
                        if (originalNode.hasChildNodes()) {
                            updateElement((Element)originalNode, (Element)updateNode);
                        } else {
                            if (verbose >= 1) {
                                System.out.println("Replacing node");
                            }
                            Node newNode = originalDocument.importNode(updateNode, true);  // true => deep clone ie all substructure
                            original.replaceChild(newNode, originalNode);
                        }
                    }
                }
            }
        }
    }

    /**
     * Search the original document for a node whose type and name is the same, then perform attribute match.
     * @param originalTop Top element of the original document.
     * @param updateElement The update element from the update document.
     * @return Node in original document if found, null otherwise.
     */
    protected Node findExistingNode(Element original, Element update) {
        if (verbose >= 3) {
            System.out.println("Find node: " + update.getNodeName());
        }
        NodeList nodes = original.getChildNodes();
        if ((nodes != null) && (nodes.getLength() > 0)) {
            int len = nodes.getLength();
            for ( int i = 0; i < len; i++ ) {
                Node node = nodes.item(i);
                if ( (node.getNodeType() == update.getNodeType()) && 
                     (node.getNodeName().equalsIgnoreCase(update.getNodeName())) ) {
                    if (verbose >= 3) {
                        System.out.println("Node match:" + node.getNodeName());
                    }
                    if (attributesMatch((Element)node, update)) {
                        return node;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check if all those attributes defined on the update element match those on the original.
     * @param originalElement Candidate element of the original document.
     * @param updateElement The update element from the update document.
     * @return True if all attributes match, false otherwise.
     */
    protected boolean attributesMatch(Element originalElement, Element updateElement) {
        if (!updateElement.hasAttributes()) {
            if (verbose >= 3) {
                System.out.println("Update element doesn't have attributes - hence match.");
            }
            return true;
        }
        if (originalElement.hasAttributes()) {
            // Check that all those attributes specified in the update element match the original.
            for (Enumerator enum =  getAttributes(updateElement.getAttributes()); enum.hasMoreElements() ;) {
                Attr attr = (Attr)enum.nextElement();
                String attributeName = attr.getNodeName();
                String attributeValue = normalize(attr.getNodeValue());
                if (originalElement.hasAttribute(attributeName)) {
                    if (attributeValue.equals(normalize(originalElement.getAttribute(attributeName)))) {
                        if (verbose >= 3) {
                            System.out.println("Attribute:" + attributeName + " matches");
                        }
                        continue;
                    } else {
                        if (verbose >= 3) {
                            System.out.println("Attribute:" + attributeName + " doesn't match");
                        }
                        return false;
                    }
                } else {
                    return false;
                }
            }                
            if (verbose >= 3) {
                System.out.println("All attributes match!");
            }
            return true;
         }
         return false;
    }

    /**
     * Print a document.
     * @param aDoc The document to be printed.
     */
    protected void print(Document aDoc) {        
        out.println("<?xml version=\"1.0\" encoding=\""+ encoding + "\"?>");
        Element element = aDoc.getDocumentElement();
        print(element, 0);
    }

    
    /**
     * Print a node. Recurses on element nodes.
     * @param node The node to be printed.
     * @param depth Used to control indentation spacing.
     */
    protected void print(Node node, int depth) {

        boolean openNode = false;
        // is there anything to do?
        if ( node == null ) {
            return;
        }
        int type = node.getNodeType();
        String data = null;
        if (type == Node.TEXT_NODE) {
            data = node.getNodeValue();
            if (data == null) {
                return;
            }
            data = data.trim();
            if (data.length() == 0 ) {
                return;
            }
        }

        indent(depth);
        switch ( type ) {
            // print simple value
            case Node.TEXT_NODE: {
                out.println(environmentSubstitution(data));
                break; 
            }
            // print document
            case Node.DOCUMENT_NODE: {

                out.println("<?xml version=\"1.0\" encoding=\""+
                                encoding + "\"?>");
                //print(((Document)node).getDocumentElement());

                NodeList children = node.getChildNodes();
                for ( int iChild = 0; iChild < children.getLength(); iChild++ ) {
                    print(children.item(iChild), depth+1);
                }
                out.flush();
                break;
            }

            // print element with attributes
            case Node.ELEMENT_NODE: {
                out.print('<');
                String nodeName = node.getNodeName();
                int nodeNameLength = nodeName.length();
                out.print(nodeName);
                for (Enumerator enum =  getAttributes(node.getAttributes()); enum.hasMoreElements() ;) {
                    Attr attr = (Attr)enum.nextElement();
                    if (enum.isFirst()) {
                        out.print(" ");
                    } else {
                        indent(depth);
                        for (int i = 0; i < nodeNameLength+2; i++) {  // 2 is for < and space
                            out.print(" ");
                        }
                    }                       
                    out.print(attr.getNodeName());
                    out.print("=\"");
                    out.print(normalize(attr.getNodeValue()));
                    out.print('"');
                    if (!enum.isLast()) {
                        out.println();
                    }
                }
                NodeList children = node.getChildNodes();
                openNode = ((children != null) && (children.getLength() > 0));
                if (openNode) {
                    out.println('>');
                } else {
                    out.println("/>");
                }
                if (openNode) {
                    int len = children.getLength();
                    for ( int i = 0; i < len; i++ ) {
                        print(children.item(i), depth+1);
                    }
                }
                break;
            }

            // handle entity reference nodes
            case Node.ENTITY_REFERENCE_NODE: {
                    out.print('&');
                    out.print(node.getNodeName());
                    out.println(';');
                break;
            }

            // print cdata sections
            case Node.CDATA_SECTION_NODE: {
                    out.print("<![CDATA[");
                    out.print(environmentSubstitution(node.getNodeValue()));
                    out.println("]]>");
                break;
            }

            // print processing instruction
            case Node.PROCESSING_INSTRUCTION_NODE: {
                out.print("<?");
                out.print(node.getNodeName());
                data = node.getNodeValue();
                if ( data != null && data.length() > 0 ) {
                    out.print(' ');
                    out.print(environmentSubstitution(data));
                }
                out.println("?>");
                break;
            }
            case Node.COMMENT_NODE: {
                out.print("<!-- ");
                out.print(node.getNodeValue());
                out.println(" -->");
                break;
            }
            default: {
                out.println("<!-- Unhandled node type:" + type + " -->");
            }
        }

        if (openNode) {
            indent(depth);
            out.print("</");
            out.print(node.getNodeName());
            out.println('>');
        }
        out.flush();

    } // print(Node)


    /**
     * Replaced any environment variables with their value.
     * @param data String possibly containing ${XXX} strings.
     * @return String with substitutions done.
     */
    protected String environmentSubstitution(String data) {
        return props.doSubstitutions(data, allowUndefined);
    }

    /**
     * Generate an enumerator for walking all the attributes of an element.
     * If the property "sorted" is true they will be returned in sorted order.
     * @param attributeMap Used to access all the attributes.
     * @return Enumerator to attributes.
     */
    protected Enumerator getAttributes(NamedNodeMap attributesMap) {
        Vector sortVector = new Vector();
        int len = (attributesMap != null) ? attributesMap.getLength() : 0;
        int j;
        for ( int i = 0; i < len; i++ ) {
            Attr attribute = (Attr)attributesMap.item(i);
            if (props.getBooleanProperty("sorted", false)) {
                String attributeName = attribute.getNodeName();
                j = 0;
                while (j < sortVector.size()) {
                    if (attributeName.compareTo(((Attr)sortVector.elementAt(j)).getNodeName()) < 0) {
                        break;
                    }
                    j++;
                }
                sortVector.insertElementAt(attribute, j);
            } else {
                sortVector.add(attribute);
            }
        }
        // Place special attributes first (in same order as they are defined in property)
        int headIndex = 0;
        String attributeList = props.getProperty("attribute");
        if (attributeList != null) {
            StringTokenizer parser = new StringTokenizer(attributeList);
            while (parser.hasMoreTokens()) {
                String attributeName = parser.nextToken();
                j = 0;
                while (j < sortVector.size()) {
                    if (attributeName.compareTo(((Attr)sortVector.elementAt(j)).getNodeName()) == 0) {
                        sortVector.add(headIndex++, sortVector.remove(j));
                        break;
                    }
                    j++;
                }
            }
        }                
        return new Enumerator(sortVector);
    } 

    class Enumerator implements Enumeration {
        Enumeration enum = null;
        int fetched = 0;

        Enumerator(Vector data) {
            enum = data.elements();
        }
        
        public boolean hasMoreElements() {
            return enum.hasMoreElements();
        } 

        public Object nextElement() {
            fetched++;
            return enum.nextElement();
        }
        
        public boolean isFirst() {
            return (fetched == 1);
        }
        
        public boolean isLast() {
            return (!enum.hasMoreElements());
        }
    }        

    protected String normalize(String s) {
        StringBuffer str = new StringBuffer();
        s = environmentSubstitution(s);
        int len = (s != null) ? s.length() : 0;
        for ( int i = 0; i < len; i++ ) {
            char ch = s.charAt(i);
            switch ( ch ) {
            case '<': {
                    str.append("&lt;");
                    break;
                }
            case '>': {
                    str.append("&gt;");
                    break;
                }
            case '&': {
                    str.append("&amp;");
                    break;
                }
            case '"': {
                    str.append("&quot;");
                    break;
                }
            case '\'': {
                    str.append("&apos;");
                    break;
                }
            case '\r':
            case '\n': {
                    // else, default append char
                }
            default: {
                    str.append(ch);
                }
            }
        }

        return(str.toString());

    }

    protected void indent(int depth) {
        depth *= indent;
        for (int i=0; i < depth; i++) {
            out.print(" ");
        }
    }

}

