#!/bin/sh
# passed parameters: $GROUP $SOURCE_DIR $TARGET_DIR $INSTALL_LOG
group=$1
source_dir=$2
target_dir=$3
log=$4
if [ -d $source_dir/webapps ] ; then
    current_dir=`pwd`
    echo Creating $group.war file.
    if [ -d $TEMP/WEB-INF ] ; then
        rm -rf $TEMP/WEB-INF
    fi
    mkdir -p $TEMP/WEB-INF/lib
    cp $BLUEJADE_HOME/lib/bluejade.jar $TEMP/WEB-INF/lib >> $log
    jar -cf $source_dir/deploy/$group.war -C $TEMP WEB-INF >> $log
    cd $source_dir/webapps
    for I in * ;
    do
        jar -uf $source_dir/deploy/$group.war $I >> $log
    done
    cd $current_dir
fi
