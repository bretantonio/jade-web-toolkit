/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.util.*;
import java.sql.*;
import java.text.*;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.FIPAException;

import com.hp.bluejade.agent.CoolAdapter;

/**
 * Agent which repeatedly sends a QUERY_REF message to Receiver.
 * This class extends CoolAdapter to illustrate usage of properties.
 * The Sender agent just extends Jade Agent.
 */
public class Sender extends CoolAdapter {

    int delaySeconds;

    class MyBehaviour extends CyclicBehaviour {

        public MyBehaviour( Agent a ) {
            super(a);
        }

        public void action() {

            ACLMessage msg = new ACLMessage(ACLMessage.QUERY_REF);
        	AID receiverAID = new AID("receiver", AID.ISLOCALNAME);

        	msg.setSender(getAID());
        	msg.addReceiver(receiverAID);
        	msg.setProtocol("fipa-request");

        	int i = 0;
            String message;
            ACLMessage response;
            while (true) {
                i++;
                msg.setContent("message " + i);

            	printInfo(2, "Sending message " + i);

            	send(msg);

            	response = blockingReceive();
                message = response.getContent().toString();
                printInfo(2, "Received:" + message);

                doWait(delaySeconds * 1000);
            }
        }
    }

    /** The <CODE>setup()</CODE> method is called by the agent container as part
     * of the the agent intialization. This method will first call setup() in
     * CoolAdapter which will initialize the agent's properties.
     */
    protected void setup() {
        super.setup();
        delaySeconds = getProperties().getIntProperty("delay", 10);
        printInfo(1, "Delay seconds:" + delaySeconds);

        MyBehaviour b = new MyBehaviour(this);
        addBehaviour(b);
        System.out.println("Agent "+getLocalName()+" is running.");
    }

}
