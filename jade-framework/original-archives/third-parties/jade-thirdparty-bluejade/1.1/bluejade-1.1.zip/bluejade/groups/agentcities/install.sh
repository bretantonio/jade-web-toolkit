#!/bin/sh
canonical() {
   p=$1
   echo $1 | grep "^/" >/dev/null
   if [ $? -gt 0 ] ; then
      p=`pwd`/$1
   fi
   echo $p;
}

mydir=`dirname $0`
GROUPDIR=`canonical $mydir`
if [ -z "$BLUEJADE_HOME" ] ; then
    echo "The environment variable BLUEJADE_HOME is not set."
    exit 1
fi

if [ ! "$1" ] ; then
    echo You must specify the name of the existing configuration directory.
fi

cd $GROUPDIR
. $BLUEJADE_HOME/bin/unix/install.sh $GROUPDIR $*
