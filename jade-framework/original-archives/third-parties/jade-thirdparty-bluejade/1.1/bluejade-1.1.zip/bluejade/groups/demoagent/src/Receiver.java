/*
 * (c) Copyright Hewlett-Packard Company 2001 
 * This program is free software; you can redistribute it and/or modify it under the terms of 
 * the GNU Lesser General Public License as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and 
 * no warranty that the program does not infringe the Intellectual Property rights of a third party.  
 * See the GNU Lesser General Public License for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License along with this program; 
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
 * 
 */ 

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.util.*;
import java.sql.*;
import java.text.*;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.FIPAException;


/**
 *  Agent which echoes back each incoming message.
 *  This is a test agent which waits for an incomming message
 *  and then returns that message back changing the performative
 *  to INFORM but leaving the content unchanged.
 *  It is intended for testing connections.
 *  The reply message will have updated sender, receiver,
 *  and in-reply-to fields (so that it can be successfuly
 *  returned to the original sender).
 */
public class Receiver extends Agent{

    class MyBehaviour extends CyclicBehaviour{

        public MyBehaviour( Agent a ) {
            super(a);
        }
       
        public void action() {
            
            try {
                ACLMessage request =  receive();
                
                if( request != null )
                {
                    System.out.println("Agent "+getLocalName()+" received:\n"
                                       +request);
                    
                    // Copy fields from incoming request.
                    ACLMessage response = request.createReply();
                    response.setPerformative(ACLMessage.INFORM);
                    response.setReplyWith(request.getReplyWith());
                    response.setContent(request.getContent());
                    
                    send(response);
                    
                    System.out.println("Agent "+getLocalName()+" sent:\n"
                                       +response);
                }
            }
            catch (Exception e)
            {
                System.out.println("Agent "+getLocalName()+":");
                e.printStackTrace();
            }
            block();            
        }
        
    }
    
     /**
     * The <CODE>setup()</CODE> method is called by the agent container as part
     * of the the agent intialization after the agent's contructor is called.
     * @see jade.core.Agent#setup()
     */
    protected void setup() {
        MyBehaviour b = new MyBehaviour(this);
        addBehaviour(b);
        System.out.println("Agent "+getLocalName()+" is running.");
    }

}
