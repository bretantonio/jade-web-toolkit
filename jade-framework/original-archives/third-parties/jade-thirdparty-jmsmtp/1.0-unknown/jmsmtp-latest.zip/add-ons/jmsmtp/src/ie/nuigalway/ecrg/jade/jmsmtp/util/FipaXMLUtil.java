/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
 /**
 *  FIPA XML Utility <p>
 *
 *  Utility class used to encode and decode JADE Envelopes into FIPA compatible
 *  XML messages </p>
 *
 * @author     Edward Curry - NUI, Galway
 * @version    1.0 14 January 2004
 */
package ie.nuigalway.ecrg.jade.jmsmtp.util;

import ie.nuigalway.ecrg.jade.jmsmtp.common.JmsMtpConfig;

import jade.core.AID;

import jade.domain.FIPAAgentManagement.Envelope;
import jade.domain.FIPAAgentManagement.ReceivedObject;

import java.io.*;
import java.io.BufferedReader;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import org.apache.log4j.Category;

public class FipaXMLUtil {

  private static Category log = Category.getRoot();
  private DateFormat fipaDateFormat;// used to create FIPA XML date format

  private String parser = "org.apache.crimson.parser.XMLReaderImpl";

  private final static String MIME_VERSION = "Mime-Version: 1.0";
  private final static String CONTENT_TYPE = "Content-Type: ";
  private final static String MULTIPART_MIXED = "multipart/mixed";
  private final static String CONTENT_LENGTH = "Content-Length: ";
  private final static String BOUNDARY = "boundary";
  private final static String CRLF = "\r\n";
  private final static String BLK = "";


  /**
   *  Creates a new FipaXMLUtil object.
   */
  public FipaXMLUtil() {

    try {
      parser = JmsMtpConfig.getProperty("ie.nuigalway.ecrg.jade.jmsmtp.fipaxmlutil.parser", parser).trim();

    } catch (Exception e) {
      parser = "org.apache.crimson.parser.XMLReaderImpl";
      log.error("Error setting default parser: " + e.toString());

    }

    // Set the FIPA XMl Date format
    fipaDateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmssSSS'Z'");
  }


  /**
   *  Constructor for the FipaXMLUtil object
   *
   * @param  parser  Description of the Parameter
   */
  public FipaXMLUtil(String parser) {

    this.parser = parser;

    // Set the FIPA XMl Date format
    fipaDateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmssSSS'Z'");
  }


  /**
   *  Convert a JADE Envelope and message Payload to FIPA compatible XML
   *
   * @param  env      JADE Envelope to be encoded
   * @param  payload  Message payload to be encoded into XML
   * @return          String FIPA XML containing converted envelope and message
   *      payload
   */
  public String encode(Envelope env, String payload) {
    return encode(env, payload.getBytes());
  }


  /**
   *  Convert a JADE Envelope and message Payload to FIPA compatible XML
   *
   * @param  env      JADE Envelope to be encoded
   * @param  payload  Message payload to be encoded into XML
   * @return          String FIPA XML containing converted envelope and message
   *      payload
   */
  public String encode(Envelope env, byte[] payload) {

    String strPayload = new String(payload);
    env.setPayloadLength(new Long((long) strPayload.length()));

    String boundary = "251D738450A171593A1583EB";
    StringBuffer msg = new StringBuffer(200);

    msg.append(MIME_VERSION).append(CRLF);
    msg.append(CONTENT_TYPE).append(MULTIPART_MIXED).append(" ; ").append(CRLF);
    msg.append("\t").append(BOUNDARY).append("=\"").append(boundary).append("\"").append(CRLF);
    msg.append(CRLF);

    msg.append("This is not part of the MIME multipart encoded message.").append(CRLF);
    msg.append("--").append(boundary).append(CRLF);

    // Add the env
    msg.append(CONTENT_TYPE).append("application/xml").append(CRLF);
    msg.append(CRLF);//  Required empty line

    // Choose encoding format.

    msg.append(XMLCodec.encodeXML(env));

    msg.append("\n");

    //Insert Boundary.
    msg.append(CRLF);
    msg.append("--").append(boundary).append(CRLF);

    //  Add the payload
    String payloadEncoding = env.getPayloadEncoding();

    if ((payloadEncoding != null) && (payloadEncoding.length() > 0)) {
      msg.append(CONTENT_TYPE).append(env.getAclRepresentation());
      msg.append("; charset=").append(env.getPayloadEncoding());
    } else {
      msg.append(CONTENT_TYPE).append("application/text");
    }

    msg.append(CRLF).append(CRLF);
    msg.append(new String(payload)).append(CRLF);

    // Insert EOF boundary
    msg.append("--").append(boundary).append("-").append(CRLF);

    return msg.toString();
  }


  /**
   *  Given an FIPA compliant XML message decode its envelope and payload
   *
   * @param  msg            FIPA compliant XML message to be decoded
   * @param  payload        StringBuffer to populate with message payload
   * @return                Envelope Decoded JADE Message Envelope
   * @exception  Exception  Error decoding the message
   */
  public Envelope decode(String msg, StringBuffer payload) throws Exception {

    BufferedReader br = new BufferedReader(new StringReader(msg));
    StringBuffer msgEnv = new StringBuffer(200);
    boolean foundMime = false;
    boolean foundBoundary = false;
    boolean findContentType = false;
    String boundary = null;

    String line;
    try {
      while (BLK.equals(line = br.readLine())) {
        ;
      }// skip empty lines

      if (line == null) {
        throw new IOException();
      }

      while (!(line = br.readLine()).equals(BLK)) {
        if (line.startsWith(MIME_VERSION)) {
          foundMime = true;
        }

        if (line.startsWith(CONTENT_TYPE)) {
          //Process the left part
          if (!(processLine(line).toLowerCase().startsWith(MULTIPART_MIXED))) {
            log.error("Error decoding: MULTIPART/MIXED");
            throw new Exception("Error decoding: MULTIPART/MIXED");
          }
          //Process the right part
          int pos = line.indexOf(BOUNDARY);
          if (pos == -1) {
            // Boundary on next line
            line = br.readLine();
            if ((pos = line.indexOf(BOUNDARY)) == -1) {
              // Bounday not found
              log.error("Error decoding: MIME boundary not found");
              throw new Exception("Error decoding: MIME boundary not found");
            }
          }
          line = line.substring(pos + BOUNDARY.length());
          pos = line.indexOf("\"") + 1;
          boundary = "--" + line.substring(pos, line.indexOf("\"", pos));
          foundBoundary = true;
        }
      }//end while

      //if( !foundBoundary || !foundMime) {
      if (!foundBoundary) {
        log.error("Error decoding: Mime header error");
        throw new Exception("Error decoding: Mime header error");
      }

      //jump to first  "--Boundary"
      while ((line = br.readLine()).equals(BLK)) {
        ;
      }// skip empty lines
      do {
        if (line.startsWith(boundary)) {
          break;
        }
      } while (!(line = br.readLine()).equals(BLK));

      while ((line = br.readLine()).equals(BLK)) {
        ;
      }// skip empty lines
      // Skip content-type
      do {
        if (line.startsWith(CONTENT_TYPE)) {
          break;
        }
      } while (!(line = br.readLine()).equals(BLK));

      //Capture the XML part
      //Capture the message envelope
      while (!(line = br.readLine()).equals(boundary)) {
        if (!line.equals(BLK)) {
          msgEnv.append(line);
        }
      }
      //System.out.println(xml.toString());

      //Capture the ACL part
      //JMP to ACLMessage
      while ((line = br.readLine()).equals(BLK)) {
        ;
      }

      // Skip content-type
      do {
        if (line.startsWith(CONTENT_TYPE)) {
          break;
        }
      } while (!(line = br.readLine()).equals(BLK));
      //Create last boundary for capture the ACLMessage
      boundary = boundary + "-";
      //Capture the acl part.
      // skip blank lines
      while ((line = br.readLine()).equals(BLK)) {
        ;
      }

      // handle first line separately
      if (!line.equals(boundary)) {
        payload.append(line);
      }
      // then handle following lines and append a separator
      while (!(line = br.readLine()).equals(boundary)) {
        if (!line.equals(BLK)) {
          payload.append(" ").append(line);
        }
      }

      XMLCodec codec = new XMLCodec(parser);
      StringReader sr = new StringReader(msgEnv.toString());
      Envelope env = codec.parse(sr);

      if ((env.getPayloadLength() !=
          null) && (env.getPayloadLength().intValue() != payload.length())) {
        log.error("JMS-MTP WARNING: payload size does not match envelope information");
      }

      return env;
    } catch (Exception e) {
      log.error("Error decoding: " + e.toString());
      throw new Exception("Error decoding FIPA XML message", e);
    }
  }


  /**
   *  return the next information of search in the line
   *
   * @param  line             Description of the Parameter
   * @return                  Description of the Return Value
   * @exception  IOException  Description of the Exception
   */
  private static String processLine(String line)
       throws IOException {

    StringTokenizer st = new StringTokenizer(line);
    try {
      st.nextToken();// Consumme first token
      return st.nextToken();
    } catch (NoSuchElementException nsee) {
      //System.err.println("Malformed line !: "+line);
      throw new IOException("Malformed line !: " + line);
    }
  }


  /**
   *  Given a date in a string format convert it to a Date object
   *
   * @param  dateTxt  Date to be converted in a string format
   * @return          Date Decoded date from string
   */
  public Date getDateFromString(String dateTxt) {

    try {

      return fipaDateFormat.parse(dateTxt);
    } catch (Exception e) {
      log.error("Error extracting Date from String:" + e.toString());
    }

    return null;
  }
}

