package ie.nuigalway.ecrg.jade.jmsmtp.examples;

import ie.nuigalway.ecrg.jade.jmsmtp.util.FipaXMLUtil;
import ie.nuigalway.ecrg.jade.jmsmtp.util.MapMessageUtil;

import jade.core.AID;
import jade.domain.FIPAAgentManagement.Envelope;
import jade.lang.acl.ACLMessage;
import java.util.Properties;

import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueSender;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.*;

/**
 *  Simple application for showing how to put a message into the JADE message
 *  queue using JMS-MTP. JADE ACLMessage classes are used as a convenience for
 *  constructing the ACL Message string.
 *
 * @author     Eduardo H. Ramirez <eduardo.ramirez@itesm.mx>, Monterrey
 *      Institute of Technology.
 * @author     Edward Curry - NUI, Galway
 * @version    1.0 14 January 2004
 */

public class JadeQueueSender implements MessageListener {

  private MapMessageUtil mapUtil = new MapMessageUtil();//from jms-mtp package
  private FipaXMLUtil xmlUtil = new FipaXMLUtil("org.apache.crimson.parser.XMLReaderImpl");//from jms-mtp package

  private QueueConnectionFactory queueConnectionFactory = null;
  private QueueConnection queueConnection = null;
  private QueueReceiver receiver;
  private int _count = 10;
  private int _received = 0;

  // Default settings
  private String ICF = "org.exolab.jms.jndi.InitialContextFactory";
  private String PROVIDER_URL = "rmi://localhost:1099";
  private String REPLY_TO_DEST = "JadeQueueSenderExample";
  private String PLATFORM_DEST = "jade/localhost";
  private String REPLY_TO_JMSMTP_ADDRESS = "jms:openjms|xml|non_persistent|||rmi://localhost:1099/JadeQueueSenderExample";
  private String PING_AGENT_NAME = "ping@localhost:1098/JADE"; 
  
  /**
   *  Constructor for the JadeQueueSender object
   */
  public JadeQueueSender() {

    Queue jadeQueue = null;

    try {

      Properties props = new Properties();
      props.put(Context.INITIAL_CONTEXT_FACTORY, ICF);
      props.put(Context.PROVIDER_URL, PROVIDER_URL);

      InitialContext ctx = new InitialContext(props);

      QueueConnectionFactory factory = (QueueConnectionFactory) ctx.lookup("JmsQueueConnectionFactory");
      QueueConnection connection = factory.createQueueConnection();
      connection.start();

      QueueSession session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
      Queue queue = (Queue) ctx.lookup(REPLY_TO_DEST);
      receiver = session.createReceiver(queue);
      receiver.setMessageListener(this);

      jadeQueue = (Queue) ctx.lookup(PLATFORM_DEST);
      QueueSender sender = session.createSender(jadeQueue);

      //Create an ACL Message object using JADE API.
      ACLMessage msg = new ACLMessage(ACLMessage.QUERY_REF);

      //Sender properties
      AID sender_aid = new AID();
      sender_aid.setName("JadeQueueSenderExample");

      // Use a JMS-MTP Address as the return address for the agent to reply to
      // This client will listen to 'rmi://localhost:1099/JadeQueueSenderExample'
      // Set the other options of the address to your desired setting,
      // in this case non persistent FIPA XML messages
      sender_aid.addAddresses(REPLY_TO_JMSMTP_ADDRESS);
      msg.setSender(sender_aid);
      
      // Alternatively we are also able to get the agent to reply to another agent. i.e.:
      // Reply to self: s_aid.setName("ping@mogador:1098/JADE");
      // or reply to another agent: s_aid.setName("personal_agent@mogador:1098/JADE");
      
      // Setup the PingAgents properties (This is the agent that will receive the message)
      AID pingAgent = new AID();
      pingAgent.setName(PING_AGENT_NAME);

      msg.addReceiver(pingAgent);

      // Set the message content "ping"
      msg.setContent("ping");
      msg.setDefaultEnvelope();

      //Encode map message
      Message message = session.createMapMessage();
      mapUtil.encode((MapMessage) message, msg.getEnvelope(), msg.toString());

      // Or use a FIPA XML Message
      //TextMessage message = session.createTextMessage();
      //message.setText(xmlUtil.encode(msg.getEnvelope(), msg.toString()));

      for (int ii = 1; ii <= _count; ii++) {
        System.out.println("Sending number" + ii + " : " + msg + "\n\n" + message);
        sender.send(message);
      }
    } catch (Exception ex) {
      System.out.println("Exception: " + ex.toString());
    }
  }


  /**
   *  The main program for the JadeQueueSender class
   *
   * @param  args  The command line arguments
   */
  public static void main(String[] args) {
    new JadeQueueSender();
  }


  /**
   *  All messages that for this listener are received by this method
   *
   * @param  msg  Description of the Parameter
   */
  public void onMessage(Message msg) {

    _received++;
    System.out.println("[" + _received + " of " + _count + "] ");

    StringBuffer payload = new StringBuffer();
    Envelope env = new Envelope();

    if (msg instanceof TextMessage) {

      System.out.println("Text Message");
      TextMessage tm = (TextMessage) msg;

      try {
        // Decode XML
        env = xmlUtil.decode(tm.getText(), payload);
      } catch (Exception jmse) {
        System.out.println("Error in JMS TextMessage Extraction: " + jmse.toString());
      }
    } else if (msg instanceof MapMessage) {

      System.out.println("Map Message");

      MapMessage mm = (MapMessage) msg;

      try {
        env = mapUtil.decode(mm, payload);
      } catch (Exception jmse) {
        System.out.println("Error in JMS MapMessage Extraction: " + jmse.toString());
      }
    }

    System.out.println("Message decode");

    System.out.println("Message body:" + payload.toString());

    if (_received == _count) {
      try {
        System.out.println("The listener received " + _received + " messages from queue " + receiver.getQueue());
      } catch (Exception jmse) {
        System.out.println("Error: " + jmse.toString());
      }
    }
  }
}

