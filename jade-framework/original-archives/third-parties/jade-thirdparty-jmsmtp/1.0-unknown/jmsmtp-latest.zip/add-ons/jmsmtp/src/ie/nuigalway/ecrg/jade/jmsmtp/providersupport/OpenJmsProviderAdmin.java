/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/**
 *  OpenJMS implementation of the ProviderAdmin interface <p>
 *
 *  Provides support for the OpenJMS JMS provider </p>
 *
 * @author     Edward Curry - NUI, Galway
 * @version    1.0 14 January 2004
 */
 
package ie.nuigalway.ecrg.jade.jmsmtp.providersupport;

import ie.nuigalway.ecrg.jade.jmsmtp.common.JMSAddress;
import ie.nuigalway.ecrg.jade.jmsmtp.common.ProviderAdmin;

import jade.mtp.MTPException;

import java.util.Properties;

import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Category;
import org.exolab.jms.administration.AdminConnectionFactory;
import org.exolab.jms.administration.JmsAdminServerIfc;

public class OpenJmsProviderAdmin implements ProviderAdmin {

  private static Category log = Category.getRoot();
  Properties props;

  private String url;


  /**
   *  Setup the OpenJMS Provider Admin
   */
  public OpenJmsProviderAdmin() {
    props = new Properties();

    if (log.isDebugEnabled()) {
      log.debug("Creating InitialContext");
    }
    props.put(Context.INITIAL_CONTEXT_FACTORY, "org.exolab.jms.jndi.InitialContextFactory");
  }


  /**
   *  Create a QueueConnection to a specified broker and place it in the hashmap
   *
   * @param  jmsTA          Details of broker to create connection factory too
   * @return                QueueConnectionFactory onnection to this broker
   * @throws  MTPException  Error creating the ConnectionFactory
   */
  public QueueConnectionFactory getQueueConnectionFactory(JMSAddress jmsTA)
       throws MTPException {
    props.put(Context.PROVIDER_URL, jmsTA.getBrokerURL());

    ClassLoader prevCl = Thread.currentThread().getContextClassLoader();

    try {

      // Save the class loader so that you can restore it later
      Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());

      InitialContext ctx = new InitialContext(props);

      return (QueueConnectionFactory) ctx.lookup("JmsQueueConnectionFactory");
    } catch (NamingException ne) {
      log.error("ConnectionFactory not found:" + ne.toString());
      throw new MTPException("Connection Factory not found", ne);
    } catch (Exception e) {
      log.error("Failed to create InitialContext:" + e.toString());
      throw new MTPException("Failed to create InitialContext", e);
    } finally {

      // Restore
      Thread.currentThread().setContextClassLoader(prevCl);
    }
  }


  /**
   *  Lookup or create a specified queue and return it
   *
   * @param  jmsTA          Contains details of the queue to lookup or create
   * @return                Queue The specified queue returned
   * @throws  MTPException  Error while creating the queue
   */
  public Queue getOrCreateQueue(JMSAddress jmsTA) throws MTPException {

    Queue endResult = null;
    JmsAdminServerIfc admin;

    props.put(Context.PROVIDER_URL, jmsTA.getBrokerURL());

    ClassLoader prevCl = Thread.currentThread().getContextClassLoader();

    try {

      // Save the class loader so that you can restore it later
      Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());

      InitialContext iniCtx = new InitialContext(props);

      // Lookup Queue
      if (log.isDebugEnabled()) {
        log.debug("Trying to connect to existing queue...");
      }

      admin = AdminConnectionFactory.create(jmsTA.getBrokerURL());
      boolean result = admin.destinationExists(jmsTA.getQueueName());

      if (result) {
        if (log.isDebugEnabled()) {
          log.debug("...queue exists!");
        }
      } else {
        if (log.isDebugEnabled()) {
          log.debug("...queue does not exist");
        }

        // Set to TRUE for queue
        if (!admin.addDestination(jmsTA.getQueueName(), Boolean.TRUE)) {
          log.error("Failed to add destination=" + jmsTA.getQueueName());
        }
      }

      // Append 'queue/' before the queue name to locate it in JNDI  (JBossMQ convention)
      endResult = (Queue) iniCtx.lookup(jmsTA.getQueueName());

    } catch (Exception e) {

      if (log.isDebugEnabled()) {
        log.debug("Failed to get or create the queue:" + e.toString());
      }

      throw new MTPException("Failed to get or create the queue:", e);
    } finally {

      // Restore
      Thread.currentThread().setContextClassLoader(prevCl);
    }

    return endResult;
  }
}

