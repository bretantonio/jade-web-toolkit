/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.gui;
import ie.nuigalway.ecrg.jade.jmsagentgateway.Util;

import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.PublishMessage;

/**
 *  Model for published message gui list
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class PublishedMessageModel {

  private String sender;
  private String providerURL;
  private String destination;
  private String destType;
  private String time;


  /**
   *  Constructor for the PublishedMessageModel object
   *
   * @param  sender  Message Sender
   * @param  pm      The message publishedr
   */
  public PublishedMessageModel(String sender, PublishMessage pm) {
    this.sender = sender;
    this.providerURL = pm.getProviderInfo().getProviderURL();
    this.destination = pm.getMessage().getDestination();
    this.destType = (pm.getProviderInfo().getDestType() == Util.QUEUE) ? "Queue" : "Topic";

  }


  /**
   *  Sets the sender attribute of the PublishedMessageModel object
   *
   * @param  value  The new sender value
   */
  public void setSender(String value) {
    this.sender = value;
  }


  /**
   *  Gets the sender attribute of the PublishedMessageModel object
   *
   * @return    The sender value
   */
  public String getSender() {
    return this.sender;
  }


  /**
   *  Sets the providerURL attribute of the PublishedMessageModel object
   *
   * @param  value  The new providerURL value
   */
  public void setProviderURL(String value) {
    this.providerURL = value;
  }


  /**
   *  Gets the providerURL attribute of the PublishedMessageModel object
   *
   * @return    The providerURL value
   */
  public String getProviderURL() {
    return this.providerURL;
  }


  /**
   *  Sets the destination attribute of the PublishedMessageModel object
   *
   * @param  value  The new destination value
   */
  public void setDestination(String value) {
    this.destination = value;
  }


  /**
   *  Gets the destination attribute of the PublishedMessageModel object
   *
   * @return    The destination value
   */
  public String getDestination() {
    return this.destination;
  }


  /**
   *  Sets the destType attribute of the PublishedMessageModel object
   *
   * @param  value  The new destType value
   */
  public void setDestType(String value) {
    this.destType = value;
  }


  /**
   *  Gets the destType attribute of the PublishedMessageModel object
   *
   * @return    The destType value
   */
  public String getDestType() {
    return this.destType;
  }


  /**
   *  Sets the time attribute of the PublishedMessageModel object
   *
   * @param  value  The new time value
   */
  public void setTime(String value) {
    this.time = value;
  }


  /**
   *  Gets the time attribute of the PublishedMessageModel object
   *
   * @return    The time value
   */
  public String getTime() {
    return this.time;
  }

}

