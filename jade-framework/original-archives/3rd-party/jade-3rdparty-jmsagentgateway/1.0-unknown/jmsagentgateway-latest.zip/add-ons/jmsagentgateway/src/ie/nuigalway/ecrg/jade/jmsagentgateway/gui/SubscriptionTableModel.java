/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.gui;

import java.util.Vector;

import javax.swing.table.AbstractTableModel;

/**
 *  Table model of gui subscription lsit
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class SubscriptionTableModel extends AbstractTableModel {

  private Vector subs;// List of stuscriptions


  /**
   *  Constructor for the SubscriptionTableModel object
   */
  public SubscriptionTableModel() {
    super();
    subs = new Vector();
  }


  /**
   *  Add Subscription to the list
   *
   * @param  sub  New subscription to be added
   */
  public void add(SubscriptionModel sub) {
    subs.add((Object) sub);
  }


  /**
   *  Remove subscription from list
   *
   * @param  sub  Subscription to be removed
   */
  public void remove(SubscriptionModel sub) {
    subs.remove((Object) sub);
  }


  /**
   *  Gets the elementAt attribute of the SubscriptionTableModel object
   *
   * @param  index  Index of requested element
   * @return        The requested SubscriptionModel
   */
  public SubscriptionModel getElementAt(int index) {
    return ((SubscriptionModel) subs.get(index));
  }


  /**
   *  Clear the list of subscriptions
   */
  public void clear() {
    subs.clear();
  }


  /**
   *  Gets the rowCount attribute of the SubscriptionTableModel object
   *
   * @return    The rowCount value
   */
  public int getRowCount() {
    return (subs.size());
  }


  /**
   *  Gets the columnCount attribute of the SubscriptionTableModel object
   *
   * @return    The columnCount value
   */
  public int getColumnCount() {
    return (6);
  }


  /**
   *  Gets the valueAt attribute of the SubscriptionTableModel object
   *
   * @param  row     Row number
   * @param  column  Column number
   * @return         Requested Value
   */
  public Object getValueAt(int row, int column) {

    String value = new String();
    SubscriptionModel sub = (SubscriptionModel) subs.get(row);

    switch (column) {
        case 0:
          // Sender
          value = sub.getSender();
          break;
        case 1:
          // Server URL
          value = sub.getProviderURL();
          break;
        case 2:
          // Destination
          value = sub.getDestination();
          break;
        case 3:
          // Dest Type
          value = sub.getDestType();
          break;
        case 4:
          // Durable
          value = sub.getDurable();
          break;
        case 5:
          // Message Counter
          value = String.valueOf(sub.getMsgCounter());
          break;
    }
    return ((Object) value);
  }

}

