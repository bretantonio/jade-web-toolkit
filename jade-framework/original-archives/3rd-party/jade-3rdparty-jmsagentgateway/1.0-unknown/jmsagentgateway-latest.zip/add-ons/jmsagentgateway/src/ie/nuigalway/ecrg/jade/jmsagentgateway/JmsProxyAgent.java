/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway;

import ie.nuigalway.ecrg.jade.jmsagentgateway.gui.JmsAgentGatewayGui;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsAgentGatewayOntology;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.ProviderInfo;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.PublishMessage;

import jade.content.Concept;
import jade.content.ContentElement;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.Ontology;
import jade.content.onto.basic.Action;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.SequentialBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.gui.GuiAgent;
import jade.gui.GuiEvent;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.SubscriptionResponder;
import jade.util.BasicProperties;
import jade.util.ExpandedProperties;
import java.io.IOException;

import java.io.InputStream;
import java.net.URL;

import org.apache.log4j.Category;
import org.apache.log4j.PropertyConfigurator;

/**
 *  The JmsProxyAgent act as a proxy to JMS providers allowing JADE agents to
 *  particapate in JMS interactions
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class JmsProxyAgent extends GuiAgent {
  private static Category log = Category.getRoot();

  private Codec codec = new SLCodec();
  private Ontology ontology = JmsAgentGatewayOntology.getInstance();

  private JmsGateway jmsP = new JmsGateway();

  private JmsAgentGatewayGui gui;

  private JmsSubscriptionManager manager;

  // Configuration variables
  private boolean guiEnabled = false;
  private String agentType = "JmsProxyAgent";
  private String agentOwner = "ecrg.it.nuigalway.ie";

  /**
   *  GUI Event code for unsubscription
   */
  public final static int UNSUBSCRIBE_EVENT = 1000;


  /**
   *  Constructor for the SubscriptionAgent object
   */
  public JmsProxyAgent() {
    super();
    if (log.isDebugEnabled()) {
      log.debug("JmsProxyAgent started");
    }
  }


  /**
   *  Setup the Agent
   */
  protected void setup() {

    setProperties();

    if (guiEnabled) {

      if (log.isDebugEnabled()) {
        log.debug("Satrting GUI for agent");
      }

      gui = new JmsAgentGatewayGui(this);
      gui.setVisible(true);
    }

    // Register language and ontology
    getContentManager().registerLanguage(codec);
    getContentManager().registerOntology(ontology);

    // Set this agent main behaviour
    SequentialBehaviour sb = new SequentialBehaviour();
    sb.addSubBehaviour(new RegisterInDF(this));
    sb.addSubBehaviour(new ReceiveMessages(this));
    addBehaviour(sb);

    if (log.isDebugEnabled()) {
      log.debug("Starting subscription manager");
    }

    manager = new JmsSubscriptionManager();
    manager.setContentManager(getContentManager());

    if (guiEnabled) {
      manager.setGUI(gui);
    }

    MessageTemplate mt = MessageTemplate.or(MessageTemplate.MatchPerformative(ACLMessage.CANCEL),
        MessageTemplate.MatchPerformative(ACLMessage.SUBSCRIBE));

    addBehaviour(new SubscriptionResponder(this, mt, manager));
  }


  /**
   *  Method for handling ReplyNotUnderstood messages
   *
   * @param  msg  Message to sendreceived
   */
  private void replyNotUnderstood(ACLMessage msg) {

    try {

      ContentElement content = getContentManager().extractContent(msg);
      ACLMessage reply = msg.createReply();
      reply.setPerformative(ACLMessage.NOT_UNDERSTOOD);
      getContentManager().fillContent(reply, content);

      send(reply);
      if (log.isDebugEnabled()) {
        log.debug("Not understood!");
      }
    } catch (Exception ex) {
      log.error(ex.toString());
    }
  }


  /**
   *  Method for handling failure messages
   *
   * @param  msg  Message to send
   */
  private void replyFailure(ACLMessage msg) {

    try {

      ContentElement content = getContentManager().extractContent(msg);
      ACLMessage reply = msg.createReply();
      reply.setPerformative(ACLMessage.FAILURE);
      getContentManager().fillContent(reply, content);

      send(reply);
      if (log.isDebugEnabled()) {
        log.debug("Failure");
      }
    } catch (Exception ex) {
      log.error(ex.toString());
    }
  }


  /**
   *  Method for handling done messages
   *
   * @param  msg  Message to send
   */
  private void replyDone(ACLMessage msg) {

    try {

      ContentElement content = getContentManager().extractContent(msg);
      ACLMessage reply = msg.createReply();
      reply.setPerformative(ACLMessage.CONFIRM);
      getContentManager().fillContent(reply, content);

      send(reply);
      if (log.isDebugEnabled()) {
        log.debug("Done");
      }
    } catch (Exception ex) {
      log.error(ex.toString());
    }
  }


  /**
   *  Agent handler for GUI events
   *
   * @param  ev  Event from GUI
   */
  protected void onGuiEvent(GuiEvent ev) {

    switch (ev.getType()) {

        case UNSUBSCRIBE_EVENT:
          try {
            manager.deregister((SubscriptionResponder.Subscription) ev.getParameter(0));
          } catch (Exception e) {
            log.error("Error in GUI" + e.toString());
          }
          break;
    }
  }


  /**
   *  Sets the properties attribute of the JmsProxyAgent object
   */
  private void setProperties() {

    String PROP_NAME = "jmsagentgateway.properties";
    String packageName = "ie.nuigalway.ecrg.jade.jmsagentgateway.";

    BasicProperties properties = null;

    properties = new ExpandedProperties();
    String defaultPropName = PROP_NAME;

    InputStream propertyStream = this.getClass().getClassLoader().getResourceAsStream(defaultPropName);

    if (propertyStream != null) {

      try {
        properties.load(propertyStream);
      } catch (IOException ioe) {
        log.error("Error reading:" + defaultPropName);
      }
    }

    try {

      // Try to configure from .properties file
      log.debug("loading setting from configuration file");
      guiEnabled = properties.getBooleanProperty(packageName + "gui", false);
      agentType = properties.getProperty(packageName + "agentType", "JmsProxyAgent");
      agentOwner = properties.getProperty(packageName + "agentOwner", "ecrg.it.nuigalway.ie");

    } catch (Exception any) {
      log.error("Error setting configuration, using defaults");
      // Set Default values
      guiEnabled = false;
      agentType = "JmsProxyAgent";
      agentOwner = "ecrg.it.nuigalway.ie";
    }
  }


  /**
   *  Behaviour to registers the agent in the DF
   *
   * @author     Edward Curry created 08 December 2003 * *
   * @version    0.5 12 January 2004
   */
  class RegisterInDF extends OneShotBehaviour {

    /**
     *  Constructor for the RegisterInDF object
     *
     * @param  a  Description of the Parameter
     */
    RegisterInDF(Agent a) {
      super(a);
    }


    /**
     *  Action to register agent
     */
    public void action() {

      ServiceDescription sd = new ServiceDescription();
      sd.setType(agentType);
      sd.setName(getName());
      sd.setOwnership(agentOwner);

      DFAgentDescription dfd = new DFAgentDescription();
      dfd.setName(getAID());
      dfd.addServices(sd);

      try {
        DFAgentDescription[] dfds = DFService.search(myAgent, dfd);

        if (dfds.length > 0) {
          DFService.deregister(myAgent, dfd);
        }

        DFService.register(myAgent, dfd);

        System.out.println(getLocalName() + " is ready.");
        if (log.isDebugEnabled()) {
          log.debug(getLocalName() + " is ready.");
        }
      } catch (Exception ex) {
        log.error("Failed registering with DF!: " + ex.toString());
        doDelete();
      }
    }
  }


  /**
   *  Behaviour to listen for incoming messages
   *
   * @author     Edward Curry created 08 December 2003 * *
   * @version    0.5 12 January 2004
   */
  class ReceiveMessages extends CyclicBehaviour {

    /**
     *  Constructor for the ReceiveMessages object
     *
     * @param  a  Agent listening
     */
    public ReceiveMessages(Agent a) {
      super(a);
    }


    /**
     *  Listen for messages to republish
     */
    public void action() {

      ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.REQUEST));

      if (msg == null) {
        block();
        return;
      }

      try {
        ContentElement content = getContentManager().extractContent(msg);
        Concept action = ((Action) content).getAction();

        switch (msg.getPerformative()) {

            case (ACLMessage.REQUEST):
              if (log.isDebugEnabled()) {
                log.debug("Request from " + msg.getSender().getLocalName());
              }

              if (action instanceof PublishMessage) {
                addBehaviour(new HandlePublishMessage(myAgent, msg));
              } else {
                replyNotUnderstood(msg);
              }
              break;
            default:
              replyNotUnderstood(msg);
        }
      } catch (Exception ex) {
        log.error(ex.toString());
      }
    }
  }


  /**
   *  Handler for publishing messages
   *
   * @author     Edward Curry created 08 December 2003 * *
   * @version    0.5 12 January 2004
   */
  class HandlePublishMessage extends OneShotBehaviour {

    private ACLMessage request;


    /**
     *  Constructor for the HandlePublishMessage object
     *
     * @param  a        Parent agent
     * @param  request  Message to republish
     */
    HandlePublishMessage(Agent a, ACLMessage request) {
      super(a);
      this.request = request;
    }


    /**
     *  Action to republish message
     */
    public void action() {

      try {
        ContentElement content = getContentManager().extractContent(request);
        PublishMessage pm = (PublishMessage) ((Action) content).getAction();

        // Get ProviderInfo
        ProviderInfo serverInfo = pm.getProviderInfo();

        // Get Message
        JmsMessage msg = pm.getMessage();

        if (log.isDebugEnabled()) {
          log.debug("Message - Dest:" + msg.getDestination() + " Payload:" + Util.convertStringToObject(msg.getPayload()) + " DelMode:" + msg.getDeliveryMode());
        }

        // Pass information to Proxy
        jmsP.deliver(serverInfo, msg);

        if (guiEnabled) {
          gui.addPublishedMessage(request.getSender().getName(), pm);
        }

        replyDone(request);
      } catch (Exception ex) {
        replyFailure(request);
        log.error(ex.toString());
      }
    }
  }

  static {
    String resource = "/log4j-jmsagentgateway.properties";
    URL configFileResource = JmsGateway.class.getResource(resource);
    PropertyConfigurator.configure(configFileResource);

  }
}

