/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.gui;

import java.util.Vector;

import javax.swing.table.AbstractTableModel;


/**
 *  Table model for pulished message gui list
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class PublishedMessageTableModel extends AbstractTableModel {
  Vector msgs;


  /**
   *  Constructor for the PublishedMessageTableModel object
   */
  public PublishedMessageTableModel() {
    super();
    msgs = new Vector();
  }


  /**
   *  Add a message to the list
   *
   * @param  msg  Message to add to the list
   */
  public void add(PublishedMessageModel msg) {
    msgs.add((Object) msg);
  }


  /**
   *  Gets the elementAt attribute of the PublishedMessageTableModel object
   *
   * @param  index  Description of the Parameter
   * @return        The elementAt value
   */
  public PublishedMessageModel getElementAt(int index) {
    return ((PublishedMessageModel) msgs.get(index));
  }


  /**
   *  Description of the Method
   */
  public void clear() {
    msgs.clear();
  }


  /**
   *  Gets the rowCount attribute of the PublishedMessageTableModel object
   *
   * @return    The rowCount value
   */
  public int getRowCount() {
    return (msgs.size());
  }


  /**
   *  Gets the columnCount attribute of the PublishedMessageTableModel object
   *
   * @return    The columnCount value
   */
  public int getColumnCount() {
    return (5);
  }


  /**
   *  Gets the valueAt attribute of the PublishedMessageTableModel object
   *
   * @param  row     Row number
   * @param  column  Column number
   * @return         The valueAt value
   */
  public Object getValueAt(int row, int column) {
    String value = new String();
    PublishedMessageModel pm = (PublishedMessageModel) msgs.get(row);

    switch (column) {
        case 0:
          // Sender
          value = pm.getSender();
          break;
        case 1:
          // Server URL
          value = pm.getProviderURL();
          break;
        case 2:
          // Destination
          value = pm.getDestination();
          break;
        case 3:
          // Dest Type
          value = pm.getDestType();
          break;
        case 4:
          // Delivery Mode
          value = pm.getTime();
          break;
    }
    return ((Object) value);
  }
}

