/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.onto;

import jade.content.*;
import jade.core.*;
import jade.util.leap.*;

/**
 *  Concept used to represent a JMS Subscription Protege name: Subscription
 *
 * @author     ontology bean generator
 * @version    2004/03/31, 18:54:36
 */
public class Subscription implements Concept {

  /**
   *  JMS Destination Protege name: destination
   */
  private String destination;

  /**
   *  JMS Message Selector Protege name: selector
   */
  private String selector;

  /**
   *  ID used for durable subscription Protege name: durableIdent
   */
  private String durableIdent;

  /**
   *  Subscription Type: Set to TRUE for DURABLE Set to FALSE for NON_DURABLE
   *  Protege name: durable
   */
  private boolean durable;


  /**
   *  Sets the destination attribute of the Subscription object
   *
   * @param  value  The new destination value
   */
  public void setDestination(String value) {
    this.destination = value;
  }


  /**
   *  Gets the destination attribute of the Subscription object
   *
   * @return    The destination value
   */
  public String getDestination() {
    return this.destination;
  }


  /**
   *  Sets the selector attribute of the Subscription object
   *
   * @param  value  The new selector value
   */
  public void setSelector(String value) {
    this.selector = value;
  }


  /**
   *  Gets the selector attribute of the Subscription object
   *
   * @return    The selector value
   */
  public String getSelector() {
    return this.selector;
  }


  /**
   *  Sets the durableIdent attribute of the Subscription object
   *
   * @param  value  The new durableIdent value
   */
  public void setDurableIdent(String value) {
    this.durableIdent = value;
  }


  /**
   *  Gets the durableIdent attribute of the Subscription object
   *
   * @return    The durableIdent value
   */
  public String getDurableIdent() {
    return this.durableIdent;
  }


  /**
   *  Sets the durable attribute of the Subscription object
   *
   * @param  value  The new durable value
   */
  public void setDurable(boolean value) {
    this.durable = value;
  }


  /**
   *  Gets the durable attribute of the Subscription object
   *
   * @return    The durable value
   */
  public boolean getDurable() {
    return this.durable;
  }

}

