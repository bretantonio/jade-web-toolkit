/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway;

import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Property;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.ProviderInfo;

import java.util.Iterator;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;

import org.apache.log4j.Category;


/**
 *  Proxy used by the JmsProxyAgent to connect to a JMS provider
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class JmsGateway {

  private static Category log;


  /**
   *  Creates a new ProviderManager object.
   */
  public JmsGateway() {

    log = Category.getRoot();

    if (log.isDebugEnabled()) {
      log.debug("Porxy Started");
    }
  }


  /**
   *  Deactivate the JmsGateway
   */
  public void deactivate() {

    if (log.isDebugEnabled()) {
      log.debug("Remove all Connections to JMS Providers");
    }

    try {
      JMS_Util.closeBrokerConnections();
    } catch (Exception e) {
    }
  }


  /**
   *  Deliver the message
   *
   * @param  proInfo        Server Information to send message too
   * @param  msg            Message to send
   * @exception  Exception  Error sending message
   * @throws  Exception     Error during message send
   */
  public void deliver(ProviderInfo proInfo, JmsMessage msg) throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("Deliver a Message to an address");
    }

    try {

      if (log.isDebugEnabled()) {
        log.debug("Create connection to the JMS Server");
      }

      Connection conn = JMS_Util.getBrokerConnection(proInfo);

      if (log.isDebugEnabled()) {
        log.debug("Createing Session");
      }

      MessageProducer msgProd;
      Session session;

      if (proInfo.getDestType() == Util.QUEUE) {
        session = ((QueueConnection) conn).createQueueSession(false, QueueSession.AUTO_ACKNOWLEDGE);
        Queue que = ((QueueSession) session).createQueue(msg.getDestination());
        msgProd = ((QueueSession) session).createSender(que);
      } else {
        session = ((TopicConnection) conn).createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
        Topic top = ((TopicSession) session).createTopic(msg.getDestination());
        msgProd = ((TopicSession) session).createPublisher(top);
      }

      if (msg.getTimeToLive() != 0) {
        msgProd.setTimeToLive((long) msg.getTimeToLive());
      }

      msgProd.setPriority(msg.getPriority());

      if (log.isDebugEnabled()) {
        log.debug("Setting Persistence");
      }

      if (proInfo.getDestType() == Util.QUEUE) {

        if (msg.getDeliveryMode() == Util.NON_PERSISTENT) {
          msgProd.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
        } else {
          msgProd.setDeliveryMode(DeliveryMode.PERSISTENT);
        }

      }

      if (log.isDebugEnabled()) {
        log.debug("Create the Message");
      }

      javax.jms.ObjectMessage message;

      message = session.createObjectMessage();
      message.setObject(Util.convertStringToObject(msg.getPayload()));

      // Add Attributes
      Iterator itProps = msg.getProperties().iterator();

      while (itProps.hasNext()) {
        Property prop = (Property) itProps.next();
        message.setStringProperty(prop.getPropName(), prop.getPropValue());
      }

      if (log.isDebugEnabled()) {
        log.debug("Send the Message");
      }

      if (proInfo.getDestType() == Util.QUEUE) {
        ((QueueSender) msgProd).send(message);
      } else {
        ((TopicPublisher) msgProd).publish(message);
      }

      msgProd.close();
      session.close();
    } catch (Exception e) {
      log.error("Error in sending: " + e.toString());
      throw new Exception("Error sending the Message: ", e);
    }
  }
}

