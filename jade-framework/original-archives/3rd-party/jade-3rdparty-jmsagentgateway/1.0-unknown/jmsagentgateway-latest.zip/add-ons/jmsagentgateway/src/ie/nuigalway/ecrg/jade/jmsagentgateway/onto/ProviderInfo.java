/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.onto;

import jade.content.*;
import jade.core.*;
import jade.util.leap.*;

/**
 *  Concept used to represent a JMS providers server Protege name: ProviderInfo
 *
 * @author     ontology bean generator
 * @version    2004/03/31, 18:54:36
 */
public class ProviderInfo implements Concept {

  /**
   *  Connection Password Protege name: password
   */
  private String password;

  /**
   *  URL of the JMS provider to connect too. Protege name: providerURL
   */
  private String providerURL;

  /**
   *  Initial Connection Factory of the JMS Provider Protege name: providerICF
   */
  private String providerICF;

  /**
   *  Connection Username Protege name: username
   */
  private String username;

  /**
   *  Set to TRUE for TOPIC Set to False for QUEUE Protege name: destType
   */
  private boolean destType;


  /**
   *  Sets the password attribute of the ProviderInfo object
   *
   * @param  value  The new password value
   */
  public void setPassword(String value) {
    this.password = value;
  }


  /**
   *  Gets the password attribute of the ProviderInfo object
   *
   * @return    The password value
   */
  public String getPassword() {
    return this.password;
  }


  /**
   *  Sets the providerURL attribute of the ProviderInfo object
   *
   * @param  value  The new providerURL value
   */
  public void setProviderURL(String value) {
    this.providerURL = value;
  }


  /**
   *  Gets the providerURL attribute of the ProviderInfo object
   *
   * @return    The providerURL value
   */
  public String getProviderURL() {
    return this.providerURL;
  }


  /**
   *  Sets the providerICF attribute of the ProviderInfo object
   *
   * @param  value  The new providerICF value
   */
  public void setProviderICF(String value) {
    this.providerICF = value;
  }


  /**
   *  Gets the providerICF attribute of the ProviderInfo object
   *
   * @return    The providerICF value
   */
  public String getProviderICF() {
    return this.providerICF;
  }


  /**
   *  Sets the username attribute of the ProviderInfo object
   *
   * @param  value  The new username value
   */
  public void setUsername(String value) {
    this.username = value;
  }


  /**
   *  Gets the username attribute of the ProviderInfo object
   *
   * @return    The username value
   */
  public String getUsername() {
    return this.username;
  }


  /**
   *  Sets the destType attribute of the ProviderInfo object
   *
   * @param  value  The new destType value
   */
  public void setDestType(boolean value) {
    this.destType = value;
  }


  /**
   *  Gets the destType attribute of the ProviderInfo object
   *
   * @return    The destType value
   */
  public boolean getDestType() {
    return this.destType;
  }

}

