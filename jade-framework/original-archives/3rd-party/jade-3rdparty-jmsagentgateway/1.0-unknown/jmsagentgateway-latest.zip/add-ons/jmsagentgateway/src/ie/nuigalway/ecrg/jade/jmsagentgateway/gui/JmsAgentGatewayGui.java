/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.gui;

import ie.nuigalway.ecrg.jade.jmsagentgateway.JmsProxyAgent;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.PublishMessage;

import jade.gui.GuiEvent;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableColumn;

import org.apache.log4j.Category;

/**
 *  This is the GUI of the PubSubAgent. Becuase in Java a new Thread is spawn
 *  for each GUI, the communication with the Agent thread is based on event
 *  passing.
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class JmsAgentGatewayGui extends JFrame implements ActionListener {

  private JmsProxyAgent jmsProxyAgent;

  private SubscriptionTableModel subscriptionListModel;
  private JTable subscriptionList;

  private PublishedMessageTableModel publishedMessageListModel;
  private JTable publishedMessageList;

  private static String UNSUBSCRIBELABEL = "Cancel Subscription";
  private static String CLEARLABEL = "Clear";

  private static Category log;


  /**
   *  Constructor for the PubSubAgentGui object
   *
   * @param  agent  Agent to communicate with
   */
  public JmsAgentGatewayGui(JmsProxyAgent agent) {
    super();
    log = Category.getRoot();
    jmsProxyAgent = agent;
    setTitle("JMS-Agent Gateway - GUI of JmsProxyAgent: " + agent.getLocalName());
    setSize(505, 405);

    if (log.isDebugEnabled()) {
      log.debug("Starting GUI");
    }

    // Set GUI window layout manager
    JPanel main = new JPanel();
    main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));

    // Add the list of subscription sites to the NORTH part
    subscriptionListModel = new SubscriptionTableModel();
    subscriptionList = new JTable(subscriptionListModel);
    subscriptionList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    JPanel subscriptionPanel = new JPanel();
    subscriptionPanel.setLayout(new BorderLayout());

    JScrollPane subscriptionPane = new JScrollPane();
    subscriptionPane.getViewport().setView(subscriptionList);
    subscriptionPanel.add(subscriptionPane, BorderLayout.CENTER);
    subscriptionPanel.setBorder(BorderFactory.createTitledBorder("Active Subscriptions"));
    subscriptionList.setRowHeight(20);

    main.add(subscriptionPanel);

    TableColumn col;
    col = subscriptionList.getColumn((Object) subscriptionList.getColumnName(0));
    col.setHeaderValue((Object) (new String("Agent ID")));
    col = subscriptionList.getColumn((Object) subscriptionList.getColumnName(1));
    col.setHeaderValue((Object) (new String("Server URL")));
    col = subscriptionList.getColumn((Object) subscriptionList.getColumnName(2));
    col.setHeaderValue((Object) (new String("Destination")));
    col = subscriptionList.getColumn((Object) subscriptionList.getColumnName(3));
    col.setHeaderValue((Object) (new String("Type")));
    col = subscriptionList.getColumn((Object) subscriptionList.getColumnName(4));
    col.setHeaderValue((Object) (new String("Durable")));
    col = subscriptionList.getColumn((Object) subscriptionList.getColumnName(5));
    col.setHeaderValue((Object) (new String("Msg Rec")));

    JPanel subPanel = new JPanel();
    subPanel.setLayout(new BoxLayout(subPanel, BoxLayout.X_AXIS));

    JButton cancelButton = new JButton(UNSUBSCRIBELABEL);
    cancelButton.addActionListener(this);
    subPanel.add(cancelButton);

    main.add(subPanel);

    // Add the list of publishedMessage sites to the CENTER part
    JPanel publishedMessagePanel = new JPanel();
    publishedMessagePanel.setLayout(new BorderLayout());
    publishedMessageListModel = new PublishedMessageTableModel();
    publishedMessageList = new JTable(publishedMessageListModel);

    JScrollPane pane = new JScrollPane();
    pane.getViewport().setView(publishedMessageList);
    publishedMessagePanel.add(pane, BorderLayout.CENTER);
    publishedMessagePanel.setBorder(BorderFactory.createTitledBorder("Messages Published"));
    publishedMessageList.setRowHeight(20);

    main.add(publishedMessagePanel);

    // Column names
    col = publishedMessageList.getColumn((Object) publishedMessageList.getColumnName(0));
    col.setHeaderValue((Object) (new String("Agent ID")));
    col = publishedMessageList.getColumn((Object) publishedMessageList.getColumnName(1));
    col.setHeaderValue((Object) (new String("Server URL")));
    col = publishedMessageList.getColumn((Object) publishedMessageList.getColumnName(2));
    col.setHeaderValue((Object) (new String("Destination")));
    col = publishedMessageList.getColumn((Object) publishedMessageList.getColumnName(3));
    col.setHeaderValue((Object) (new String("Type")));
    col = publishedMessageList.getColumn((Object) publishedMessageList.getColumnName(4));
    col.setHeaderValue((Object) (new String("Timestamp")));

    // Clear Button
    JPanel p = new JPanel();
    JButton b = new JButton(CLEARLABEL);
    b.addActionListener(this);
    p.add(b);
    main.add(p);

    getContentPane().add(main, BorderLayout.CENTER);
  }


  /**
   *  Event listener for actions on GUI
   *
   * @param  e  Events from the gui
   */
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();

    if (command.equalsIgnoreCase(CLEARLABEL)) {
      clearPublishedMessages();
    } else if (command.equalsIgnoreCase(UNSUBSCRIBELABEL)) {

      SubscriptionModel subModel;
      int sel = subscriptionList.getSelectedRow();

      if (sel >= 0) {
        subModel = subscriptionListModel.getElementAt(sel);

        GuiEvent ev = new GuiEvent((Object) this, jmsProxyAgent.UNSUBSCRIBE_EVENT);
        ev.addParameter(subModel.getSubscription());
        jmsProxyAgent.postGuiEvent(ev);
      }
    }
  }


  /**
   *  Draws GUI in correct sizes
   */
  private void showCorrect() {
    // Arrange and display GUI window
    pack();
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    int centerX = (int) screenSize.getWidth() / 2;
    int centerY = (int) screenSize.getHeight() / 2;
    setLocation(centerX - getWidth() / 2, centerY - getHeight() / 2);
    show();
  }


  /**
   *  Adds a new subscription to the GUI list
   *
   * @param  sub  New subscription to be added to list
   */
  public void addSubscription(SubscriptionModel sub) {
    subscriptionListModel.add(sub);
    subscriptionListModel.fireTableDataChanged();
  }


  /**
   *  Removes a subscription from the list
   *
   * @param  sub  Subscription to remove
   */
  public void removeSubscription(SubscriptionModel sub) {
    subscriptionListModel.remove(sub);
    subscriptionListModel.fireTableDataChanged();
  }


  /**
   *  Updates the list of subscriptions
   */
  public void updateSubscriptions() {
    subscriptionListModel.fireTableDataChanged();
  }


  /**
   *  Adds a new published message to the GUI list
   *
   * @param  sender  Sender of the message
   * @param  pm      The new published message
   */
  public void addPublishedMessage(String sender, PublishMessage pm) {
    publishedMessageListModel.add(new PublishedMessageModel(sender, pm));
    publishedMessageListModel.fireTableDataChanged();
  }


  /**
   *  Clear the published message list
   */
  public void clearPublishedMessages() {
    publishedMessageListModel.clear();
    publishedMessageListModel.fireTableDataChanged();
  }

}

