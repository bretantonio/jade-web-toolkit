/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway;

import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.ProviderInfo;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import javax.jms.Connection;
import javax.jms.QueueConnectionFactory;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.Category;

/**
 *  General utility class for JMS Interactions
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class JMS_Util {

  private static HashMap brokerConnections = new HashMap();
  private static Category log = Category.getRoot();


  /**
   *  Used to create a new broker connection or to retrive one from the hashmap
   *
   * @param  proInfo     Description of the Parameter
   * @return             QueueConnection A Connection object for the broker
   * @throws  Exception  Error During Connection Activation
   */
  public static Connection getBrokerConnection(ProviderInfo proInfo) throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("Retriving broker connection");
    }

    String key = (proInfo.getDestType() == Util.QUEUE ? "queue" : "topic") + ":" + proInfo.getUsername() + ":" + proInfo.getProviderURL();

    // check to see if the connection has been connected
    if (!brokerConnections.containsKey(key)) {
      setupBrokerConnection(proInfo);
    }

    return (Connection) brokerConnections.get(key);
  }


  /**
   *  Create a connection to a specified broker and place it in the hashmap
   *
   * @param  proInfo     Server information for connection
   * @throws  Exception  Error during connection setup
   */
  public static void setupBrokerConnection(ProviderInfo proInfo) throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("Creating a connection to broker: " + proInfo.getProviderURL());
    }

    try {

      Hashtable properties = new Hashtable();

      // Get initial context factory from ProviderInfo
      properties.put(Context.INITIAL_CONTEXT_FACTORY, proInfo.getProviderICF());
      properties.put(Context.PROVIDER_URL, proInfo.getProviderURL());
      Context context = new InitialContext(properties);

      Connection conn;

      // Queue or Topic ?
      if (proInfo.getDestType() == Util.QUEUE) {

        if (log.isDebugEnabled()) {
          log.debug("Creating a queue connection");
        }

        QueueConnectionFactory qcf = (QueueConnectionFactory) context.lookup("JmsQueueConnectionFactory");

        if (proInfo.getUsername() == null) {
          conn = qcf.createQueueConnection();
        } else {
          conn = qcf.createQueueConnection(proInfo.getUsername(),
              proInfo.getPassword());
        }
      } else {

        if (log.isDebugEnabled()) {
          log.debug("Creating a topic connection");
        }

        TopicConnectionFactory tcf = (TopicConnectionFactory) context.lookup("JmsTopicConnectionFactory");

        if (proInfo.getUsername() == null) {
          conn = tcf.createTopicConnection();
        } else {
          conn = tcf.createTopicConnection(proInfo.getUsername(),
              proInfo.getPassword());
        }
      }

      if (log.isDebugEnabled()) {
        log.debug("Start the new connection");
      }

      conn.start();

      if (log.isDebugEnabled()) {
        log.debug("Placing the connection into the hashmap");
      }

      brokerConnections.put((proInfo.getDestType() == Util.QUEUE ? "queue" : "topic") + ":" + proInfo.getUsername() + ":" + proInfo.getProviderURL(), conn);

    } catch (Exception e) {
      log.error("Failed to create connection to destination:" + e.toString());
      throw new Exception("Failed to create connection to destination: " + e.toString(), e);
    }
  }


  /**
   *  Close all connections in the hashmap
   */
  public static void closeBrokerConnections() {

    if (log.isDebugEnabled()) {
      log.debug("Close all connections in the hashmap");
    }

    Set conns = brokerConnections.entrySet();

    for (Iterator i = conns.iterator(); i.hasNext(); ) {

      Connection temp = (Connection) i.next();

      try {
        temp.stop();
        temp.close();
      } catch (Exception e) {
        // Ignore the closing errors
      }
    }

    brokerConnections.clear();
  }
}

