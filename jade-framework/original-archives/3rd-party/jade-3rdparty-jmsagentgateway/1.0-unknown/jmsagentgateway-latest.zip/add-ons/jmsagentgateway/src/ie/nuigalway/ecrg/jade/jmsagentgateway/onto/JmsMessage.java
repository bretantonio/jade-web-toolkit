/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.onto;

import jade.content.*;
import jade.core.*;
import jade.util.leap.*;

/**
 *  Concept used to represent a JMS Message Protege name: JmsMessage
 *
 * @author     ontology bean generator
 * @version    2004/03/31, 18:54:36
 */
public class JmsMessage implements Concept {

  /**
   *  JMS Destination Protege name: destination
   */
  private String destination;

  /**
   *  Time-to-Live value of message Protege name: timeToLive
   */
  private int timeToLive;

  /**
   *  Set to TRUE for PERSISTENT Set to FALSE for NON_PERSISTENT Protege name:
   *  deliveryMode
   */
  private boolean deliveryMode;

  /**
   *  Collection of Properties Protege name: properties
   */
  private List properties = new ArrayList();

  /**
   *  Message Priority Protege name: priority
   */
  private int priority;

  /**
   *  Message Payload Protege name: payload
   */
  private String payload;


  /**
   *  Sets the destination attribute of the JmsMessage object
   *
   * @param  value  The new destination value
   */
  public void setDestination(String value) {
    this.destination = value;
  }


  /**
   *  Gets the destination attribute of the JmsMessage object
   *
   * @return    The destination value
   */
  public String getDestination() {
    return this.destination;
  }


  /**
   *  Sets the timeToLive attribute of the JmsMessage object
   *
   * @param  value  The new timeToLive value
   */
  public void setTimeToLive(int value) {
    this.timeToLive = value;
  }


  /**
   *  Gets the timeToLive attribute of the JmsMessage object
   *
   * @return    The timeToLive value
   */
  public int getTimeToLive() {
    return this.timeToLive;
  }


  /**
   *  Sets the deliveryMode attribute of the JmsMessage object
   *
   * @param  value  The new deliveryMode value
   */
  public void setDeliveryMode(boolean value) {
    this.deliveryMode = value;
  }


  /**
   *  Gets the deliveryMode attribute of the JmsMessage object
   *
   * @return    The deliveryMode value
   */
  public boolean getDeliveryMode() {
    return this.deliveryMode;
  }


  /**
   *  Adds a feature to the Properties attribute of the JmsMessage object
   *
   * @param  elem  The feature to be added to the Properties attribute
   */
  public void addProperties(Property elem) {
    List oldList = this.properties;
    properties.add(elem);
  }


  /**
   *  Description of the Method
   *
   * @param  elem  Description of the Parameter
   * @return       Description of the Return Value
   */
  public boolean removeProperties(Property elem) {
    List oldList = this.properties;
    boolean result = properties.remove(elem);
    return result;
  }


  /**
   *  Description of the Method
   */
  public void clearAllProperties() {
    List oldList = this.properties;
    properties.clear();
  }


  /**
   *  Gets the allProperties attribute of the JmsMessage object
   *
   * @return    The allProperties value
   */
  public Iterator getAllProperties() {
    return properties.iterator();
  }


  /**
   *  Gets the properties attribute of the JmsMessage object
   *
   * @return    The properties value
   */
  public List getProperties() {
    return properties;
  }


  /**
   *  Sets the properties attribute of the JmsMessage object
   *
   * @param  l  The new properties value
   */
  public void setProperties(List l) {
    properties = l;
  }


  /**
   *  Sets the priority attribute of the JmsMessage object
   *
   * @param  value  The new priority value
   */
  public void setPriority(int value) {
    this.priority = value;
  }


  /**
   *  Gets the priority attribute of the JmsMessage object
   *
   * @return    The priority value
   */
  public int getPriority() {
    return this.priority;
  }


  /**
   *  Sets the payload attribute of the JmsMessage object
   *
   * @param  value  The new payload value
   */
  public void setPayload(String value) {
    this.payload = value;
  }


  /**
   *  Gets the payload attribute of the JmsMessage object
   *
   * @return    The payload value
   */
  public String getPayload() {
    return this.payload;
  }

}

