/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway;

import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.ProviderInfo;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Subscription;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.apache.log4j.Category;

/**
 *  General utility class for agent
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class Util {

  /**
   *  Persistent message setting
   */
  public final static boolean PERSISTENT = true;

  /**
   *  Non persistent message setting
   */
  public final static boolean NON_PERSISTENT = false;

  /**
   *  Topic setting
   */
  public final static boolean TOPIC = true;

  /**
   *  Queue setting
   */
  public final static boolean QUEUE = false;

  /**
   *  Durable subscription setting
   */
  public final static boolean DURABLE = true;

  /**
   *  Non durable subscription setting
   */
  public final static boolean NON_DURABLE = false;

  private static Category log = Category.getRoot();


  /**
   *  General utility method for creating a message
   *
   * @param  destination    destination of message
   * @param  payload        The messages payload (Can be any Serializable Java
   *      object)
   * @param  deliveryMode   Persistent setting of the message
   * @return                Newly created Jms Message
   * @exception  Exception  Error creating the message
   */
  public static JmsMessage createMessage(String destination, java.io.Serializable payload, boolean deliveryMode) throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("Creating new message for: " + destination);
    }

    JmsMessage msg = new JmsMessage();

    msg.setDestination(destination);
    msg.setPayload(convertObjectToString(payload));
    msg.setDeliveryMode(deliveryMode);

    // Defaults Settings
    msg.setTimeToLive(0);

    return msg;
  }


  /**
   *  Utility method to create a Subscription
   *
   * @param  destination  Topic or Queue to subscribe to
   * @param  durable      Subsctiptions durability setting
   * @return              Newley created subscription info
   */
  public static Subscription createSubscription(String destination, boolean durable) {

    if (log.isDebugEnabled()) {
      log.debug("Create a subscription to: " + destination);
    }

    Subscription sub = new Subscription();

    sub.setDestination(destination);
    sub.setDurable(durable);

    return sub;
  }


  /**
   *  Utility method for creating server information
   *
   * @param  providerURL  URL of the server
   * @param  providerICF  Initial Connection Factory Class
   * @param  destType     Queue or Topic Destination
   * @return              Returns a server information object
   */
  public static ProviderInfo createProviderInfo(boolean destType, String providerURL, String providerICF) {

    if (log.isDebugEnabled()) {
      log.debug("Creating server infformation for: " + providerURL);
    }

    ProviderInfo proInfo = new ProviderInfo();

    proInfo.setDestType(destType);
    proInfo.setProviderURL(providerURL);
    proInfo.setProviderICF(providerICF);

    return proInfo;
  }


  /**
   *  Convert a BASE64 string payload to a serializable object
   *
   * @param  payload        BASE64 string messages payload
   * @return                Serialized payload string
   * @exception  Exception  Error during conversion
   */
  public static java.io.Serializable convertStringToObject(String payload) throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("Converting the payload string to a serializable object");
    }

    try {

      ObjectInputStream oin = new ObjectInputStream(
          new ByteArrayInputStream(new sun.misc.BASE64Decoder().decodeBuffer(payload)));

      java.io.Serializable s = (java.io.Serializable) oin.readObject();

      return s;
    } catch (IOException ioe) {
      log.error("Error in converting payload string to serializableobject " + ioe.toString());
      throw new Exception("Error converting String to Object", ioe);
    }
  }


  /**
   *  Convert an object to a BASE64 string
   *
   * @param  obj            Payload object
   * @return                Payload object converted to a BASE64 string
   * @exception  Exception  Error during object to string conversion
   */
  public static String convertObjectToString(java.io.Serializable obj) throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("Converting the payload object to a string");
    }

    try {

      ByteArrayOutputStream c = new ByteArrayOutputStream();
      ObjectOutputStream oos = new ObjectOutputStream(c);
      oos.writeObject(obj);
      oos.flush();

      return new sun.misc.BASE64Encoder().encode(c.toByteArray());
    } catch (IOException ioe) {
      log.error("Error converting object to string " + ioe.toString());
      throw new Exception("Error converting object to string", ioe);
    }
  }
}

