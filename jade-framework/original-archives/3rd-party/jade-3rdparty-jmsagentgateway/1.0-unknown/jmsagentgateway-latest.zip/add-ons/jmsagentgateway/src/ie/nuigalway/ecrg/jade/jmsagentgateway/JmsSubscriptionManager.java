/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway;

import ie.nuigalway.ecrg.jade.jmsagentgateway.gui.JmsAgentGatewayGui;
import ie.nuigalway.ecrg.jade.jmsagentgateway.gui.SubscriptionModel;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Subscribe;

import jade.content.ContentManager;
import jade.content.onto.basic.Action;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.lang.acl.ACLMessage;
import jade.proto.SubscriptionResponder;

import java.util.HashMap;

import org.apache.log4j.Category;

/**
 *  Implementation of the Subscription Manager for the JMS Pub Sub Agent
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class JmsSubscriptionManager implements SubscriptionResponder.SubscriptionManager {

  private static Category log = Category.getRoot();

  private HashMap listenerMap;// stores the desitnation listeners
  private ContentManager cm;
  private JmsAgentGatewayGui gui;


  /**
   *  Constructor for the JmsSubscriptionManager object
   */
  public JmsSubscriptionManager() {
    super();

    if (log.isDebugEnabled()) {
      log.debug("JmsSubscriptionManager Started");
    }

    listenerMap = new HashMap();
  }


  /**
   *  Sets the contentManager attribute of the JmsSubscriptionManager object
   *
   * @param  cm  The new contentManager value
   */
  public void setContentManager(jade.content.ContentManager cm) {
    this.cm = cm;
  }


  /**
   *  Sets the gUI attribute of the JmsSubscriptionManager object
   *
   * @param  gui  The new gUI value
   */
  public void setGUI(JmsAgentGatewayGui gui) {
    this.gui = gui;
  }


  /**
   *  Register a new subscription request with the manager
   *
   * @param  sub                         Subscription information
   * @return                             Result of registration
   * @exception  RefuseException         Refuse subscription
   * @exception  NotUnderstoodException  Not understood
   */
  public boolean register(SubscriptionResponder.Subscription sub) throws RefuseException, NotUnderstoodException {

    if (log.isDebugEnabled()) {
      log.debug("Registering Subscription:");
    }

    try {

      Subscribe subscribe = (Subscribe) ((Action) cm.extractContent(sub.getMessage())).getAction();
      SubscriptionModel subModel = new SubscriptionModel(sub, subscribe);

      JmsListener jmsL = new JmsListener(sub, cm, gui, subModel);

      listenerMap.put(sub, jmsL);

      if (gui != null) {
        gui.addSubscription(subModel);
      }
    } catch (Exception e) {
      log.error("Error adding the listener to the listenerMap: " + e.toString());

      ACLMessage reply = sub.getMessage().createReply();
      reply.setPerformative(ACLMessage.REFUSE);
      throw new RefuseException(reply.toString());
    }

    if (log.isDebugEnabled()) {
      log.debug("Subscription Added");
    }

    return true;
  }


  /**
   *  Deregister a subscription from the manager
   *
   * @param  sub                   Subscription to deregister
   * @return                       Result of the deregistration
   * @exception  FailureException  Failure result
   */
  public boolean deregister(SubscriptionResponder.Subscription sub) throws FailureException {

    if (log.isDebugEnabled()) {
      log.debug("Deregistering Subscription:");
    }

    try {
      ACLMessage reply = sub.getMessage().createReply();
      reply.setPerformative(ACLMessage.FAILURE);
      sub.notify(reply);

      // Get string from the TA and remove item from hash
      ((JmsListener) listenerMap.get(sub)).stop();

      if (gui != null) {
        gui.removeSubscription(((JmsListener) listenerMap.get(sub)).getSubscriptionModel());
      }

      listenerMap.remove(sub);

    } catch (Exception e) {
      log.error("Error removing subscription: " + e.toString());
      //ignore failure
    }
    return false;
  }
  /*
   *  public void removeAllQL () throws Exception {
   *  if (log.isDebugEnabled()) {
   *  log.debug("Removing all QLs");
   *  }
   *  / Get all the QLs
   *  Set keys = listenerMap.keySet();
   *  / Remove each of the QLs
   *  for (Iterator i = keys.iterator(); i.hasNext();) {
   *  try {
   *  this.removeQL((String) i.next());
   *  } catch (Exception e) {
   *  throw e;
   *  }
   *  }
   *  }
   *  }
   */
}

