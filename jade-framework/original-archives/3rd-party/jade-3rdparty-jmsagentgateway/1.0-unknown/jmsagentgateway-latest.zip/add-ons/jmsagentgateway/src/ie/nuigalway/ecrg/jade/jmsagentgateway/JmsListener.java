/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway;

import ie.nuigalway.ecrg.jade.jmsagentgateway.gui.JmsAgentGatewayGui;
import ie.nuigalway.ecrg.jade.jmsagentgateway.gui.SubscriptionModel;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsAgentGatewayOntology;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.OnMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Property;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.ProviderInfo;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Subscribe;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Subscription;

import jade.content.ContentElement;
import jade.content.ContentManager;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.Ontology;
import jade.content.onto.basic.Action;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.proto.SubscriptionResponder;

import java.util.Enumeration;

import javax.jms.Connection;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;

import org.apache.log4j.Category;


/**
 *  Listener for destinations in the subscription manager
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class JmsListener implements javax.jms.MessageListener, javax.jms.ExceptionListener {

  private static Category log = Category.getRoot();

  private Connection conn;
  private Session session;

  private SubscriptionResponder.Subscription sub;

  private ContentManager cm;
  private Codec codec = new SLCodec();
  private Ontology ontology = JmsAgentGatewayOntology.getInstance();

  private Subscription jmsSub;
  private ProviderInfo proInfo;

  private JmsAgentGatewayGui gui;
  private SubscriptionModel subModel;


  /**
   *  Constructor for the JmsListener object
   *
   * @param  sub            Subscription for listener
   * @param  cm             Content manager for message ontologies
   * @param  gui            GUI associated with the agent
   * @param  subModel       GUI Model of this subscription
   * @exception  Exception  Error during listener startup
   */
  public JmsListener(SubscriptionResponder.Subscription sub, ContentManager cm, JmsAgentGatewayGui gui, SubscriptionModel subModel) throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("New JmsListener Setup");
    }
    this.gui = gui;
    this.subModel = subModel;
    this.cm = cm;

    ContentElement content = cm.extractContent(sub.getMessage());
    Subscribe msgSub = (Subscribe) ((Action) content).getAction();
    this.jmsSub = msgSub.getSubscription();
    this.proInfo = msgSub.getProviderInfo();
    this.sub = sub;

    // Start the listener
    try {
      this.setupConnection();
    } catch (Exception e) {
      log.error("Error in JmsListener connection setup:" + e.toString());
      throw e;
    }

    if (log.isDebugEnabled()) {
      log.debug("JmsListener Setup Complete");
    }
  }


  /**
   *  Method is executed in order to create a connection to a JMS server and
   *  listen to the specified destination
   *
   * @exception  Exception  Description of the Exception
   */
  private void setupConnection() throws Exception {

    conn = JMS_Util.getBrokerConnection(proInfo);

    if (log.isDebugEnabled()) {
      log.debug("Looking up destination");
    }

    // Setup Filters
    MessageConsumer msgCon;

    if (proInfo.getDestType() == Util.QUEUE) {

      session = ((QueueConnection) conn).createQueueSession(false, QueueSession.AUTO_ACKNOWLEDGE);
      QueueSession queueSession = (QueueSession) session;
      Queue que = queueSession.createQueue(jmsSub.getDestination());

      if ((jmsSub.getSelector() != null) && (jmsSub.getSelector().equals(""))) {
        msgCon = queueSession.createReceiver(que);
      } else {
        msgCon = queueSession.createReceiver(que, jmsSub.getSelector());
      }

    } else {
      session = ((TopicConnection) conn).createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
      TopicSession topicSession = (TopicSession) session;
      Topic top = topicSession.createTopic(jmsSub.getDestination());

      if (jmsSub.getDurable() == Util.DURABLE) {

        if ((jmsSub.getSelector() != null) && (jmsSub.getSelector().equals(""))) {
          msgCon = topicSession.createDurableSubscriber(top, jmsSub.getDurableIdent());
        } else {
          msgCon = topicSession.createDurableSubscriber(top, jmsSub.getDurableIdent(), jmsSub.getSelector(), true);
        }

      } else {

        if ((jmsSub.getSelector() != null) && (jmsSub.getSelector().equals(""))) {
          msgCon = topicSession.createSubscriber(top);
        } else {
          msgCon = topicSession.createSubscriber(top, jmsSub.getSelector(), false);
        }

      }
    }

    msgCon.setMessageListener(this);

    if (log.isDebugEnabled()) {
      log.debug("Installing Exception Listener");
    }

    conn.setExceptionListener((javax.jms.ExceptionListener) this);

    if (log.isDebugEnabled()) {
      log.debug("Setup Complete");
    }
  }


  /**
   *  Method is executed when a message is receivd from the agents queue
   *
   * @param  msg  JMS Message received
   */
  public void onMessage(Message msg) {

    if (log.isDebugEnabled()) {
      log.debug("Incoming Message");
    }

    if (gui != null) {
      incMsgCounter();
    }

    OnMessage onMsg = new OnMessage();

    try {
      JmsMessage jmsMsg;

      if (msg instanceof ObjectMessage) {
        if (log.isDebugEnabled()) {
          log.debug("ObjectMessage");
        }
        jmsMsg = Util.createMessage(jmsSub.getDestination(), ((ObjectMessage) msg).getObject(), Util.PERSISTENT);
      } else if (msg instanceof TextMessage) {
        if (log.isDebugEnabled()) {
          log.debug("TextMessage");
        }
        jmsMsg = Util.createMessage(jmsSub.getDestination(), ((TextMessage) msg).getText(), Util.PERSISTENT);
      } else {
        if (log.isDebugEnabled()) {
          log.debug("Unsupported message format");
        }
        jmsMsg = Util.createMessage(jmsSub.getDestination(), "JMS Message Format not Supported", Util.PERSISTENT);
      }
      // Fill properties
      Enumeration propNames = msg.getPropertyNames();

      if (log.isDebugEnabled()) {
        log.debug("jmsListener Received: " + Util.convertStringToObject(jmsMsg.getPayload()));
      }

      while (propNames.hasMoreElements()) {

        String name = (String) propNames.nextElement();
        String value;

        // TODO:  BETTER SOLUTION NEEDED HERRE
        try {
          value = (msg.getStringProperty(name));
        } catch (Exception e) {
          value = "Error";
        }

        Property prop = new Property();
        prop.setPropName(name);
        prop.setPropValue(value);
        jmsMsg.addProperties(prop);
      }

      onMsg.setMessage(jmsMsg);
    } catch (Exception e) {
      log.error("Error castng message: " + e.toString());
    }

    ACLMessage aclMsg = new ACLMessage(ACLMessage.INFORM);
    aclMsg.setLanguage(codec.getName());
    aclMsg.setOntology(ontology.getName());

    try {
      Action act = new Action();
      act.setActor(new AID());
      act.setAction(onMsg);
      cm.fillContent(aclMsg, act);
    } catch (Exception e) {
      log.error("Error filling Content: " + e.toString());
    }

    sub.notify(aclMsg);
  }


  /**
   *  Method is executed when an execption is thrown by the JMS Provider
   *  Attempts to reconnect to the provider
   *
   * @param  jmse  JMS Exception thrown
   */
  public void onException(javax.jms.JMSException jmse) {

    log.error("Exception Thrown: " + jmse.toString());

    if (log.isDebugEnabled()) {
      log.debug("Attempt to Re-establish the connection to the JMS Provider");
    }

    conn = null;

    // Reestablish the connection
    while (conn == null) {

      try {

        if (log.isDebugEnabled()) {
          log.debug("Sleeping for 10 Seconds");
        }

        Thread.sleep(10000);
      } catch (Exception e) {

      }

      try {
        setupConnection();
      } catch (Exception e) {

        continue;
      }
    }
  }


  /**
   *  Method is executed to disconnect from a JMS server
   *
   * @throws  Exception  Error in closeing JMS Connection
   */
  public void stop() throws Exception {

    if (log.isDebugEnabled()) {
      log.debug("Stopping listener");
    }

    session.close();

  }


  /**
   *  Increment message counter tracking the number of messages sent to this
   *  subscription
   */
  private void incMsgCounter() {
    subModel.incMsgCounter();
    gui.updateSubscriptions();
  }


  /**
   *  Gets the subscriptionModel attribute of the JmsListener object
   *
   * @return    The subscriptionModel value
   */
  public SubscriptionModel getSubscriptionModel() {
    return subModel;
  }

}

