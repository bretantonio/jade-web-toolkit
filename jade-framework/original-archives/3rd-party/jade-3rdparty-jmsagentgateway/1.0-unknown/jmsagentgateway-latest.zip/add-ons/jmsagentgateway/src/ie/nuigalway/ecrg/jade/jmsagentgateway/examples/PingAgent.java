/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.examples;
import ie.nuigalway.ecrg.jade.jmsagentgateway.Util;

import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsAgentGatewayOntology;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.JmsMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.OnMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.PublishMessage;
import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Subscribe;

import jade.content.ContentElement;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.Ontology;
import jade.content.onto.basic.Action;
import jade.content.AgentAction;
import jade.core.AID;
import jade.core.Agent;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.proto.SubscriptionInitiator;


/**
 *  Example PingClient agent used to interact with the JmsProxyAgent
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class PingAgent extends Agent {

  private AID jmsProxyAgent;

  private Codec codec = new SLCodec();
  private Ontology ontology = JmsAgentGatewayOntology.getInstance();


  /**
   *  Setup the agent
   */
  protected void setup() {

    // Register language and ontology
    getContentManager().registerLanguage(codec);
    getContentManager().registerOntology(ontology);

    lookupAgent();

    // Set this agent main behaviour
    addBehaviour(new JmsSubscriptionInitiator(this, getSubscriptionMsg()));
  }


  /**
   *  Utility messgea to publish a pong
   *
   * @param  payload  Payload of the message to be published
   */
  private void publishPong(String payload) {

    PublishMessage pm = new PublishMessage();

    try {
      pm.setMessage(Util.createMessage("pingAgent/pong", payload, Util.PERSISTENT));
    } catch (Exception e) {
      System.out.println("Error creating message:" + e.toString());
    }

    // Using a connection with the openJMS provider
    pm.setProviderInfo(Util.createProviderInfo(Util.TOPIC, "rmi://localhost:1099/", "org.exolab.jms.jndi.InitialContextFactory"));

    System.out.println("Sending message: " + payload);
    sendMessage(ACLMessage.REQUEST, pm);
  }


  /**
   *  Utility method for sending a message
   *
   * @param  performative  Performative for the message
   * @param  action        The AgentAction of the message to be sent
   */
  private void sendMessage(int performative, AgentAction action) {

    ACLMessage msg = new ACLMessage(performative);
    msg.setLanguage(codec.getName());
    msg.setOntology(ontology.getName());

    try {
      getContentManager().fillContent(msg, new Action(jmsProxyAgent, action));
      msg.addReceiver(jmsProxyAgent);

      send(msg);
    } catch (Exception e) {
      System.out.println("Error sending message:" + e.toString());
      e.printStackTrace();
    }
  }


  /**
   *  Create a subscription message
   *
   * @return    The subscriptionMsg value
   */
  private ACLMessage getSubscriptionMsg() {

    Subscribe sub = new Subscribe();
    sub.setSubscription(Util.createSubscription("pingAgent/ping", Util.NON_DURABLE));

    // Using a connection with the openJMS provider
    sub.setProviderInfo(Util.createProviderInfo(Util.QUEUE, "rmi://localhost:1099/", "org.exolab.jms.jndi.InitialContextFactory"));

    ACLMessage msg = new ACLMessage(ACLMessage.SUBSCRIBE);
    msg.setLanguage(codec.getName());
    msg.setOntology(ontology.getName());

    try {
      getContentManager().fillContent(msg, new Action(jmsProxyAgent, sub));
      msg.addReceiver(jmsProxyAgent);
    } catch (Exception e) {
      System.out.println("Error populating subscription message:" + e.toString());
      e.printStackTrace();
    }

    return msg;
  }


  /**
   *  Lookup the JmsProxyAgent
   */
  private void lookupAgent() {

    // Publisher Agent
    ServiceDescription sd = new ServiceDescription();
    sd.setType("JmsProxyAgent");

    DFAgentDescription dfd = new DFAgentDescription();
    dfd.addServices(sd);

    try {
      DFAgentDescription[] dfds = DFService.search(this, dfd);

      if (dfds.length > 0) {
        jmsProxyAgent = dfds[0].getName();
      } else {
        System.out.println("Couldn't localize server!");
      }

    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("Failed searching int the DF!");
    }
  }


  /**
   *  Implementation of the SubscriptionInitiator interface
   *
   * @author     Edward Curry created 08 December 2003 * *
   * @version    0.5 12 January 2004
   */
  class JmsSubscriptionInitiator extends SubscriptionInitiator {

    private int counter = 0;
    Agent agent;


    /**
     *  Constructor for the JmsSubscriptionInitiator object
     *
     * @param  a    Agent involved in this interaction
     * @param  msg  Subscription message to send
     */
    JmsSubscriptionInitiator(Agent a, ACLMessage msg) {
      super(a, msg);
      agent = a;
    }


    /**
     *  Method called when a Agree message is received
     *
     * @param  agree  Agree message received
     */
    protected void handleAgree(ACLMessage agree) {
      System.out.println("Handle Agree");
    }


    /**
     *  Method called when a Refuse message is received
     *
     * @param  refuse  Refuse message received
     */
    protected void handleRefuse(ACLMessage refuse) {
      System.out.println("Handle Refuse");
    }


    /**
     *  Method called when a NotUnderstood message is recceived
     *
     * @param  notUnderstood  NotUnderstood message received
     */
    protected void handleNotUnderstood(ACLMessage notUnderstood) {
      System.out.println("Handle not understood");
    }


    /**
     *  Method called when a Inform message is received
     *
     * @param  inform  Inform message received
     */
    protected void handleInform(ACLMessage inform) {
      System.out.println("Handle Inform");

      try {

        ContentElement content = getContentManager().extractContent(inform);
        OnMessage om = (OnMessage) ((Action) content).getAction();
        JmsMessage jmsMsg = om.getMessage();

        counter++;
        System.out.println("Message Received: Payload:" + ((String) Util.convertStringToObject(jmsMsg.getPayload())));

        // Send pong message
        publishPong("Pong" + counter);

      } catch (Exception e) {
        e.printStackTrace();
      }
    }


    /**
     *  Method called when a Failure message is received
     *
     * @param  failure  Failure message received
     */
    protected void handleFailure(ACLMessage failure) {
      System.out.println("Handle Failure");
    }
  }
}

