/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.onto;

import jade.content.*;
import jade.core.*;
import jade.util.leap.*;

/**
 *  Action used to request a subscription Protege name: Subscribe
 *
 * @author     ontology bean generator
 * @version    2004/03/31, 18:54:36
 */
public class Subscribe implements AgentAction {

  /**
   *  Connection information for the JMS Server Protege name: providerInfo
   */
  private ProviderInfo providerInfo;

  /**
   *  Requested Subscription Protege name: subscription
   */
  private Subscription subscription;


  /**
   *  Sets the providerInfo attribute of the Subscribe object
   *
   * @param  value  The new providerInfo value
   */
  public void setProviderInfo(ProviderInfo value) {
    this.providerInfo = value;
  }


  /**
   *  Gets the providerInfo attribute of the Subscribe object
   *
   * @return    The providerInfo value
   */
  public ProviderInfo getProviderInfo() {
    return this.providerInfo;
  }


  /**
   *  Sets the subscription attribute of the Subscribe object
   *
   * @param  value  The new subscription value
   */
  public void setSubscription(Subscription value) {
    this.subscription = value;
  }


  /**
   *  Gets the subscription attribute of the Subscribe object
   *
   * @return    The subscription value
   */
  public Subscription getSubscription() {
    return this.subscription;
  }

}

