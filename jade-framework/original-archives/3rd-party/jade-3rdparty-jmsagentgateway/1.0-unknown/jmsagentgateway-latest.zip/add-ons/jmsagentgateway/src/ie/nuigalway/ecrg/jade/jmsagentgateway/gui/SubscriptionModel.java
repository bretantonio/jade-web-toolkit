/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.gui;
import ie.nuigalway.ecrg.jade.jmsagentgateway.Util;

import ie.nuigalway.ecrg.jade.jmsagentgateway.onto.Subscribe;

import jade.proto.SubscriptionResponder;

/**
 *  Subscription list model
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */
public class SubscriptionModel {

  private String sender;
  private String providerURL;
  private String destination;
  private String destType;
  private String durable;
  private int msgCounter;//  Counts the number of messages sent to this subscription

  private SubscriptionResponder.Subscription subscription;


  /**
   *  Constructor for the SubscriptionModel object
   *
   * @param  subscription  Subscription to add
   * @param  sub           Subscribe request
   */
  public SubscriptionModel(SubscriptionResponder.Subscription subscription, Subscribe sub) {
    this.subscription = subscription;
    this.sender = subscription.getMessage().getSender().getName();
    this.providerURL = sub.getProviderInfo().getProviderURL();
    this.destination = sub.getSubscription().getDestination();
    this.destType = (sub.getProviderInfo().getDestType() == Util.QUEUE) ? "Queue" : "Topic";
    this.durable = (sub.getSubscription().getDurable() == Util.DURABLE) ? "Durable" : "Non_Durable";
    this.msgCounter = 0;
  }


  /**
   *  Sets the sender attribute of the SubscriptionModel object
   *
   * @param  value  The new sender value
   */
  public void setSender(String value) {
    this.sender = value;
  }


  /**
   *  Gets the sender attribute of the SubscriptionModel object
   *
   * @return    The sender value
   */
  public String getSender() {
    return this.sender;
  }


  /**
   *  Sets the providerURL attribute of the SubscriptionModel object
   *
   * @param  value  The new providerURL value
   */
  public void setProviderURL(String value) {
    this.providerURL = value;
  }


  /**
   *  Gets the providerURL attribute of the SubscriptionModel object
   *
   * @return    The providerURL value
   */
  public String getProviderURL() {
    return this.providerURL;
  }


  /**
   *  Sets the destination attribute of the SubscriptionModel object
   *
   * @param  value  The new destination value
   */
  public void setDestination(String value) {
    this.destination = value;
  }


  /**
   *  Gets the destination attribute of the SubscriptionModel object
   *
   * @return    The destination value
   */
  public String getDestination() {
    return this.destination;
  }


  /**
   *  Sets the destType attribute of the SubscriptionModel object
   *
   * @param  value  The new destType value
   */
  public void setDestType(String value) {
    this.destType = value;
  }


  /**
   *  Gets the destType attribute of the SubscriptionModel object
   *
   * @return    The destType value
   */
  public String getDestType() {
    return this.destType;
  }


  /**
   *  Sets the durable attribute of the SubscriptionModel object
   *
   * @param  value  The new durable value
   */
  public void setDurable(String value) {
    this.durable = value;
  }


  /**
   *  Gets the durable attribute of the SubscriptionModel object
   *
   * @return    The durable value
   */
  public String getDurable() {
    return this.durable;
  }


  /**
   *  Increment the counter tracking the number of messages sent to this client
   */
  public void incMsgCounter() {
    this.msgCounter++;
  }


  /**
   *  Gets the msgCounter attribute of the SubscriptionModel object
   *
   * @return    The msgCounter value
   */
  public int getMsgCounter() {
    return this.msgCounter;
  }


  /**
   *  Sets the subscription attribute of the SubscriptionModel object
   *
   * @param  value  The new subscription value
   */
  public void setSubscription(SubscriptionResponder.Subscription value) {
    this.subscription = value;
  }


  /**
   *  Gets the subscription attribute of the SubscriptionModel object
   *
   * @return    The subscription value
   */
  public SubscriptionResponder.Subscription getSubscription() {
    return this.subscription;
  }

}

