/*
 *  (c) Copyright Enterprise Computing Research Group (ECRG),
 *  National University of Ireland, Galway 2003/2004.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of
 *  the GNU Lesser General Public License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE and
 *  no warranty that the program does not infringe the Intellectual Property rights of a third party.
 *  See the GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License along with this program;
 *  if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package ie.nuigalway.ecrg.jade.jmsagentgateway.examples;

import ie.nuigalway.ecrg.jade.jmsagentgateway.Util;

import java.util.Properties;
import java.util.Set;

import javax.jms.JMSException;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.*;

/**
 *  Simple application for showing how to ping the PingAgent byt sending a
 *  message to the pingAgent/ping queue and lisenting for a response on the
 *  pingAgent/pong topic
 *
 * @author     Edward Curry
 * @version    0.5 12 January 2004
 */

public class PingClient implements MessageListener {

  private QueueConnectionFactory queueConnectionFactory = null;
  private QueueConnection queueConnection = null;
  private TopicConnectionFactory topicConnectionFactory = null;
  private TopicConnection topicConnection = null;
  private TopicSubscriber subscriber;
  private int _count = 10;
  private int _received = 0;
  private boolean _summary = false;


  /**
   *  Constructor for the PingClient object
   */
  public PingClient() {

    try {

      // Connect to JMS provider
      Properties props = new Properties();
      props.put(Context.INITIAL_CONTEXT_FACTORY, "org.exolab.jms.jndi.InitialContextFactory");
      props.put(Context.PROVIDER_URL, "rmi://localhost:1099");

      InitialContext ctx = new InitialContext(props);

      // Setup queue connection
      QueueConnectionFactory queueFactory = (QueueConnectionFactory) ctx.lookup("JmsQueueConnectionFactory");
      QueueConnection queueConnection = queueFactory.createQueueConnection();
      queueConnection.start();
      QueueSession queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

      // Setup topic connection
      TopicConnectionFactory topicFactory = (TopicConnectionFactory) ctx.lookup("JmsTopicConnectionFactory");
      TopicConnection topicConnection = topicFactory.createTopicConnection();
      topicConnection.start();

      TopicSession topicSession = topicConnection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);

      // Lookup 'pingAgent/pong' topic and listen for pongs
      Topic topic = (Topic) ctx.lookup("pingAgent/pong");
      subscriber = topicSession.createSubscriber(topic);
      subscriber.setMessageListener(this);

      // Send pings to the 'pingAgent/ping' queue
      Queue pingQueue = (Queue) ctx.lookup("pingAgent/ping");
      QueueSender sender = queueSession.createSender(pingQueue);
      TextMessage txtMsg = queueSession.createTextMessage();

      txtMsg.setText("ping");

      for (int ii = 1; ii <= _count; ii++) {
        System.out.println("Sending Ping" + ii + " : ");// + txtMsg);
        sender.send(txtMsg);
      }
    } catch (Exception ex) {
      System.out.println("Exception: " + ex.toString());
    }
  }


  /**
   *  The main program for the PingClient class
   *
   * @param  args  The command line arguments
   */
  public static void main(String[] args) {
    new PingClient();
  }


  /**
   *  All messages that for this listener are received by this method
   *
   * @param  msg  Description of the Parameter
   */
  public void onMessage(Message msg) {

    // Count messages received
    _received++;
    System.out.println("[" + _received + " of " + _count + "] ");

    // Decode received message
    try {
      String msgPayload;

      if (msg instanceof ObjectMessage) {
        System.out.println("ObjectMessage");
        msgPayload = (String) ((ObjectMessage) msg).getObject();
      } else if (msg instanceof TextMessage) {
        System.out.println("TextMessage");
        msgPayload = ((TextMessage) msg).getText();
      } else {
        System.out.println("Unsupported Message Format");
        msgPayload = "Unsupported Message Format";
      }

      System.out.println("Message body:" + msgPayload);
    } catch (Exception jmse) {
      System.out.println("Error in JMS Message Extraction: " + jmse.toString());
    }
  }
}

