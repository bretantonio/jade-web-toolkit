package aclanalyser;

import org.jgraph.graph.*;
import org.jgraph.JGraph;
import org.jgraph.layout.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Graph {

    private JGraph graph;
    private GraphModel model;
    private ConnectionSet cs;
    private DBAccess abd;
    private Matrix matrix;
    private LayoutAlgorithm algorithm;

    private Color[] colors = {Color.blue, Color.red, Color.yellow, Color.orange, Color.darkGray, Color.pink, Color.green, Color.gray, Color.magenta, Color.cyan, Color.lightGray, Color.white, new Color(7, 122, 43), new Color(64, 36, 1), new Color(100, 23, 45), new Color(200, 180, 13), new Color(171, 71, 232)};

    private AgentMark window = null;

    private DefaultGraphCell[] nodes = new DefaultGraphCell[ControlProtocol.MAX_AGENTS];
    private DefaultEdge[][] edges = new DefaultEdge[ControlProtocol.MAX_AGENTS][ControlProtocol.MAX_AGENTS];

    public Graph(DBAccess access, AgentMark window) {
        this(access);
        this.window = window;
    }

    public Graph(DBAccess access) {
        model = new DefaultGraphModel();
        graph = new JGraph(model);
        graph.setSelectNewCells(true);
        cs = new ConnectionSet();
        abd = access;
        matrix = abd.getMatrix();
        SpringEmbeddedLayoutController controller = new SpringEmbeddedLayoutController();
        algorithm = controller.getLayoutAlgorithm();
    }

    public void catchMouse() {
        graph.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                graph_mousePressed(e);
            }
        });
    }

    private DefaultGraphCell buildNode(String name, Map attributes, Color color) {

        DefaultGraphCell node = new DefaultGraphCell(name);

        Map attrib = GraphConstants.createMap();
        attributes.put(node, attrib);

        Rectangle bounds = new Rectangle(50, 50, 100, 25);
        GraphConstants.setBounds(attrib, bounds);
        GraphConstants.setBorderColor(attrib, Color.black);

        if (color != null) {
            GraphConstants.setBackground(attrib, color);
            GraphConstants.setOpaque(attrib, true);
        }

        DefaultPort port = new DefaultPort();
        node.add(port);

        return node;
    }

    private DefaultEdge buildEdge(String name, Map attributes, DefaultGraphCell n1, DefaultGraphCell n2, GraphModel model, ConnectionSet cs, int type) {
        // Get ports
        DefaultPort p1 = (DefaultPort) n1.getFirstChild();
        DefaultPort p2 = (DefaultPort) n2.getFirstChild();

        DefaultEdge edge = new DefaultEdge(name);

        Map edgeAttrib = GraphConstants.createMap();
        attributes.put(edge, edgeAttrib);

        GraphConstants.setLineEnd(edgeAttrib, type);
        GraphConstants.setEndFill(edgeAttrib, true);

        cs.connect(edge, p1, p2);

        return edge;
    }

    public JScrollPane showGraphMessages() {
        int ult;

        if (matrix == null)
            ult = 0;
        else
            ult = matrix.getNumAgents();

        Map attributes = new Hashtable();

        Object[] cells = new Object[ControlProtocol.MAX_ELEMENTS];
        int aux = 0;

        for (int i = 0; i < ult; i++) {
            nodes[i] = buildNode(matrix.getAgent(i), attributes, null);
            cells[aux++] = nodes[i];
        }

        int message;
        long size;
        for (int i = 0; i < ult; i++)
            for (int j = i + 1; j < ult; j++) {
                message = matrix.getMesssage(i, j) + matrix.getMesssage(j, i);
                size = matrix.getSize(i, j) + matrix.getSize(j, i);

                if (message != 0) {
                    edges[i][j] = buildEdge("" + message + " (" + size + " bytes)", attributes, nodes[i], nodes[j], model, cs, GraphConstants.ARROW_NONE);
                    cells[aux++] = edges[i][j];
                }
            }

        if (aux > 0) {
            Object[] cells2 = new Object[aux];
            for (int k = 0; k < aux; k++)
                cells2[k] = cells[k];

            model.insert(cells2, attributes, cs, null, null);
        }

        graph.setBendable(false);
        graph.setDisconnectable(false);
        graph.setEditable(false);

        sort();

        return new JScrollPane(graph);
    }

    public void sort() {
        if (matrix != null) algorithm.perform(graph, true, new Properties());
    }

    public void refresh() {
        Matrix aux = abd.getMatrix();
        if (aux != null) {
            int count = 0;
            Object[] cells = new Object[ControlProtocol.MAX_ELEMENTS];
            Map attributes = new Hashtable();

            // new nodes
            int before = matrix.getNumAgents();
            int after = aux.getNumAgents();

            if (before < after) {
                for (int i = before; i < after; i++) {
                    nodes[i] = buildNode(aux.getAgent(i), attributes, null);
                    cells[count++] = nodes[i];
                }
            }

            int older,newer;
            long size;

            // changes in old edges
            for (int i = 0; i < before; i++)
                for (int j = i + 1; j < before; j++) {
                    older = matrix.getMesssage(i, j) + matrix.getMesssage(j, i);
                    newer = aux.getMesssage(i, j) + aux.getMesssage(j, i);
                    if (older != newer) {
                        size = aux.getSize(i, j) + aux.getSize(j, i);
                        if (older == 0) {
                            edges[i][j] = buildEdge("" + newer + " (" + size + " bytes)", attributes, nodes[i], nodes[j], model, cs, GraphConstants.ARROW_NONE);
                            cells[count++] = edges[i][j];
                        } else
                            edges[i][j].setUserObject("" + newer + " (" + size + " bytes)");
                    }
                }

            // new edges
            for (int i = 0; i < before; i++)
                for (int j = before; j < after; j++) {
                    newer = aux.getMesssage(i, j) + aux.getMesssage(j, i);
                    if (newer != 0) {
                        size = aux.getSize(i, j) + aux.getSize(j, i);
                        edges[i][j] = buildEdge("" + newer + " (" + size + " bytes)", attributes, nodes[i], nodes[j], model, cs, GraphConstants.ARROW_NONE);
                        cells[count++] = edges[i][j];
                    }
                }


            for (int i = before; i < after; i++)
                for (int j = i + 1; j < after; j++) {
                    newer = aux.getMesssage(i, j) + aux.getMesssage(j, i);
                    if (newer != 0) {
                        size = aux.getSize(i, j) + aux.getSize(j, i);
                        edges[i][j] = buildEdge("" + newer + " (" + size + " bytes)", attributes, nodes[i], nodes[j], model, cs, GraphConstants.ARROW_NONE);
                        cells[count++] = edges[i][j];
                    }
                }

            matrix = aux;

            Object[] cells2 = new Object[count];
            for (int k = 0; k < count; k++)
                cells2[k] = cells[k];

            model.insert(cells2, attributes, cs, null, null);
        }
    }

    void graph_mousePressed(MouseEvent e) {
        Point point = graph.fromScreen(new Point(e.getPoint()));
        CellView view = graph.getNextViewAt(null, point.x, point.y);
        if (view != null) {
            Object obj = view.getCell();
            if (obj instanceof DefaultGraphCell) {
                if (!(obj instanceof DefaultEdge)) {
                    DefaultGraphCell cell = (DefaultGraphCell) obj;
                    window.agentMarked((String) cell.getUserObject());
                }
            }
        }
    }

    public JScrollPane showAgentIn(String agent) {
        if (matrix == null) return new JScrollPane();

        int ult = matrix.getNumAgents();
        int pos = 0;

        // Locate position of the agent
        for (pos = 0; pos < ult; pos++)
            if (agent.equals(matrix.getAgent(pos))) break;

        if (pos == ult) return new JScrollPane();

        Map attributes = new Hashtable();

        Object[] cells = new Object[ControlProtocol.MAX_ELEMENTS];
        DefaultGraphCell mainNode = buildNode(agent, attributes, Color.cyan);
        DefaultGraphCell node;
        DefaultEdge edge;
        cells[0] = mainNode;
        int aux = 1;
        int message;
        long size;

        for (int i = 0; i < ult; i++) {
            if (matrix.getMesssage(i, pos) > 0) {
                node = buildNode(matrix.getAgent(i), attributes, null);
                cells[aux++] = node;
                message = matrix.getMesssage(i, pos);
                size = matrix.getSize(i, pos);
                edge = buildEdge("" + message + " (" + size + " bytes)", attributes, node, mainNode, model, cs, GraphConstants.ARROW_CLASSIC);
                cells[aux++] = edge;
            }
        }

        Object[] cells2 = new Object[aux];
        for (int k = 0; k < aux; k++)
            cells2[k] = cells[k];

        model.insert(cells2, attributes, cs, null, null);

        graph.setBendable(false);
        graph.setDisconnectable(false);
        graph.setEditable(false);

        algorithm.perform(graph, true, new Properties());

        return new JScrollPane(graph);
    }

    public JScrollPane showAgentOut(String agent) {
        if (matrix == null) return new JScrollPane();

        int ult = matrix.getNumAgents();
        int pos = 0;

        // Locate position of the agent
        for (pos = 0; pos < ult; pos++)
            if (agent.equals(matrix.getAgent(pos))) break;

        if (pos == ult) return new JScrollPane();

        Map attributes = new Hashtable();

        Object[] cells = new Object[ControlProtocol.MAX_ELEMENTS];
        DefaultGraphCell mainNode = buildNode(agent, attributes, Color.cyan);
        DefaultGraphCell node;
        DefaultEdge edge;
        cells[0] = mainNode;
        int aux = 1;
        int message;
        long size;

        for (int i = 0; i < ult; i++) {
            if (matrix.getMesssage(pos, i) > 0) {
                node = buildNode(matrix.getAgent(i), attributes, null);
                cells[aux++] = node;
                message = matrix.getMesssage(pos, i);
                size = matrix.getSize(pos, i);
                edge = buildEdge("" + message + " (" + size + " bytes)", attributes, mainNode, node, model, cs, GraphConstants.ARROW_CLASSIC);
                cells[aux++] = edge;
            }
        }

        Object[] cells2 = new Object[aux];
        for (int k = 0; k < aux; k++)
            cells2[k] = cells[k];

        model.insert(cells2, attributes, cs, null, null);

        graph.setBendable(false);
        graph.setDisconnectable(false);
        graph.setEditable(false);

        algorithm.perform(graph, true, new Properties());

        return new JScrollPane(graph);
    }

    public void moreSize() {
        graph.setScale(graph.getScale() + 0.1);
    }

    public void lessSize() {
        if (graph.getScale() > 0.3)
            graph.setScale(graph.getScale() - 0.1);
    }

    private void colourAgent(String agent, Color color) {
        for (int i = 0; i < nodes.length; i++) {
            String nod = (String) nodes[i].getUserObject();
            if (nod.equals(agent)) {
                Map atrib = nodes[i].getAttributes();
                GraphConstants.setBackground(atrib, color);
                GraphConstants.setOpaque(atrib, true);
                break;
            }
        }
    }

    public void colour(LinkedList[] groups) {
        for (int i = 0; i < groups.length; i++) {
            Color col = colors[i % 11];
            for (int j = 0; j < groups[i].size(); j++) {
                String ag = (String) groups[i].get(j);
                colourAgent(ag, col);
            }
        }
    }

    public JScrollPane showSchema(LinkedList[] groups) {
        Object[] cells = new Object[ControlProtocol.MAX_ELEMENTS];
        DefaultGraphCell node;
        DefaultEdge edge;
        int aux = 0;
        Map attributes = new Hashtable();

        // First the nodes
        for (int i = 0; i < groups.length; i++) {
            node = buildNode("Group" + i, attributes, colors[i % 17]);
            cells[aux++] = node;
        }
        // then the edges
        int messages = 0;
        long size = 0;
        Matrix matrix = abd.getMatrix();
        if (matrix == null) return new JScrollPane();
        String ag1,ag2;
        int agent1,agent2;
        for (int i = 0; i < groups.length - 1; i++)
            for (int j = i + 1; j < groups.length; j++) {
                messages = 0;
                size = 0;
                // we compute messages from all to all between the two groups
                for (int k = 0; k < groups[i].size(); k++) {
                    ag1 = (String) groups[i].get(k);
                    agent1 = matrix.getAgentByName(ag1);
                    for (int l = 0; l < groups[j].size(); l++) {
                        ag2 = (String) groups[j].get(l);
                        agent2 = matrix.getAgentByName(ag2);
                        messages = messages + matrix.getMesssage(agent1, agent2) + matrix.getMesssage(agent2, agent1);
                        size = size + matrix.getSize(agent1, agent2) + matrix.getSize(agent2, agent1);
                    }
                }
                if (messages > 0) {
                    edge = buildEdge("" + messages + " (" + size + " bytes)", attributes, (DefaultGraphCell) cells[i], (DefaultGraphCell) cells[j], model, cs, GraphConstants.ARROW_NONE);
                    cells[aux++] = edge;
                }
            }

        Object[] cells2 = new Object[aux];
        for (int k = 0; k < aux; k++)
            cells2[k] = cells[k];

        model.insert(cells2, attributes, cs, null, null);

        graph.setBendable(false);
        graph.setDisconnectable(false);
        graph.setEditable(false);

        algorithm.perform(graph, true, new Properties());

        return new JScrollPane(graph);
    }
}