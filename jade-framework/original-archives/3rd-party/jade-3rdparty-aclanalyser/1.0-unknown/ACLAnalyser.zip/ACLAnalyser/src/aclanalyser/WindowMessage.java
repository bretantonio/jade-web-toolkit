package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

public class WindowMessage extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JButton exit = new JButton();
    private JButton view = new JButton();
    private JList jList1 = new JList();
    private JScrollPane jScrollPane1 = new JScrollPane();

    private WindowMain main;

    // Build the frame
    public WindowMessage(WindowMain win) {
        main = win;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "message.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Messages:");
        jLabel1.setBounds(new Rectangle(47, 22, 179, 21));
        contentPane.setLayout(null);
        this.setSize(new Dimension(397, 230));
        this.setTitle("Messages");
        exit.setBounds(new Rectangle(309, 146, 76, 27));
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exit_actionPerformed(e);
            }
        });
        view.setBounds(new Rectangle(309, 90, 76, 27));
        view.setText("Show");
        view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view_actionPerformed(e);
            }
        });
        jList1.setBorder(BorderFactory.createLineBorder(Color.black));
        jList1.setBounds(new Rectangle(32, 55, 257, 130));
        jScrollPane1.setBounds(new Rectangle(32, 55, 257, 130));
        contentPane.add(jLabel1, null);
        contentPane.add(exit, null);
        contentPane.add(view, null);
        contentPane.add(jList1, null);
        contentPane.add(jScrollPane1, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    public void fill(Vector vector) {
        if (vector.size() == 0) vector.add("No messages");
        jList1.setListData(vector);
        jScrollPane1.getViewport().setView(jList1);
    }

    void exit_actionPerformed(ActionEvent e) {
        setVisible(false);
        dispose();
    }

    void view_actionPerformed(ActionEvent e) {
        Object obj;

        obj = jList1.getSelectedValue();

        if (obj instanceof LocatedMessage) {
            LocatedMessage me = (LocatedMessage) obj;
            if (me != null) {
                WindowInfMessage frame = new WindowInfMessage(me);
                // Validate frames with preset sizes.
                // Pack frames with important size information. For instance about its design.
                frame.validate();

                // Center window
                Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                Dimension frameSize = frame.getSize();
                if (frameSize.height > screenSize.height) {
                    frameSize.height = screenSize.height;
                }
                if (frameSize.width > screenSize.width) {
                    frameSize.width = screenSize.width;
                }
                frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
                frame.setVisible(true);

                main.setWindowSession(frame);
            }
        }
    }

    public void end() {
        setVisible(false);
        dispose();
    }

}