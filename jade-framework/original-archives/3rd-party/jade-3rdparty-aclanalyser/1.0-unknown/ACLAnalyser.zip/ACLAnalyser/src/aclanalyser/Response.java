package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Response extends JFrame {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JTextField jTextField1 = new JTextField();

    // Build the frame
    public Response() {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setFont(new java.awt.Font("Dialog", 1, 16));
        jLabel1.setText("Result:");
        jLabel1.setBounds(new Rectangle(20, 14, 242, 28));
        contentPane.setLayout(null);
        this.setSize(new Dimension(366, 151));
        this.setTitle("Leader selection");
        jTextField1.setFont(new java.awt.Font("SansSerif", 0, 14));
        jTextField1.setBounds(new Rectangle(18, 50, 321, 54));
        contentPane.add(jLabel1, null);
        contentPane.add(jTextField1, null);
    }

    // Modified in order to be able to exit when the window is closed
    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            setVisible(false);
            dispose();
        }
    }

    public void setResult(String resultado) {
        jTextField1.setText(resultado);
    }
}