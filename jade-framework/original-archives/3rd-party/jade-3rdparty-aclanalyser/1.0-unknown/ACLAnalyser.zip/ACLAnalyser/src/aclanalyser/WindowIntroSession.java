package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class WindowIntroSession extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();

    private WindowSaveSession window;
    private String current_name;

    // Build the frame
    public WindowIntroSession(WindowSaveSession win, String name) {
        current_name = name;
        window = win;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cyclops.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Introduce the session name:");
        jLabel1.setBounds(new Rectangle(47, 46, 194, 21));
        contentPane.setLayout(null);
        this.setSize(new Dimension(355, 194));
        this.setTitle("Introduction of the session name");
        jTextField1.setBounds(new Rectangle(49, 78, 266, 24));
        jTextField1.setText(current_name);
        jButton1.setBounds(new Rectangle(54, 140, 111, 27));
        jButton1.setText("Accept");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(197, 139, 111, 27));
        contentPane.add(jLabel1, null);
        contentPane.add(jTextField1, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            window.end(false, null);
            end();
        }
    }

    void jButton2_actionPerformed(ActionEvent e) {
        window.end(false, null);
        end();
    }

    void jButton1_actionPerformed(ActionEvent e) {
        String name = jTextField1.getText();
        window.end(true, name);
        end();
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}