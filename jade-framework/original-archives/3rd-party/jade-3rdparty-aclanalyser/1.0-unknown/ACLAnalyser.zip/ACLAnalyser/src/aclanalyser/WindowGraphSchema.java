package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedList;
import java.io.*;

public class WindowGraphSchema extends JFrame implements AgentMark, Termination {
    private DBAccess abd;
    private Graph graph;
    private JPanel contentPane;
    private LinkedList windows;

    private JScrollPane jPanel1;
    private JButton jButton1 = new JButton();
    private JLabel jLabel1 = new JLabel();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();

    private LinkedList[] groups;
    private String session;

    // Build the frame
    public WindowGraphSchema(DBAccess access, LinkedList[] groups, String session) {
        this.session = session;
        windows = new LinkedList();
        this.groups = groups;
        graph = new Graph(access, this);
        abd = access;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jPanel1 = graph.showSchema(this.groups);
            graph.catchMouse();
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "graph.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(555, 380));
        this.setTitle("Schema of Agents - Session: " + session);
        jPanel1.setBackground(Color.white);
        jPanel1.setBounds(new Rectangle(16, 13, 387, 311));

        jButton1.setBounds(new Rectangle(420, 90, 119, 32));
        jButton1.setText("Arrange");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });

        jLabel1.setText("Change size");
        jLabel1.setBounds(new Rectangle(434, 168, 85, 18));
        jButton3.setBounds(new Rectangle(422, 200, 48, 22));
        jButton3.setFont(new java.awt.Font("Dialog", 0, 15));
        jButton3.setText("+");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton4.setText("-");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jButton4.setBounds(new Rectangle(473, 200, 48, 22));
        jButton4.setFont(new java.awt.Font("Dialog", 0, 15));

        contentPane.add(jPanel1, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton3, null);
        contentPane.add(jButton4, null);
        contentPane.add(jLabel1, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    void jButton1_actionPerformed(ActionEvent e) {
        graph.sort();
    }

    public void agentMarked(String group) {
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            String number = group.substring(5);
            Integer n = Integer.valueOf(number);

            WindowInfGroup frame = new WindowInfGroup(group, groups[n.intValue()], abd);
            // Validate frames with preset sizes.
            // Pack frames with important size information. For instance about its design.
            frame.validate();

            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
            frame.setVisible(true);

            windows.add(frame);
        }
    }

    void jButton3_actionPerformed(ActionEvent e) {
        graph.moreSize();
    }

    void jButton4_actionPerformed(ActionEvent e) {
        graph.lessSize();
    }

    public void end() {
        WindowInfGroup win;
        for (int i = 0; i < windows.size(); i++) {
            win = (WindowInfGroup) windows.get(i);
            win.end();
        }

        setVisible(false);
        dispose();
    }

}