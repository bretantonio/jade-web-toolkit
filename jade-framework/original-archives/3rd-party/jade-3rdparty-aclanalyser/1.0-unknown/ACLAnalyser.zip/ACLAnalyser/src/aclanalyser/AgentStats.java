package aclanalyser;

public class AgentStats {
    private int num_conversations = 0;
    private int num_conversations_OK = 0;
    private int num_sent_messages = 0;
    private int num_received_messages = 0;
    private int num_messages_OK = 0;
    private int num_messages_late = 0;
    private long bytes_In = 0;
    private long bytes_Out = 0;

    public void setNumConversations(int num) {
        num_conversations = num;
    }

    public void setNumConversationsOK(int num) {
        num_conversations_OK = num;
    }

    public void setNumMessagesRec(int num) {
        num_received_messages = num;
    }

    public void setNumMessagesSent(int num) {
        num_sent_messages = num;
    }

    public void setNumMessagesOK(int num) {
        num_messages_OK = num;
    }

    public void setNumMessagesLate(int num) {
        num_messages_late = num;
    }

    public void setBytesIn(long num) {
        bytes_In = num;
    }

    public void setBytesOut(long num) {
        bytes_Out = num;
    }

    public int getNumConversations() {
        return num_conversations;
    }

    public int getNumConversationsOK() {
        return num_conversations_OK;
    }

    public int getNumConversationsError() {
        return num_conversations - num_conversations_OK;
    }

    public int getNumMessagesReceived() {
        return num_received_messages;
    }

    public int getNumMessagesSent() {
        return num_sent_messages;
    }

    public int getNumMessagesOK() {
        return num_messages_OK;
    }

    public int getNumMessagesError() {
        return num_sent_messages - num_messages_OK;
    }

    public int getNumMessagesLate() {
        return num_messages_late;
    }

    public long getBytesIn() {
        return bytes_In;
    }

    public long getBytesOut() {
        return bytes_Out;
    }

}