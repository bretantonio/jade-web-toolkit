package aclanalyser;

import jade.core.Agent;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.wrapper.*;

/**
 * Creates NUM_AGENTS (100) agents. Use the debugger to sniff and check conversations,
 * stats, etc. This class uses the Rock algorithm.
 */
public class Example2 extends Agent {

    static final int NUM_AGENTS = 100;

    protected void setup() {

        try {
            // creates the agent description of itself
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());
            // register the description with the DF
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }

        String[] agents = new String[NUM_AGENTS];
        for (int i = 0; i < NUM_AGENTS; i++)
            agents[i] = getLocalName() + "--" + i;

        try {
            // gets a container controller for creating new agents
            PlatformController container = getContainerController();
            for (int i = 0; i < NUM_AGENTS; i++) {
                //Thread.sleep(100);
                container.createNewAgent(agents[i], "aclanalyser.TestRock", null).start();
            }
        } catch (Exception any) {
            any.printStackTrace();
        }
    }

}