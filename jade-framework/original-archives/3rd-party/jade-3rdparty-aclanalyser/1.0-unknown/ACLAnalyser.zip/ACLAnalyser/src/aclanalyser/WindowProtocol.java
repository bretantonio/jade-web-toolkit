package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import java.io.*;

import jade.lang.acl.*;

public class WindowProtocol extends JFrame implements Termination {
    private ControlProtocol control;
    private JFileChooser jFileChooser1;
    private Filter filter;
    private WindowCurProtocol windowCurProt = null;
    private JPanel contentPane;
    private JTable jTable1;
    private DefaultTableModel model;
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JComboBox jComboBox1 = new JComboBox();
    private JComboBox jComboBox2 = new JComboBox();
    private JComboBox jComboBox3 = new JComboBox();
    private JComboBox jComboBox4 = new JComboBox();
    private JButton jButton1 = new JButton();
    private JLabel jLabel5 = new JLabel();
    private JComboBox jComboBox5 = new JComboBox();
    private JButton jButton2 = new JButton();
    private JLabel jLabel6 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private JLabel jLabel7 = new JLabel();
    private JComboBox jComboBox6 = new JComboBox();
    private JScrollPane scroll;
    private JMenuBar jMenuBar1 = new JMenuBar();
    private JMenu jMenu1 = new JMenu();
    private JMenuItem jMenuItem1 = new JMenuItem();
    private JMenuItem jMenuItem2 = new JMenuItem();
    private JMenuItem jMenuItem3 = new JMenuItem();
    private JMenuItem jMenuItem6 = new JMenuItem();
    private JMenu jMenu2 = new JMenu();
    private JMenuItem jMenuItem4 = new JMenuItem();
    private JMenuItem jMenuItem5 = new JMenuItem();

    // Build the frame
    public WindowProtocol(ControlProtocol cp) {
        control = cp;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "tie.gif"));
        filter = new Filter();
        jFileChooser1 = new JFileChooser();
        jFileChooser1.addChoosableFileFilter(filter);
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(668, 383));
        this.setTitle("Config Protocol");
        Vector vector = new Vector();
        jLabel1.setText("Initial state:");
        jLabel1.setBounds(new Rectangle(24, 20, 125, 22));
        jLabel2.setBounds(new Rectangle(24, 70, 125, 22));
        jLabel3.setText("Sender role:");
        jLabel3.setBounds(new Rectangle(24, 120, 125, 22));
        jLabel4.setText("Receiver role:");
        jLabel4.setBounds(new Rectangle(24, 170, 125, 22));
        jLabel5.setText("Final state:");
        jComboBox1.setBounds(new Rectangle(24, 45, 111, 17));
        jComboBox1.addItem("Initial");
        for (int j = 1; j < ControlProtocol.POSSIBLE_OK_STATE; j++)
            jComboBox1.addItem("" + j);
        jComboBox1.addItem("Posible Final");
        jComboBox2.setBounds(new Rectangle(24, 95, 111, 17));
        jComboBox4.addItem(ControlProtocol.INITIATOR);
        jComboBox4.addItem(ControlProtocol.PARTICIPANT);
        jComboBox4.addItem(ControlProtocol.ANY_ROL);
        jComboBox3.setBounds(new Rectangle(24, 145, 111, 17));
        jComboBox3.addItem(ControlProtocol.INITIATOR);
        jComboBox3.addItem(ControlProtocol.PARTICIPANT);
        jComboBox3.addItem(ControlProtocol.ANY_ROL);
        jComboBox4.setBounds(new Rectangle(24, 195, 111, 17));
        jComboBox5.addItem("Initial");
        for (int j = 1; j < ControlProtocol.POSSIBLE_OK_STATE; j++)
            jComboBox5.addItem("" + j);
        jComboBox5.addItem("Possible Final");
        jComboBox5.addItem("Final");
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.AGREE));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.CANCEL));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.CFP));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.CONFIRM));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.DISCONFIRM));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.FAILURE));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.INFORM));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.INFORM_IF));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.INFORM_REF));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.NOT_UNDERSTOOD));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.PROPAGATE));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.PROPOSE));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.PROXY));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.QUERY_IF));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.QUERY_REF));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.REFUSE));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.REQUEST));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.REQUEST_WHEN));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.REQUEST_WHENEVER));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.SUBSCRIBE));
        jComboBox2.addItem(ACLMessage.getPerformative(ACLMessage.UNKNOWN));

        jButton1.setBounds(new Rectangle(33, 292, 88, 29));
        jButton1.setText("Add cell");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jLabel2.setText("Performative:");
        jLabel5.setBounds(new Rectangle(24, 220, 93, 17));
        jComboBox5.setBounds(new Rectangle(24, 245, 111, 17));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setText("Remove cell");
        jButton2.setBounds(new Rectangle(194, 292, 103, 29));

        jLabel6.setText("Protocol name:");
        jLabel6.setBounds(new Rectangle(203, 17, 99, 18));
        jTextField1.setBounds(new Rectangle(302, 18, 166, 19));

        jLabel7.setBounds(new Rectangle(203, 47, 99, 18));
        jLabel7.setText("Protocol type:");
        jComboBox6.setBounds(new Rectangle(302, 48, 121, 19));
        jComboBox6.addItem(ControlProtocol.SIMPLE);
        jComboBox6.addItem(ControlProtocol.MULTIPLE);

        vector.add("Initial State");
        vector.add("Performative");
        vector.add("Sender Role");
        vector.add("Receiver Role");
        vector.add("Final State");
        model = new DefaultTableModel(vector, 0);
        jTable1 = new JTable(model);

        jTable1.setBounds(new Rectangle(175, 85, 471, 169));
        jTable1.setSelectionMode(0);  // only allow 1-row selection

        JTableHeader anHeader = jTable1.getTableHeader();
        anHeader.setReorderingAllowed(false);

        scroll = new JScrollPane(jTable1);
        scroll.setBounds(new Rectangle(175, 85, 471, 169));

        jMenu1.setText("File");
        jMenuItem1.setText("New");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem1_actionPerformed(e);
            }
        });
        jMenuItem2.setText("Open");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem2_actionPerformed(e);
            }
        });
        jMenuItem3.setText("Save");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem3_actionPerformed(e);
            }
        });
        jMenuItem6.setText("Exit");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem6_actionPerformed(e);
            }
        });
        jMenu2.setText("Active Protocols");
        jMenuItem4.setText("Load");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem4_actionPerformed(e);
            }
        });
        jMenuItem5.setText("Show");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem5_actionPerformed(e);
            }
        });

        contentPane.add(scroll, null);
        contentPane.add(jLabel1, null);
        contentPane.add(jLabel2, null);
        contentPane.add(jLabel3, null);
        contentPane.add(jLabel4, null);
        contentPane.add(jComboBox1, null);
        contentPane.add(jComboBox2, null);
        contentPane.add(jComboBox3, null);
        contentPane.add(jComboBox4, null);
        contentPane.add(jComboBox5, null);
        contentPane.add(jButton1, null);
        contentPane.add(jLabel5, null);
        contentPane.add(jButton2, null);
        contentPane.add(jTextField1, null);
        contentPane.add(jLabel7, null);
        contentPane.add(jLabel6, null);
        contentPane.add(jComboBox6, null);
        jMenuBar1.add(jMenu1);
        jMenuBar1.add(jMenu2);
        jMenu1.add(jMenuItem1);
        jMenu1.add(jMenuItem2);
        jMenu1.add(jMenuItem3);
        jMenu1.add(new JPopupMenu.Separator());
        jMenu1.add(jMenuItem6);
        jMenu2.add(jMenuItem4);
        jMenu2.add(jMenuItem5);
        this.setJMenuBar(jMenuBar1);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    void jButton1_actionPerformed(ActionEvent e) {
        Object initState = jComboBox1.getSelectedItem();
        Object perf = jComboBox2.getSelectedItem();
        Object sender = jComboBox3.getSelectedItem();
        Object receiver = jComboBox4.getSelectedItem();
        Object endState = jComboBox5.getSelectedItem();
        Object[] data = {initState, perf, sender, receiver, endState};
        model.addRow(data);
    }

    void jButton2_actionPerformed(ActionEvent e) {
        int i = jTable1.getSelectedRow();
        if (i != -1) model.removeRow(i);
    }

    private void cleanTable() {
        jTextField1.setText("");
        int num = jTable1.getRowCount();
        for (int i = 0; i < num; i++)
            model.removeRow(0);
    }

    public void show(Protocol prot) {
        cleanTable();

        jTextField1.setText(prot.getName());
        if (prot.getType().equals(jComboBox6.getItemAt(0)))
            jComboBox6.setSelectedIndex(0);
        else
            jComboBox6.setSelectedIndex(1);

        // now the cells
        ProtocolCell cell;
        Enumeration enum = prot.getEnumeration();

        String perf,startRol,endRol,initSta,endSta;
        int initState,endState;

        while (enum.hasMoreElements()) {
            cell = (ProtocolCell) enum.nextElement();
            perf = cell.getPerform();
            startRol = cell.getRolSender();
            endRol = cell.getRolReceiver();
            initState = cell.getInitialState();
            if (initState == ControlProtocol.OK_STATE)
                initSta = "Final";
            else if (initState == ControlProtocol.POSSIBLE_OK_STATE)
                initSta = "Possible Final";
            else if (initState == 0)
                initSta = "Initial";
            else
                initSta = "" + initState;
            endState = cell.getState();
            if (endState == ControlProtocol.OK_STATE)
                endSta = "Final";
            else if (endState == ControlProtocol.POSSIBLE_OK_STATE)
                endSta = "Possible Final";
            else if (endState == 0)
                endSta = "Initial";
            else
                endSta = "" + endState;
            Object[] data = {initSta, perf, startRol, endRol, endSta};
            model.addRow(data);
        }
    }

    private Protocol getProtocol() {
        String perf,startRol,endRol,initSta,endSta;
        int initState,endState;

        Protocol prot = new Protocol(jTextField1.getText(), (String) jComboBox6.getSelectedItem());

        int num = jTable1.getRowCount();
        for (int i = 0; i < num; i++) {
            perf = (String) model.getValueAt(i, 1);
            startRol = (String) model.getValueAt(i, 2);
            endRol = (String) model.getValueAt(i, 3);
            initSta = (String) model.getValueAt(i, 0);
            if (initSta.equals("Final"))
                initState = ControlProtocol.OK_STATE;
            else if (initSta.equals("Possible Final"))
                initState = ControlProtocol.POSSIBLE_OK_STATE;
            else if (initSta.equals("Initial"))
                initState = 0;
            else
                initState = Integer.valueOf(initSta).intValue();
            endSta = (String) model.getValueAt(i, 4);
            if (endSta.equals("Final"))
                endState = ControlProtocol.OK_STATE;
            else if (endSta.equals("Possible Final"))
                endState = ControlProtocol.POSSIBLE_OK_STATE;
            else if (endSta.equals("Initial"))
                endState = 0;
            else
                endState = Integer.valueOf(endSta).intValue();
            prot.addElement(perf, startRol, endRol, initState, endState);
        }

        return prot;
    }

    void jMenuItem1_actionPerformed(ActionEvent e) {
        cleanTable();
    }

    void jMenuItem2_actionPerformed(ActionEvent e) {
        int a = jFileChooser1.showOpenDialog(this);
        if (a == JFileChooser.APPROVE_OPTION) {
            File file = jFileChooser1.getSelectedFile();
            if ((file.isFile()) && (filter.accept(file))) {
                // Open file
                Protocol prot = Protocol.loadProtocol(file.toString());
                show(prot);
            }
        }
    }

    void jMenuItem3_actionPerformed(ActionEvent e) {
        Protocol prot = getProtocol();

        int a = jFileChooser1.showSaveDialog(this);
        if (a == JFileChooser.APPROVE_OPTION) {
            File file = jFileChooser1.getSelectedFile();
            if (filter.accept(file)) {
                try {
                    file.createNewFile();
                    if (file.isFile())
                        prot.saveProtocol(file.toString());
                } catch (Exception ex) {
                    System.err.println("Error creating protocol file " + ex);
                }
            }
        }
    }

    void jMenuItem4_actionPerformed(ActionEvent e) {
        Protocol prot = getProtocol();
        control.addProtocol(prot);
    }

    void jMenuItem5_actionPerformed(ActionEvent e) {
        if (windowCurProt != null) windowCurProt.end();

        windowCurProt = new WindowCurProtocol(control, jFileChooser1, this);

        // Validate frames with preset sizes.
        // Pack frames with important size information. For instance about its design.
        windowCurProt.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = windowCurProt.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        windowCurProt.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        windowCurProt.setVisible(true);
    }

    void jMenuItem6_actionPerformed(ActionEvent e) {
        end();
    }

    public void end() {
        if (windowCurProt != null) windowCurProt.end();
        setVisible(false);
        dispose();
    }
}