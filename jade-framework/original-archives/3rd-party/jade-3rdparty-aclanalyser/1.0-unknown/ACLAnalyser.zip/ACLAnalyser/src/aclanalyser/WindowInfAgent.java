package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import java.io.*;

public class WindowInfAgent extends JFrame implements Termination {
    private String agent;
    private Graph graphIn;
    private Graph graphOut;
    private AgentStats as;
    private DBAccess abd;
    private WindowConv windowConv = null;
    private WindowMessage windowMessages = null;
    private WindowMain main;

    private JPanel contentPane;
    private JScrollPane jPanel1;
    private JScrollPane jPanel2;
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JLabel jLabel9 = new JLabel();
    private JLabel jLabel10 = new JLabel();
    private JLabel jLabel11 = new JLabel();
    private JLabel jLabel12 = new JLabel();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JLabel jLabel13 = new JLabel();
    private JLabel jLabel14 = new JLabel();
    private JLabel jLabel15 = new JLabel();
    private JLabel jLabel16 = new JLabel();
    private JLabel jLabel17 = new JLabel();
    private JLabel jLabel18 = new JLabel();
    private JLabel jLabel19 = new JLabel();
    private JLabel jLabel110 = new JLabel();
    private JLabel jLabel111 = new JLabel();
    private JLabel jLabel112 = new JLabel();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();
    private JLabel jLabel20 = new JLabel();
    private JLabel jLabel21 = new JLabel();
    private JButton jButton5 = new JButton();
    private JButton jButton7 = new JButton();
    private JButton jButton8 = new JButton();
    private JButton jButton6 = new JButton();

    // Build the frame
    public WindowInfAgent(String ag, DBAccess access, WindowMain win) {
        main = win;
        agent = ag;
        graphIn = new Graph(access);
        graphOut = new Graph(access);
        abd = access;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jPanel1 = graphIn.showAgentIn(ag);
            jPanel2 = graphOut.showAgentOut(ag);
            jbInit();
            as = access.getAgentStats(ag);
            fill();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "agent.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(710, 521));
        this.setTitle("Information of: " + agent);
        jPanel1.setBackground(Color.white);
        jPanel2.setBackground(Color.white);
        jPanel1.setBounds(new Rectangle(320, 46, 270, 190));
        jPanel2.setBounds(new Rectangle(320, 286, 270, 190));
        jLabel1.setText("Input graph");
        jLabel1.setBounds(new Rectangle(320, 18, 153, 19));
        jLabel2.setText("Output graph");
        jLabel2.setBounds(new Rectangle(320, 254, 173, 19));
        jLabel3.setText("Initiated conversations");
        jLabel3.setBounds(new Rectangle(40, 52, 210, 25));
        jLabel4.setText("Initiated successful conversations");
        jLabel4.setBounds(new Rectangle(40, 80, 210, 25));
        jLabel5.setBounds(new Rectangle(40, 108, 210, 25));
        jLabel5.setText("Initiated unsuccessful conversations");
        jLabel6.setText("Sent message");
        jLabel6.setBounds(new Rectangle(40, 136, 210, 25));
        jLabel7.setBounds(new Rectangle(40, 164, 210, 25));
        jLabel7.setText("Sent right messages");
        jLabel8.setBounds(new Rectangle(40, 192, 210, 25));
        jLabel8.setText("Sent wrong messages");
        jLabel9.setText("Sent late messages");
        jLabel9.setBounds(new Rectangle(40, 220, 210, 25));
        jLabel11.setBounds(new Rectangle(40, 276, 210, 25));
        jLabel11.setText("Received messages");
        jLabel10.setText("Sent bytes");
        jLabel10.setBounds(new Rectangle(40, 248, 210, 25));
        jLabel12.setText("Received bytes");
        jLabel12.setBounds(new Rectangle(40, 304, 210, 25));
        jButton1.setBounds(new Rectangle(20, 410, 132, 28));
        jButton1.setText("Show messages");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });

        jButton2.setBounds(new Rectangle(160, 410, 150, 28));
        jButton2.setText("Show conversations");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });

        jLabel13.setText("jLabel13");
        jLabel13.setBounds(new Rectangle(257, 52, 50, 25));
        jLabel14.setBounds(new Rectangle(257, 80, 50, 25));
        jLabel14.setText("jLabel13");
        jLabel15.setBounds(new Rectangle(257, 108, 50, 25));
        jLabel15.setText("jLabel13");
        jLabel16.setBounds(new Rectangle(257, 136, 50, 25));
        jLabel16.setText("jLabel13");
        jLabel17.setBounds(new Rectangle(257, 164, 50, 25));
        jLabel17.setText("jLabel13");
        jLabel18.setBounds(new Rectangle(257, 192, 50, 25));
        jLabel18.setText("jLabel13");
        jLabel19.setBounds(new Rectangle(257, 220, 50, 25));
        jLabel19.setText("jLabel13");
        jLabel110.setBounds(new Rectangle(257, 248, 50, 25));
        jLabel110.setText("jLabel13");
        jLabel111.setBounds(new Rectangle(257, 276, 50, 25));
        jLabel111.setText("jLabel13");
        jLabel112.setBounds(new Rectangle(257, 304, 50, 25));
        jLabel112.setText("jLabel13");
        jButton3.setBounds(new Rectangle(605, 93, 92, 29));
        jButton3.setText("Arrange");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton4.setText("Arrange");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jButton4.setBounds(new Rectangle(605, 327, 92, 29));
        jLabel20.setText("Change size");
        jLabel20.setBounds(new Rectangle(611, 148, 81, 19));
        jLabel21.setBounds(new Rectangle(611, 382, 81, 19));
        jLabel21.setText("Change size");
        jButton5.setBounds(new Rectangle(599, 183, 46, 20));
        jButton5.setFont(new java.awt.Font("Dialog", 0, 15));
        jButton5.setText("+");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton5_actionPerformed(e);
            }
        });
        jButton7.setText("+");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton7_actionPerformed(e);
            }
        });
        jButton7.setFont(new java.awt.Font("Dialog", 0, 15));
        jButton7.setBounds(new Rectangle(599, 417, 46, 20));
        jButton8.setText("-");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton8_actionPerformed(e);
            }
        });
        jButton8.setFont(new java.awt.Font("Dialog", 0, 15));
        jButton8.setBounds(new Rectangle(652, 417, 46, 20));
        jButton6.setText("-");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton6_actionPerformed(e);
            }
        });
        jButton6.setFont(new java.awt.Font("Dialog", 0, 15));
        jButton6.setBounds(new Rectangle(652, 183, 46, 20));
        contentPane.add(jPanel1, null);
        contentPane.add(jPanel2, null);
        contentPane.add(jLabel1, null);
        contentPane.add(jLabel2, null);
        contentPane.add(jLabel3, null);
        contentPane.add(jLabel4, null);
        contentPane.add(jLabel5, null);
        contentPane.add(jLabel6, null);
        contentPane.add(jLabel7, null);
        contentPane.add(jLabel8, null);
        contentPane.add(jLabel9, null);
        contentPane.add(jLabel11, null);
        contentPane.add(jLabel10, null);
        contentPane.add(jLabel12, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
        contentPane.add(jLabel13, null);
        contentPane.add(jLabel14, null);
        contentPane.add(jLabel15, null);
        contentPane.add(jLabel16, null);
        contentPane.add(jLabel17, null);
        contentPane.add(jLabel18, null);
        contentPane.add(jLabel19, null);
        contentPane.add(jLabel110, null);
        contentPane.add(jLabel111, null);
        contentPane.add(jLabel112, null);
        contentPane.add(jButton4, null);
        contentPane.add(jButton3, null);
        contentPane.add(jLabel21, null);
        contentPane.add(jLabel20, null);
        contentPane.add(jButton5, null);
        contentPane.add(jButton7, null);
        contentPane.add(jButton8, null);
        contentPane.add(jButton6, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    void jButton1_actionPerformed(ActionEvent e) {
        if (windowMessages == null) {
            windowMessages = new WindowMessage(main);
            windowMessages.validate();
            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = windowMessages.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            windowMessages.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        }
        windowMessages.fill(abd.searchMessages(agent));
        windowMessages.setVisible(true);
    }

    void jButton2_actionPerformed(ActionEvent e) {
        SearchConversation bc = new SearchConversation();
        Vector initiator = new Vector();
        initiator.add(agent);
        bc.setInitiator(initiator);
        Vector vec = sendQuery(bc);
        showResult(vec);
    }

    private Vector sendQuery(SearchConversation bc) {
        return abd.searchConversation(bc);
    }

    private void showResult(Vector conver) {

        if (windowConv == null) {
            windowConv = new WindowConv(abd, main);
            windowConv.validate();
            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = windowConv.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            windowConv.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        }
        windowConv.fill(conver);
        windowConv.setVisible(true);
    }


    void jButton3_actionPerformed(ActionEvent e) {
        graphIn.sort();
    }

    void jButton4_actionPerformed(ActionEvent e) {
        graphOut.sort();
    }

    private void fill() {
        jLabel13.setText("" + as.getNumConversations());
        jLabel14.setText("" + as.getNumConversationsOK());
        jLabel15.setText("" + as.getNumConversationsError());
        jLabel16.setText("" + as.getNumMessagesSent());
        jLabel17.setText("" + as.getNumMessagesOK());
        jLabel18.setText("" + as.getNumMessagesError());
        jLabel19.setText("" + as.getNumMessagesLate());
        jLabel110.setText("" + as.getBytesOut());
        jLabel111.setText("" + as.getNumMessagesReceived());
        jLabel112.setText("" + as.getBytesIn());
    }

    void jButton5_actionPerformed(ActionEvent e) {
        graphIn.moreSize();
    }

    void jButton6_actionPerformed(ActionEvent e) {
        graphIn.lessSize();
    }

    void jButton7_actionPerformed(ActionEvent e) {
        graphOut.moreSize();
    }

    void jButton8_actionPerformed(ActionEvent e) {
        graphOut.lessSize();
    }

    public void end() {
        if (windowConv != null) windowConv.end();
        if (windowMessages != null) windowMessages.end();
        setVisible(false);
        dispose();
    }
}