package aclanalyser;

import jade.core.*;

import java.util.*;

/**
 * The state represents the status of a conversation, at a particular instant,
 * depending on its protocol, and on the messages sent on this conversation.
 */
public class State {
    private AID initiator;
    private int state;
    private Alarm alarm;
    protected Conversation conversation;

    /**
     * Creates a new instance of Stato, initializing its fields.
     * @param stat Initial state of the conversation.
     * @param init Initiator agent of the conversation.
     * @param conv The conversation.
     */
    public State(int stat, AID init, Conversation conv) {
        state = stat;
        initiator = (AID) init.clone();
        conversation = conv;
        alarm = null;
    }

    /**
     * Gets the role of an agent in the conversation.
     * @param ag Requested agent.
     * @return The role of the agent.
     */
    public String getRol(AID ag) {
        if (initiator.equals(ag))
            return ControlProtocol.INITIATOR;
        else
            return ControlProtocol.PARTICIPANT;
    }

    /**
     * Sets the initiator agent of the conversation.
     * @param init Initiator agent.
     */
    public void setInitiator(AID init) {
        initiator = (AID) init.clone();
    }

    /**
     * Gets the initiator agent of the conversation.
     * @return Initiator agent.
     */
    public AID getInitiator() {
        return initiator;
    }

    /**
     * Gets the state of the conversation.
     * @return State of the conversation.
     */
    public int getState() {
        return state;
    }

    /**
     * Gets the state of the conversation for an agent.
     * @param agent Agent.
     * @return State of the conversation for an agent.
     */
    public int getState(AID agent) {
        return state;
    }

    /**
     * Gets the state of the conversation for a series of agents.
     * @param agents List of agents.
     * @return State of the conversation for those agents.
     */
    public int getState(Iterator agents) {
        return state;
    }

    /**
     * Sets the state of the conversation.
     * @param sta State of the conversation.
     */
    public void setState(int sta) {
        state = sta;
    }

    /**
     * Indicates whether the conversation has finished or not.
     * @return Whether the conversation has finished or not.
     */
    public boolean end() {
        if ((state == ControlProtocol.OK_STATE) || (state == ControlProtocol.ERROR_STATE))
            return true;
        else
            return false;
    }

    /**
     * Sets the alarm of an agent in the conversation,
     * stopping before the previous one if the agent has already one.
     * @param time Duration of the alarm.
     * @param agent Agent which sets the alarm.
     */
    public void setAlarm(long time, AID agent) {
        if (alarm != null) alarm.stop();
        alarm = new Alarm(time, this, null);
        alarm.start();
    }

    /**
     * Notifies to the conversation that one alarm has expired; it modifies
     * before the state of the conversation.
     * @param agent Agent with the expired alarm.
     */
    public synchronized void notification(AID agent) {
        if (state == ControlProtocol.POSSIBLE_OK_STATE)
            setState(ControlProtocol.OK_STATE);
        else
            setState(ControlProtocol.ERROR_STATE);
        conversation.notification();
    }

    /**
     * Stops the alarm of an agent in the conversation.
     * @param agent Agent with the alarm to be stopped.
     */
    public void stopAlarm(AID agent) {
        if (alarm != null) {
            alarm.clean();
            alarm.stop();
            alarm = null;
        }
    }

    /**
     * Waits for the conversation blocking.
     */
    public synchronized void waitBlocking() {
        while (conversation.blocked()) ;
    }

}