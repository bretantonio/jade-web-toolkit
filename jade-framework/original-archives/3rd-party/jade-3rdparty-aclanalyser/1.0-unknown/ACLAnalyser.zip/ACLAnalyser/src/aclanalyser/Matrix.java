package aclanalyser;

public class Matrix {
    private int num_agents;
    private String[] agents;
    private int[][] messages;
    private long[][] sizes;

    public Matrix(int num) {
        num_agents = num;
        agents = new String[num];
        messages = new int[num][num];
        sizes = new long[num][num];
    }

    public void setAgents(String[] ag) {
        for (int i = 0; i < num_agents; i++)
            agents[i] = ag[i];
    }

    public void setMessages(int[][] messages) {
        for (int i = 0; i < num_agents; i++)
            for (int j = 0; j < num_agents; j++)
                this.messages[i][j] = messages[i][j];
    }

    public void setSizes(long[][] sizes) {
        for (int i = 0; i < num_agents; i++)
            for (int j = 0; j < num_agents; j++)
                this.sizes[i][j] = sizes[i][j];
    }

    public int getNumAgents() {
        return num_agents;
    }

    public String getAgent(int i) {
        return agents[i];
    }

    public int getAgentByName(String name) {
        for (int i = 0; i < agents.length; i++) {
            if (agents[i].equals(name)) return i;
        }
        return -1;
    }

    public int getMesssage(int i, int j) {
        return messages[i][j];
    }

    public long getSize(int i, int j) {
        return sizes[i][j];
    }
}