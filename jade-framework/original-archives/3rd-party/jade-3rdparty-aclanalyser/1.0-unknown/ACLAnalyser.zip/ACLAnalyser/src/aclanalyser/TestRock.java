package aclanalyser;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;

import jade.lang.acl.ACLMessage;

import java.util.LinkedList;

public class TestRock extends Agent {

    private LinkedList neighbors;
    private int number;

    protected void setup() {
        try {
            Thread.sleep(205000);
        } catch (Exception ec) {
            System.out.println("Error sleeping");
        }
        neighbors = new LinkedList();
        computeNeighbors();
        addBehaviour(new sendNeighborsBehaviour());
    }

    private void computeNeighbors() {
        String name = getName();
        int pos1 = name.indexOf("--");
        int pos2 = name.indexOf("@");
        String num = name.substring(pos1 + 2, pos2);
        String part1 = name.substring(0, pos1 + 2);
        String part2 = name.substring(pos2, name.length());

        Integer n = Integer.valueOf(num);
        number = n.intValue();

        // lineal
        if (number > 0) {
            addNeighbor(part1, part2, number - 1);
        }

        if (number < (Example2.NUM_AGENTS - 1)) {
            addNeighbor(part1, part2, number + 1);
        }

    }

    private void addNeighbor(String part1, String part2, int n) {
        Integer vec = new Integer(n);
        String neighbor = part1 + vec + part2;
        neighbors.add(new AID(neighbor, false));
    }

    private class sendNeighborsBehaviour extends OneShotBehaviour {

        public void action() {
            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
            AID receiv;

            for (int i = 0; i < neighbors.size(); i++) {
                receiv = (AID) neighbors.get(i);
                message.addReceiver(receiv);
            }

            message.setProtocol("protocol-send");
            message.setLanguage("l1");
            message.setOntology("o1");
            message.setConversationId(getLocalName());

            send(message);
        }
    }

}