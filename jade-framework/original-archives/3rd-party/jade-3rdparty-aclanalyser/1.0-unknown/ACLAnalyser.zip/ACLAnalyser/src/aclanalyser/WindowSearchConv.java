package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.text.*;

import jade.domain.*;
import jade.lang.acl.*;

import java.io.*;

public class WindowSearchConv extends JFrame implements Termination {
    private DBAccess abd;
    private WindowIntro frame2 = null;
    private WindowIntroOnto frame3 = null;
    private WindowIntroLang frame4 = null;
    private WindowConv frame5 = null;
    private WindowMain main;

    private JPanel contentPane;
    private JTabbedPane jTabbedPane1 = new JTabbedPane();
    private JPanel initiator = new JPanel();
    private JPanel protocol = new JPanel();
    private JPanel ontology = new JPanel();
    private JPanel language = new JPanel();
    private JPanel performativeStart = new JPanel();
    private JList jList1 = new JList();
    private JButton addInitiator = new JButton();
    private JButton delInitiator = new JButton();
    private Vector initiators = new Vector();
    private Vector ontologies = new Vector();
    private Vector languages = new Vector();
    private JList jList2 = new JList();
    private JButton addOntology = new JButton();
    private JButton delOntology = new JButton();
    private JButton delLanguage = new JButton();
    private JButton addLanguage = new JButton();
    private JLabel jLabel9 = new JLabel();
    private JLabel jLabel10 = new JLabel();
    private JLabel jLabel11 = new JLabel();
    private JLabel jLabel12 = new JLabel();
    private JLabel jLabel13 = new JLabel();
    private JLabel jLabel14 = new JLabel();
    private JLabel jLabel15 = new JLabel();
    private JLabel jLabel16 = new JLabel();
    private JLabel jLabel17 = new JLabel();
    private JLabel jLabel18 = new JLabel();
    private JLabel jLabel19 = new JLabel();
    private JLabel jLabel110 = new JLabel();
    private JCheckBox jCheckBox1 = new JCheckBox();
    private JCheckBox jCheckBox2 = new JCheckBox();
    private JCheckBox jCheckBox3 = new JCheckBox();
    private JCheckBox jCheckBox4 = new JCheckBox();
    private JCheckBox jCheckBox5 = new JCheckBox();
    private JCheckBox jCheckBox6 = new JCheckBox();
    private JCheckBox jCheckBox7 = new JCheckBox();
    private JCheckBox jCheckBox8 = new JCheckBox();
    private JCheckBox jCheckBox9 = new JCheckBox();
    private JCheckBox jCheckBox10 = new JCheckBox();
    private JCheckBox jCheckBox11 = new JCheckBox();
    private JCheckBox jCheckBox12 = new JCheckBox();
    private JScrollPane jScrollPane2 = new JScrollPane();
    private JScrollPane jScrollPane3 = new JScrollPane();
    private JList jList3 = new JList();
    private JScrollPane jScrollPane4 = new JScrollPane();
    private JLabel jLabel20 = new JLabel();
    private JLabel jLabel21 = new JLabel();
    private JLabel jLabel22 = new JLabel();
    private JCheckBox jCheckBox15 = new JCheckBox();
    private JLabel jLabel25 = new JLabel();
    private JCheckBox jCheckBox14 = new JCheckBox();
    private JLabel jLabel24 = new JLabel();
    private JCheckBox jCheckBox13 = new JCheckBox();
    private JPanel result = new JPanel();
    private JLabel jLabel26 = new JLabel();
    private JTextField maxStartHour = new JTextField();
    private JTextField maxEndHour = new JTextField();
    private JTextField minStartDate = new JTextField();
    private JPanel dates = new JPanel();
    private JTextField minEndDate = new JTextField();
    private JLabel jLabel8 = new JLabel();
    private JTextField minStartHour = new JTextField();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JTextField maxStartDate = new JTextField();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JTextField minEndHour = new JTextField();
    private JTextField maxEndDate = new JTextField();
    private JLabel jLabel1 = new JLabel();

    private JLabel jLabel27 = new JLabel();
    private JLabel jLabel28 = new JLabel();
    private JLabel jLabel29 = new JLabel();
    private JLabel jLabel210 = new JLabel();
    private JLabel jLabel211 = new JLabel();
    private JLabel jLabel212 = new JLabel();
    private JLabel jLabel213 = new JLabel();
    private JLabel jLabel214 = new JLabel();
    private JLabel jLabel215 = new JLabel();
    private JLabel jLabel216 = new JLabel();
    private JLabel jLabel217 = new JLabel();
    private JLabel jLabel218 = new JLabel();
    private JLabel jLabel219 = new JLabel();
    private JLabel jLabel2110 = new JLabel();
    private JLabel jLabel2111 = new JLabel();
    private JLabel jLabel2112 = new JLabel();
    private JLabel jLabel2113 = new JLabel();
    private JLabel jLabel2114 = new JLabel();
    private JLabel jLabel2115 = new JLabel();
    private JLabel jLabel2116 = new JLabel();
    private JLabel jLabel2117 = new JLabel();
    private JLabel jLabel2118 = new JLabel();
    private JLabel jLabel2119 = new JLabel();
    private JCheckBox jCheckBox16 = new JCheckBox();
    private JCheckBox jCheckBox17 = new JCheckBox();
    private JCheckBox jCheckBox18 = new JCheckBox();
    private JCheckBox jCheckBox19 = new JCheckBox();
    private JCheckBox jCheckBox110 = new JCheckBox();
    private JCheckBox jCheckBox111 = new JCheckBox();
    private JCheckBox jCheckBox112 = new JCheckBox();
    private JCheckBox jCheckBox113 = new JCheckBox();
    private JCheckBox jCheckBox114 = new JCheckBox();
    private JCheckBox jCheckBox115 = new JCheckBox();
    private JCheckBox jCheckBox116 = new JCheckBox();
    private JCheckBox jCheckBox117 = new JCheckBox();
    private JCheckBox jCheckBox118 = new JCheckBox();
    private JCheckBox jCheckBox119 = new JCheckBox();
    private JCheckBox jCheckBox1110 = new JCheckBox();
    private JCheckBox jCheckBox1111 = new JCheckBox();
    private JCheckBox jCheckBox1112 = new JCheckBox();
    private JCheckBox jCheckBox1113 = new JCheckBox();
    private JCheckBox jCheckBox1114 = new JCheckBox();
    private JCheckBox jCheckBox1115 = new JCheckBox();
    private JCheckBox jCheckBox1116 = new JCheckBox();
    private JCheckBox jCheckBox1117 = new JCheckBox();
    private JCheckBox jCheckBox1118 = new JCheckBox();
    private JCheckBox jCheckBox1119 = new JCheckBox();
    private JLabel jLabel30 = new JLabel();
    private JLabel jLabel21110 = new JLabel();
    private JLabel jLabel21111 = new JLabel();
    private JLabel jLabel21112 = new JLabel();
    private JLabel jLabel21113 = new JLabel();
    private JLabel jLabel21114 = new JLabel();
    private JLabel jLabel21115 = new JLabel();
    private JLabel jLabel21116 = new JLabel();
    private JLabel jLabel21117 = new JLabel();
    private JLabel jLabel21118 = new JLabel();
    private JLabel jLabel21119 = new JLabel();
    private JPanel performativeEnd = new JPanel();
    private JLabel jLabel2120 = new JLabel();
    private JLabel jLabel2121 = new JLabel();
    private JLabel jLabel2122 = new JLabel();
    private JLabel jLabel2123 = new JLabel();
    private JLabel jLabel2124 = new JLabel();
    private JLabel jLabel2125 = new JLabel();
    private JLabel jLabel2126 = new JLabel();
    private JLabel jLabel2127 = new JLabel();
    private JLabel jLabel2128 = new JLabel();
    private JLabel jLabel2129 = new JLabel();
    private JLabel jLabel31 = new JLabel();
    private JCheckBox jCheckBox1120 = new JCheckBox();
    private JCheckBox jCheckBox1121 = new JCheckBox();
    private JCheckBox jCheckBox1122 = new JCheckBox();
    private JCheckBox jCheckBox1123 = new JCheckBox();
    private JCheckBox jCheckBox1124 = new JCheckBox();
    private JCheckBox jCheckBox1125 = new JCheckBox();
    private JLabel jLabel220 = new JLabel();
    private JCheckBox jCheckBox1126 = new JCheckBox();
    private JLabel jLabel221 = new JLabel();
    private JCheckBox jCheckBox1127 = new JCheckBox();
    private JLabel jLabel222 = new JLabel();
    private JCheckBox jCheckBox1128 = new JCheckBox();
    private JCheckBox jCheckBox1129 = new JCheckBox();
    private JCheckBox jCheckBox11110 = new JCheckBox();
    private JCheckBox jCheckBox11111 = new JCheckBox();
    private JCheckBox jCheckBox11112 = new JCheckBox();
    private JCheckBox jCheckBox11113 = new JCheckBox();
    private JCheckBox jCheckBox11114 = new JCheckBox();
    private JCheckBox jCheckBox11115 = new JCheckBox();
    private JCheckBox jCheckBox11116 = new JCheckBox();
    private JCheckBox jCheckBox11117 = new JCheckBox();
    private JCheckBox jCheckBox11118 = new JCheckBox();
    private JCheckBox jCheckBox11119 = new JCheckBox();
    private JCheckBox jCheckBox120 = new JCheckBox();
    private JCheckBox jCheckBox121 = new JCheckBox();
    private JCheckBox jCheckBox122 = new JCheckBox();
    private JCheckBox jCheckBox123 = new JCheckBox();
    private JButton search = new JButton();

    // Build the frame
    public WindowSearchConv(DBAccess acc, WindowMain win) {
        main = win;
        abd = acc;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "searchConv.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(551, 320));
        this.setTitle("Search conversations");
        jTabbedPane1.setBounds(new Rectangle(15, 13, 415, 275));
        initiator.setLayout(null);
        protocol.setLayout(null);
        ontology.setLayout(null);
        language.setLayout(null);
        performativeStart.setLayout(null);
        jList1.setBorder(BorderFactory.createLineBorder(Color.black));
        jList1.setBounds(new Rectangle(31, 50, 225, 136));
        addInitiator.setBounds(new Rectangle(294, 87, 82, 30));
        addInitiator.setText("Add");
        addInitiator.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addInitiator_actionPerformed(e);
            }
        });
        delInitiator.setText("Remove");
        delInitiator.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                delInitiator_actionPerformed(e);
            }
        });
        delInitiator.setBounds(new Rectangle(295, 139, 81, 30));
        jList2.setBorder(BorderFactory.createLineBorder(Color.black));
        jList2.setBounds(new Rectangle(31, 50, 225, 136));
        addOntology.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addOntology_actionPerformed(e);
            }
        });
        addOntology.setText("Add");
        addOntology.setBounds(new Rectangle(294, 87, 82, 30));
        delOntology.setBounds(new Rectangle(295, 139, 81, 30));
        delOntology.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                delOntology_actionPerformed(e);
            }
        });
        delOntology.setText("Remove");
        delLanguage.setText("Remove");
        delLanguage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                delLanguage_actionPerformed(e);
            }
        });
        delLanguage.setBounds(new Rectangle(295, 139, 81, 30));
        addLanguage.setBounds(new Rectangle(294, 87, 82, 30));
        addLanguage.setText("Add");
        addLanguage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addLanguage_actionPerformed(e);
            }
        });
        jLabel9.setText("ANY");
        jLabel9.setBounds(new Rectangle(41, 17, 130, 19));
        jLabel10.setBounds(new Rectangle(41, 47, 130, 19));
        jLabel10.setText("fipa-request");
        jLabel11.setBounds(new Rectangle(41, 77, 130, 19));
        jLabel11.setText("fipa-query");
        jLabel12.setBounds(new Rectangle(41, 107, 130, 19));
        jLabel12.setText("fipa-contract-net");
        jLabel13.setBounds(new Rectangle(41, 137, 130, 19));
        jLabel13.setText("fipa-subscribe");
        jLabel14.setBounds(new Rectangle(41, 167, 130, 19));
        jLabel14.setText("fipa-request-when");
        jLabel15.setBounds(new Rectangle(215, 17, 144, 19));
        jLabel15.setText("fipa-iterated-contract-net");
        jLabel16.setBounds(new Rectangle(215, 47, 130, 19));
        jLabel16.setText("fipa-auction-english");
        jLabel17.setBounds(new Rectangle(215, 77, 130, 19));
        jLabel17.setText("fipa-auction-dutch");
        jLabel18.setBounds(new Rectangle(215, 107, 130, 19));
        jLabel18.setText("fipa-brokering");
        jLabel19.setBounds(new Rectangle(215, 137, 130, 19));
        jLabel19.setText("fipa-recruiting");
        jLabel110.setBounds(new Rectangle(215, 167, 130, 19));
        jLabel110.setText("fipa-propose");
        jCheckBox1.setSelected(true);
        jCheckBox1.setText("jCheckBox1");
        jCheckBox1.setBounds(new Rectangle(20, 21, 14, 13));
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1_actionPerformed(e);
            }
        });
        jCheckBox2.setBounds(new Rectangle(20, 51, 14, 13));
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox2_actionPerformed(e);
            }
        });
        jCheckBox2.setText("jCheckBox1");
        jCheckBox3.setBounds(new Rectangle(20, 81, 13, 13));
        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox3_actionPerformed(e);
            }
        });
        jCheckBox3.setText("jCheckBox1");
        jCheckBox4.setBounds(new Rectangle(20, 111, 14, 13));
        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox4_actionPerformed(e);
            }
        });
        jCheckBox4.setText("jCheckBox1");
        jCheckBox5.setBounds(new Rectangle(20, 141, 14, 13));
        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox5_actionPerformed(e);
            }
        });
        jCheckBox5.setText("jCheckBox1");
        jCheckBox6.setBounds(new Rectangle(20, 171, 14, 13));
        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox6_actionPerformed(e);
            }
        });
        jCheckBox6.setText("jCheckBox1");
        jCheckBox7.setBounds(new Rectangle(195, 21, 14, 13));
        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox7_actionPerformed(e);
            }
        });
        jCheckBox7.setText("jCheckBox1");
        jCheckBox8.setBounds(new Rectangle(195, 51, 14, 13));
        jCheckBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox8_actionPerformed(e);
            }
        });
        jCheckBox8.setText("jCheckBox1");
        jCheckBox9.setBounds(new Rectangle(195, 81, 14, 13));
        jCheckBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox9_actionPerformed(e);
            }
        });
        jCheckBox9.setText("jCheckBox1");
        jCheckBox10.setBounds(new Rectangle(195, 111, 14, 13));
        jCheckBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox10_actionPerformed(e);
            }
        });
        jCheckBox10.setText("jCheckBox1");
        jCheckBox11.setBounds(new Rectangle(195, 141, 14, 13));
        jCheckBox11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11_actionPerformed(e);
            }
        });
        jCheckBox11.setText("jCheckBox1");
        jCheckBox12.setBounds(new Rectangle(195, 171, 14, 13));
        jCheckBox12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox12_actionPerformed(e);
            }
        });
        jCheckBox12.setText("jCheckBox1");
        jScrollPane2.setBounds(new Rectangle(31, 50, 225, 136));
        jScrollPane3.setBounds(new Rectangle(31, 50, 225, 136));
        jList3.setBorder(BorderFactory.createLineBorder(Color.black));
        jList3.setBounds(new Rectangle(31, 50, 225, 136));
        jScrollPane4.setBounds(new Rectangle(31, 50, 225, 136));
        jLabel20.setText("Initiators Agents:");
        jLabel20.setBounds(new Rectangle(33, 19, 185, 19));
        jLabel21.setText("Ontologies:");
        jLabel21.setBounds(new Rectangle(29, 19, 175, 17));
        jLabel22.setText("Languages:");
        jLabel22.setBounds(new Rectangle(33, 19, 99, 18));
        jCheckBox15.setBounds(new Rectangle(59, 111, 16, 14));
        jCheckBox15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox15_actionPerformed(e);
            }
        });
        jCheckBox15.setText("jCheckBox13");
        jLabel25.setBounds(new Rectangle(90, 78, 112, 18));
        jLabel25.setText("Successful");
        jCheckBox14.setBounds(new Rectangle(59, 81, 16, 14));
        jCheckBox14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox14_actionPerformed(e);
            }
        });
        jCheckBox14.setText("jCheckBox13");
        jLabel24.setText("ANY");
        jLabel24.setBounds(new Rectangle(90, 48, 112, 18));
        jCheckBox13.setSelected(true);
        jCheckBox13.setText("jCheckBox13");
        jCheckBox13.setBounds(new Rectangle(59, 51, 16, 14));
        jCheckBox13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox13_actionPerformed(e);
            }
        });
        result.setLayout(null);
        jLabel26.setBounds(new Rectangle(90, 108, 112, 18));
        jLabel26.setText("Unsuccessful");
        maxStartHour.setBounds(new Rectangle(286, 82, 79, 21));
        maxStartHour.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                maxStartHour_focusLost(e);
            }
        });
        maxStartHour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                maxStartHour_actionPerformed(e);
            }
        });
        maxEndHour.setBounds(new Rectangle(286, 160, 79, 21));
        maxEndHour.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                maxEndHour_focusLost(e);
            }
        });
        maxEndHour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                maxEndHour_actionPerformed(e);
            }
        });
        minStartDate.setBounds(new Rectangle(160, 52, 79, 21));
        minStartDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                minStartDate_focusLost(e);
            }
        });
        minStartDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                minStartDate_actionPerformed(e);
            }
        });
        dates.setLayout(null);
        minEndDate.setBounds(new Rectangle(160, 130, 79, 21));
        minEndDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                minEndDate_focusLost(e);
            }
        });
        minEndDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                minEndDate_actionPerformed(e);
            }
        });
        jLabel8.setBounds(new Rectangle(23, 163, 129, 21));
        jLabel8.setText("Ending time between: ");
        minStartHour.setBounds(new Rectangle(160, 82, 79, 21));
        minStartHour.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                minStartHour_focusLost(e);
            }
        });
        minStartHour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                minStartHour_actionPerformed(e);
            }
        });
        jLabel7.setBounds(new Rectangle(23, 84, 141, 21));
        jLabel7.setText("Begining time between: ");
        jLabel6.setBounds(new Rectangle(248, 160, 30, 18));
        jLabel6.setText("and");
        jLabel6.setFont(new java.awt.Font("Dialog", 0, 14));
        maxStartDate.setBounds(new Rectangle(286, 52, 79, 21));
        maxStartDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                maxStartDate_focusLost(e);
            }
        });
        maxStartDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                maxStartDate_actionPerformed(e);
            }
        });
        jLabel5.setBounds(new Rectangle(248, 82, 30, 18));
        jLabel5.setText("and");
        jLabel5.setFont(new java.awt.Font("Dialog", 0, 14));
        jLabel4.setBounds(new Rectangle(248, 130, 30, 18));
        jLabel4.setText("and");
        jLabel4.setFont(new java.awt.Font("Dialog", 0, 14));
        jLabel3.setFont(new java.awt.Font("Dialog", 0, 14));
        jLabel3.setText("and");
        jLabel3.setBounds(new Rectangle(248, 52, 30, 18));
        jLabel2.setBounds(new Rectangle(22, 136, 131, 21));
        jLabel2.setText("Ending date between: ");
        minEndHour.setBounds(new Rectangle(160, 160, 79, 21));
        minEndHour.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                minEndHour_focusLost(e);
            }
        });
        minEndHour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                minEndHour_actionPerformed(e);
            }
        });
        maxEndDate.setBounds(new Rectangle(286, 130, 79, 21));
        maxEndDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(FocusEvent e) {
                maxEndDate_focusLost(e);
            }
        });
        maxEndDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                maxEndDate_actionPerformed(e);
            }
        });
        jLabel1.setText("Begining date between: ");
        jLabel1.setBounds(new Rectangle(23, 54, 141, 21));
        jLabel27.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel27.setText("ACCEPT_PROPOSAL");
        jLabel27.setBounds(new Rectangle(35, 42, 103, 18));
        jLabel28.setBounds(new Rectangle(35, 64, 96, 18));
        jLabel28.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel28.setText("AGREE");
        jLabel29.setBounds(new Rectangle(35, 86, 96, 18));
        jLabel29.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel29.setText("CANCEL");
        jLabel210.setBounds(new Rectangle(35, 108, 96, 18));
        jLabel210.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel210.setText("CFP");
        jLabel211.setBounds(new Rectangle(35, 130, 96, 18));
        jLabel211.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel211.setText("CONFIRM");
        jLabel212.setBounds(new Rectangle(35, 152, 96, 18));
        jLabel212.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel212.setText("DISCONFIRM");
        jLabel213.setBounds(new Rectangle(35, 174, 96, 18));
        jLabel213.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel213.setText("FAILURE");
        jLabel214.setBounds(new Rectangle(35, 196, 96, 18));
        jLabel214.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel214.setText("INFORM");
        jLabel215.setBounds(new Rectangle(170, 42, 96, 18));
        jLabel215.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel215.setText("INFORM_IF");
        jLabel216.setBounds(new Rectangle(170, 64, 96, 18));
        jLabel216.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel216.setText("INFORM_REF");
        jLabel217.setBounds(new Rectangle(170, 86, 98, 18));
        jLabel217.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel217.setText("NOT_UNDERSTOOD");
        jLabel218.setBounds(new Rectangle(170, 108, 96, 18));
        jLabel218.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel218.setText("PROPAGATE");
        jLabel219.setBounds(new Rectangle(170, 130, 96, 18));
        jLabel219.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel219.setText("PROPOSE");
        jLabel2110.setBounds(new Rectangle(170, 152, 96, 18));
        jLabel2110.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2110.setText("PROXY");
        jLabel2111.setBounds(new Rectangle(170, 174, 96, 18));
        jLabel2111.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2111.setText("QUERY_IF");
        jLabel2112.setBounds(new Rectangle(170, 196, 96, 18));
        jLabel2112.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2112.setText("QUERY_REF");
        jLabel2113.setBounds(new Rectangle(300, 42, 96, 18));
        jLabel2113.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2113.setText("REFUSE");
        jLabel2114.setBounds(new Rectangle(300, 64, 101, 18));
        jLabel2114.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2114.setText("REJECT_PROPOSAL");
        jLabel2115.setBounds(new Rectangle(300, 86, 96, 18));
        jLabel2115.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2115.setText("REQUEST");
        jLabel2116.setBounds(new Rectangle(300, 108, 96, 18));
        jLabel2116.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2116.setText("REQUEST_WHEN");
        jLabel2117.setBounds(new Rectangle(300, 130, 110, 18));
        jLabel2117.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2117.setText("REQUEST_WHENEVER");
        jLabel2118.setBounds(new Rectangle(300, 152, 96, 18));
        jLabel2118.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2118.setText("SUBSCRIBE");
        jLabel2119.setBounds(new Rectangle(300, 174, 96, 18));
        jLabel2119.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2119.setText("UNKNOWN");
        jCheckBox16.setText("jCheckBox16");
        jCheckBox16.setBounds(new Rectangle(15, 44, 15, 12));
        jCheckBox16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox16_actionPerformed(e);
            }
        });
        jCheckBox17.setBounds(new Rectangle(15, 66, 15, 12));
        jCheckBox17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox17_actionPerformed(e);
            }
        });
        jCheckBox17.setText("jCheckBox16");
        jCheckBox18.setBounds(new Rectangle(15, 88, 15, 12));
        jCheckBox18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox18_actionPerformed(e);
            }
        });
        jCheckBox18.setText("jCheckBox16");
        jCheckBox19.setBounds(new Rectangle(15, 110, 15, 12));
        jCheckBox19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox19_actionPerformed(e);
            }
        });
        jCheckBox19.setText("jCheckBox16");
        jCheckBox110.setBounds(new Rectangle(15, 132, 15, 12));
        jCheckBox110.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox110_actionPerformed(e);
            }
        });
        jCheckBox110.setText("jCheckBox16");
        jCheckBox111.setBounds(new Rectangle(15, 154, 15, 12));
        jCheckBox111.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox111_actionPerformed(e);
            }
        });
        jCheckBox111.setText("jCheckBox16");
        jCheckBox112.setBounds(new Rectangle(15, 176, 15, 12));
        jCheckBox112.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox112_actionPerformed(e);
            }
        });
        jCheckBox112.setText("jCheckBox16");
        jCheckBox113.setBounds(new Rectangle(15, 198, 15, 12));
        jCheckBox113.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox113_actionPerformed(e);
            }
        });
        jCheckBox113.setText("jCheckBox16");
        jCheckBox114.setBounds(new Rectangle(149, 44, 15, 12));
        jCheckBox114.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox114_actionPerformed(e);
            }
        });
        jCheckBox114.setText("jCheckBox16");
        jCheckBox115.setBounds(new Rectangle(149, 66, 15, 12));
        jCheckBox115.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox115_actionPerformed(e);
            }
        });
        jCheckBox115.setText("jCheckBox16");
        jCheckBox116.setBounds(new Rectangle(149, 88, 13, 12));
        jCheckBox116.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox116_actionPerformed(e);
            }
        });
        jCheckBox116.setText("jCheckBox16");
        jCheckBox117.setBounds(new Rectangle(149, 110, 15, 12));
        jCheckBox117.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox117_actionPerformed(e);
            }
        });
        jCheckBox117.setText("jCheckBox16");
        jCheckBox118.setBounds(new Rectangle(149, 132, 15, 12));
        jCheckBox118.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox118_actionPerformed(e);
            }
        });
        jCheckBox118.setText("jCheckBox16");
        jCheckBox119.setBounds(new Rectangle(149, 154, 15, 12));
        jCheckBox119.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox119_actionPerformed(e);
            }
        });
        jCheckBox119.setText("jCheckBox16");
        jCheckBox1110.setBounds(new Rectangle(149, 176, 15, 12));
        jCheckBox1110.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1110_actionPerformed(e);
            }
        });
        jCheckBox1110.setText("jCheckBox16");
        jCheckBox1111.setBounds(new Rectangle(149, 198, 15, 12));
        jCheckBox1111.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1111_actionPerformed(e);
            }
        });
        jCheckBox1111.setText("jCheckBox16");
        jCheckBox1112.setBounds(new Rectangle(278, 44, 15, 12));
        jCheckBox1112.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1112_actionPerformed(e);
            }
        });
        jCheckBox1112.setText("jCheckBox16");
        jCheckBox1113.setBounds(new Rectangle(278, 66, 15, 12));
        jCheckBox1113.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1113_actionPerformed(e);
            }
        });
        jCheckBox1113.setText("jCheckBox16");
        jCheckBox1114.setBounds(new Rectangle(278, 88, 15, 12));
        jCheckBox1114.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1114_actionPerformed(e);
            }
        });
        jCheckBox1114.setText("jCheckBox16");
        jCheckBox1115.setBounds(new Rectangle(278, 110, 15, 12));
        jCheckBox1115.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1115_actionPerformed(e);
            }
        });
        jCheckBox1115.setText("jCheckBox16");
        jCheckBox1116.setBounds(new Rectangle(278, 132, 15, 12));
        jCheckBox1116.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1116_actionPerformed(e);
            }
        });
        jCheckBox1116.setText("jCheckBox16");
        jCheckBox1117.setBounds(new Rectangle(278, 154, 15, 12));
        jCheckBox1117.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1117_actionPerformed(e);
            }
        });
        jCheckBox1117.setText("jCheckBox16");
        jCheckBox1118.setBounds(new Rectangle(278, 176, 15, 12));
        jCheckBox1118.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1118_actionPerformed(e);
            }
        });
        jCheckBox1118.setText("jCheckBox16");
        jCheckBox1119.setBounds(new Rectangle(15, 23, 15, 12));
        jCheckBox1119.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1119_actionPerformed(e);
            }
        });
        jCheckBox1119.setSelected(true);
        jCheckBox1119.setText("jCheckBox16");
        jLabel30.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel30.setText("ANY");
        jLabel30.setBounds(new Rectangle(35, 20, 51, 15));
        jLabel21110.setText("UNKNOWN");
        jLabel21110.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21110.setBounds(new Rectangle(300, 174, 96, 18));
        jLabel21111.setText("SUBSCRIBE");
        jLabel21111.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21111.setBounds(new Rectangle(300, 152, 96, 18));
        jLabel21112.setText("REQUEST_WHENEVER");
        jLabel21112.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21112.setBounds(new Rectangle(300, 130, 110, 18));
        jLabel21113.setText("REQUEST_WHEN");
        jLabel21113.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21113.setBounds(new Rectangle(300, 108, 96, 18));
        jLabel21114.setText("REQUEST");
        jLabel21114.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21114.setBounds(new Rectangle(300, 86, 96, 18));
        jLabel21115.setText("REJECT_PROPOSAL");
        jLabel21115.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21115.setBounds(new Rectangle(300, 64, 101, 18));
        jLabel21116.setText("REFUSE");
        jLabel21116.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21116.setBounds(new Rectangle(300, 42, 96, 18));
        jLabel21117.setText("QUERY_REF");
        jLabel21117.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21117.setBounds(new Rectangle(170, 196, 96, 18));
        jLabel21118.setText("QUERY_IF");
        jLabel21118.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21118.setBounds(new Rectangle(170, 174, 96, 18));
        jLabel21119.setText("PROXY");
        jLabel21119.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21119.setBounds(new Rectangle(170, 152, 96, 18));
        performativeEnd.setLayout(null);
        jLabel2120.setBounds(new Rectangle(170, 130, 96, 18));
        jLabel2120.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2120.setText("PROPOSE");
        jLabel2121.setBounds(new Rectangle(170, 108, 96, 18));
        jLabel2121.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2121.setText("PROPAGATE");
        jLabel2122.setBounds(new Rectangle(170, 86, 98, 18));
        jLabel2122.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2122.setText("NOT_UNDERSTOOD");
        jLabel2123.setBounds(new Rectangle(170, 64, 96, 18));
        jLabel2123.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2123.setText("INFORM_REF");
        jLabel2124.setBounds(new Rectangle(170, 42, 96, 18));
        jLabel2124.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2124.setText("INFORM_IF");
        jLabel2125.setBounds(new Rectangle(35, 196, 96, 18));
        jLabel2125.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2125.setText("INFORM");
        jLabel2126.setBounds(new Rectangle(35, 174, 96, 18));
        jLabel2126.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2126.setText("FAILURE");
        jLabel2127.setBounds(new Rectangle(35, 152, 96, 18));
        jLabel2127.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2127.setText("DISCONFIRM");
        jLabel2128.setBounds(new Rectangle(35, 130, 96, 18));
        jLabel2128.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2128.setText("CONFIRM");
        jLabel2129.setBounds(new Rectangle(35, 108, 96, 18));
        jLabel2129.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2129.setText("CFP");
        jLabel31.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel31.setText("ANY");
        jLabel31.setBounds(new Rectangle(35, 20, 51, 15));
        jCheckBox1120.setBounds(new Rectangle(149, 154, 15, 12));
        jCheckBox1120.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1120_actionPerformed(e);
            }
        });
        jCheckBox1120.setText("jCheckBox16");
        jCheckBox1121.setBounds(new Rectangle(149, 132, 15, 12));
        jCheckBox1121.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1121_actionPerformed(e);
            }
        });
        jCheckBox1121.setText("jCheckBox16");
        jCheckBox1122.setBounds(new Rectangle(149, 110, 15, 12));
        jCheckBox1122.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1122_actionPerformed(e);
            }
        });
        jCheckBox1122.setText("jCheckBox16");
        jCheckBox1123.setBounds(new Rectangle(149, 88, 15, 12));
        jCheckBox1123.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1123_actionPerformed(e);
            }
        });
        jCheckBox1123.setText("jCheckBox16");
        jCheckBox1124.setBounds(new Rectangle(149, 66, 15, 12));
        jCheckBox1124.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1124_actionPerformed(e);
            }
        });
        jCheckBox1124.setText("jCheckBox16");
        jCheckBox1125.setBounds(new Rectangle(149, 44, 15, 12));
        jCheckBox1125.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1125_actionPerformed(e);
            }
        });
        jCheckBox1125.setText("jCheckBox16");
        jLabel220.setBounds(new Rectangle(35, 86, 96, 18));
        jLabel220.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel220.setText("CANCEL");
        jCheckBox1126.setBounds(new Rectangle(15, 198, 15, 12));
        jCheckBox1126.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1126_actionPerformed(e);
            }
        });
        jCheckBox1126.setText("jCheckBox16");
        jLabel221.setBounds(new Rectangle(35, 64, 96, 18));
        jLabel221.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel221.setText("AGREE");
        jCheckBox1127.setBounds(new Rectangle(15, 176, 15, 12));
        jCheckBox1127.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1127_actionPerformed(e);
            }
        });
        jCheckBox1127.setText("jCheckBox16");
        jLabel222.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel222.setText("ACCEPT_PROPOSAL");
        jLabel222.setBounds(new Rectangle(35, 42, 103, 18));
        jCheckBox1128.setBounds(new Rectangle(15, 154, 15, 12));
        jCheckBox1128.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1128_actionPerformed(e);
            }
        });
        jCheckBox1128.setText("jCheckBox16");
        jCheckBox1129.setBounds(new Rectangle(15, 132, 15, 12));
        jCheckBox1129.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox1129_actionPerformed(e);
            }
        });
        jCheckBox1129.setText("jCheckBox16");
        jCheckBox11110.setBounds(new Rectangle(15, 23, 15, 12));
        jCheckBox11110.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11110_actionPerformed(e);
            }
        });
        jCheckBox11110.setSelected(true);
        jCheckBox11110.setText("jCheckBox16");
        jCheckBox11111.setBounds(new Rectangle(278, 176, 15, 12));
        jCheckBox11111.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11111_actionPerformed(e);
            }
        });
        jCheckBox11111.setText("jCheckBox16");
        jCheckBox11112.setBounds(new Rectangle(278, 154, 15, 12));
        jCheckBox11112.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11112_actionPerformed(e);
            }
        });
        jCheckBox11112.setText("jCheckBox16");
        jCheckBox11113.setBounds(new Rectangle(278, 132, 15, 12));
        jCheckBox11113.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11113_actionPerformed(e);
            }
        });
        jCheckBox11113.setText("jCheckBox16");
        jCheckBox11114.setBounds(new Rectangle(278, 110, 15, 12));
        jCheckBox11114.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11114_actionPerformed(e);
            }
        });
        jCheckBox11114.setText("jCheckBox16");
        jCheckBox11115.setBounds(new Rectangle(278, 88, 15, 12));
        jCheckBox11115.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11115_actionPerformed(e);
            }
        });
        jCheckBox11115.setText("jCheckBox16");
        jCheckBox11116.setBounds(new Rectangle(278, 66, 15, 12));
        jCheckBox11116.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11116_actionPerformed(e);
            }
        });
        jCheckBox11116.setText("jCheckBox16");
        jCheckBox11117.setBounds(new Rectangle(278, 44, 15, 12));
        jCheckBox11117.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11117_actionPerformed(e);
            }
        });
        jCheckBox11117.setText("jCheckBox16");
        jCheckBox11118.setBounds(new Rectangle(149, 198, 15, 12));
        jCheckBox11118.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11118_actionPerformed(e);
            }
        });
        jCheckBox11118.setText("jCheckBox16");
        jCheckBox11119.setBounds(new Rectangle(149, 176, 15, 12));
        jCheckBox11119.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox11119_actionPerformed(e);
            }
        });
        jCheckBox11119.setText("jCheckBox16");
        jCheckBox120.setBounds(new Rectangle(15, 110, 15, 12));
        jCheckBox120.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox120_actionPerformed(e);
            }
        });
        jCheckBox120.setText("jCheckBox16");
        jCheckBox121.setBounds(new Rectangle(15, 88, 15, 12));
        jCheckBox121.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox121_actionPerformed(e);
            }
        });
        jCheckBox121.setText("jCheckBox16");
        jCheckBox122.setBounds(new Rectangle(15, 66, 15, 12));
        jCheckBox122.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox122_actionPerformed(e);
            }
        });
        jCheckBox122.setText("jCheckBox16");
        jCheckBox123.setText("jCheckBox16");
        jCheckBox123.setBounds(new Rectangle(15, 44, 15, 12));
        jCheckBox123.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBox123_actionPerformed(e);
            }
        });
        search.setBounds(new Rectangle(457, 112, 82, 27));
        search.setText("Search");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search_actionPerformed(e);
            }
        });
        contentPane.add(jTabbedPane1, null);
        jTabbedPane1.add(initiator, "Initiator");
        protocol.add(jLabel9, null);
        protocol.add(jLabel14, null);
        protocol.add(jLabel13, null);
        protocol.add(jLabel12, null);
        protocol.add(jLabel11, null);
        protocol.add(jLabel10, null);
        protocol.add(jLabel15, null);
        protocol.add(jLabel16, null);
        protocol.add(jLabel17, null);
        protocol.add(jLabel19, null);
        protocol.add(jLabel110, null);
        protocol.add(jLabel18, null);
        protocol.add(jCheckBox1, null);
        protocol.add(jCheckBox2, null);
        protocol.add(jCheckBox3, null);
        protocol.add(jCheckBox4, null);
        protocol.add(jCheckBox5, null);
        protocol.add(jCheckBox6, null);
        protocol.add(jCheckBox8, null);
        protocol.add(jCheckBox9, null);
        protocol.add(jCheckBox10, null);
        protocol.add(jCheckBox11, null);
        protocol.add(jCheckBox12, null);
        protocol.add(jCheckBox7, null);
        contentPane.add(search, null);
        jTabbedPane1.add(ontology, "Ontology");
        ontology.add(jList2, null);
        ontology.add(delOntology, null);
        ontology.add(addOntology, null);
        ontology.add(jScrollPane3, null);
        ontology.add(jLabel21, null);
        jTabbedPane1.add(language, "Language");
        language.add(delLanguage, null);
        language.add(addLanguage, null);
        language.add(jList3, null);
        language.add(jScrollPane4, null);
        language.add(jLabel22, null);
        initiator.add(jList1, null);
        initiator.add(addInitiator, null);
        initiator.add(delInitiator, null);
        initiator.add(jScrollPane2, null);
        initiator.add(jLabel20, null);
        jTabbedPane1.add(result, "Result");
        result.add(jLabel24, null);
        result.add(jLabel25, null);
        result.add(jLabel26, null);
        result.add(jCheckBox13, null);
        result.add(jCheckBox14, null);
        result.add(jCheckBox15, null);
        jTabbedPane1.add(dates, "Time");
        dates.add(minStartDate, null);
        dates.add(jLabel1, null);
        dates.add(jLabel7, null);
        dates.add(minStartHour, null);
        dates.add(maxStartHour, null);
        dates.add(maxStartDate, null);
        dates.add(jLabel5, null);
        dates.add(jLabel3, null);
        dates.add(maxEndDate, null);
        dates.add(maxEndHour, null);
        dates.add(jLabel4, null);
        dates.add(minEndDate, null);
        dates.add(minEndHour, null);
        dates.add(jLabel2, null);
        dates.add(jLabel8, null);
        dates.add(jLabel6, null);
        jTabbedPane1.add(performativeStart, "First performative");
        performativeStart.add(jLabel27, null);
        performativeStart.add(jLabel28, null);
        performativeStart.add(jLabel29, null);
        performativeStart.add(jLabel210, null);
        performativeStart.add(jLabel211, null);
        performativeStart.add(jLabel212, null);
        performativeStart.add(jLabel213, null);
        performativeStart.add(jLabel214, null);
        performativeStart.add(jLabel215, null);
        performativeStart.add(jLabel216, null);
        performativeStart.add(jLabel217, null);
        performativeStart.add(jLabel218, null);
        performativeStart.add(jLabel219, null);
        performativeStart.add(jLabel2110, null);
        performativeStart.add(jLabel2111, null);
        performativeStart.add(jLabel2112, null);
        performativeStart.add(jLabel2113, null);
        performativeStart.add(jLabel2114, null);
        performativeStart.add(jLabel2115, null);
        performativeStart.add(jLabel2116, null);
        performativeStart.add(jLabel2117, null);
        performativeStart.add(jLabel2118, null);
        performativeStart.add(jLabel2119, null);
        performativeStart.add(jCheckBox17, null);
        performativeStart.add(jCheckBox18, null);
        performativeStart.add(jCheckBox19, null);
        performativeStart.add(jCheckBox110, null);
        performativeStart.add(jCheckBox111, null);
        performativeStart.add(jCheckBox112, null);
        performativeStart.add(jCheckBox113, null);
        performativeStart.add(jCheckBox114, null);
        performativeStart.add(jCheckBox115, null);
        performativeStart.add(jCheckBox117, null);
        performativeStart.add(jCheckBox118, null);
        performativeStart.add(jCheckBox119, null);
        performativeStart.add(jCheckBox1110, null);
        performativeStart.add(jCheckBox1111, null);
        performativeStart.add(jCheckBox1112, null);
        performativeStart.add(jCheckBox1113, null);
        performativeStart.add(jCheckBox1114, null);
        performativeStart.add(jCheckBox1115, null);
        performativeStart.add(jCheckBox1116, null);
        performativeStart.add(jCheckBox1117, null);
        performativeStart.add(jCheckBox1118, null);
        performativeStart.add(jCheckBox16, null);
        performativeStart.add(jCheckBox1119, null);
        performativeStart.add(jLabel30, null);
        performativeStart.add(jCheckBox116, null);
        jTabbedPane1.add(performativeEnd, "Last performative");
        performativeEnd.add(jLabel222, null);
        performativeEnd.add(jLabel221, null);
        performativeEnd.add(jLabel220, null);
        performativeEnd.add(jLabel2129, null);
        performativeEnd.add(jLabel2128, null);
        performativeEnd.add(jLabel2127, null);
        performativeEnd.add(jLabel2126, null);
        performativeEnd.add(jLabel2125, null);
        performativeEnd.add(jLabel2124, null);
        performativeEnd.add(jLabel2123, null);
        performativeEnd.add(jLabel2122, null);
        performativeEnd.add(jLabel2121, null);
        performativeEnd.add(jLabel2120, null);
        performativeEnd.add(jLabel21119, null);
        performativeEnd.add(jLabel21118, null);
        performativeEnd.add(jLabel21117, null);
        performativeEnd.add(jLabel21116, null);
        performativeEnd.add(jLabel21115, null);
        performativeEnd.add(jLabel21114, null);
        performativeEnd.add(jLabel21113, null);
        performativeEnd.add(jLabel21112, null);
        performativeEnd.add(jLabel21111, null);
        performativeEnd.add(jLabel21110, null);
        performativeEnd.add(jCheckBox122, null);
        performativeEnd.add(jCheckBox121, null);
        performativeEnd.add(jCheckBox120, null);
        performativeEnd.add(jCheckBox1129, null);
        performativeEnd.add(jCheckBox1128, null);
        performativeEnd.add(jCheckBox1127, null);
        performativeEnd.add(jCheckBox1126, null);
        performativeEnd.add(jCheckBox1125, null);
        performativeEnd.add(jCheckBox1124, null);
        performativeEnd.add(jCheckBox1123, null);
        performativeEnd.add(jCheckBox1122, null);
        performativeEnd.add(jCheckBox1121, null);
        performativeEnd.add(jCheckBox1120, null);
        performativeEnd.add(jCheckBox11119, null);
        performativeEnd.add(jCheckBox11118, null);
        performativeEnd.add(jCheckBox11117, null);
        performativeEnd.add(jCheckBox11116, null);
        performativeEnd.add(jCheckBox11115, null);
        performativeEnd.add(jCheckBox11114, null);
        performativeEnd.add(jCheckBox11113, null);
        performativeEnd.add(jCheckBox11112, null);
        performativeEnd.add(jCheckBox11111, null);
        performativeEnd.add(jCheckBox123, null);
        performativeEnd.add(jCheckBox11110, null);
        performativeEnd.add(jLabel31, null);
        jTabbedPane1.add(protocol, "Protocol");
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    public void getInitiator(String ini) {
        if (ini != null) {
            initiators.add(ini);
            jList1.setListData(initiators);
            jScrollPane2.getViewport().setView(jList1);
        }
    }

    void addInitiator_actionPerformed(ActionEvent e) {
        if (frame2 == null) {
            frame2 = new WindowIntro(this);
            frame2.validate();
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame2.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame2.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        }
        frame2.setVisible(true);
    }

    void delInitiator_actionPerformed(ActionEvent e) {
        int num = jList1.getSelectedIndex();
        if (num != -1) {
            initiators.removeElementAt(num);
            jList1.setListData(initiators);
            jScrollPane2.getViewport().setView(jList1);
        }
    }

    void addOntology_actionPerformed(ActionEvent e) {
        if (frame3 == null) {
            frame3 = new WindowIntroOnto(this);
            frame3.validate();
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame3.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame3.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        }
        frame3.setVisible(true);
    }

    void delOntology_actionPerformed(ActionEvent e) {
        int num = jList2.getSelectedIndex();
        if (num != -1) {
            ontologies.removeElementAt(num);
            jList2.setListData(ontologies);
            jScrollPane3.getViewport().setView(jList2);
        }
    }

    public void getOntology(String onto) {
        if (onto != null) {
            ontologies.add(onto);
            jList2.setListData(ontologies);
            jScrollPane3.getViewport().setView(jList2);
        }
    }

    void addLanguage_actionPerformed(ActionEvent e) {
        if (frame4 == null) {
            frame4 = new WindowIntroLang(this);
            frame4.validate();
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame4.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame4.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        }
        frame4.setVisible(true);
    }

    void delLanguage_actionPerformed(ActionEvent e) {
        int num = jList3.getSelectedIndex();
        if (num != -1) {
            languages.removeElementAt(num);
            jList3.setListData(languages);
            jScrollPane4.getViewport().setView(jList3);
        }
    }

    public void getLanguage(String lang) {
        if (lang != null) {
            languages.add(lang);
            jList3.setListData(languages);
            jScrollPane4.getViewport().setView(jList3);
        }
    }

    private String format(String st) {
        if (st.length() == 2)
            return st;
        else
            return "0" + st;
    }

    void minStartDate_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        try {
            Date date;
            if ((date = df.parse(minStartDate.getText())) == null)
                minStartDate.setText("");
            String day = format("" + date.getDate());
            String month = format("" + (date.getMonth() + 1));
            String year = "" + (date.getYear() + 1900);
            String newer = day + "/" + month + "/" + year;
            minStartDate.setText(newer);
        } catch (Exception ex) {
            minStartDate.setText("");
        }
    }

    void maxStartDate_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        try {
            Date date;
            if ((date = df.parse(maxStartDate.getText())) == null)
                maxStartDate.setText("");
            String day = format("" + date.getDate());
            String month = format("" + (date.getMonth() + 1));
            String year = "" + (date.getYear() + 1900);
            String newer = day + "/" + month + "/" + year;
            maxStartDate.setText(newer);
        } catch (Exception ex) {
            maxStartDate.setText("");
        }
    }

    void minEndDate_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        try {
            Date date;
            if ((date = df.parse(minEndDate.getText())) == null)
                minEndDate.setText("");
            String day = format("" + date.getDate());
            String month = format("" + (date.getMonth() + 1));
            String year = "" + (date.getYear() + 1900);
            String newer = day + "/" + month + "/" + year;
            minEndDate.setText(newer);
        } catch (Exception ex) {
            minEndDate.setText("");
        }
    }

    void maxEndDate_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        try {
            Date date;
            if ((date = df.parse(maxEndDate.getText())) == null)
                maxEndDate.setText("");
            String day = format("" + date.getDate());
            String month = format("" + (date.getMonth() + 1));
            String year = "" + (date.getYear() + 1900);
            String newer = day + "/" + month + "/" + year;
            maxEndDate.setText(newer);
        } catch (Exception ex) {
            maxEndDate.setText("");
        }
    }

    void minStartDate_focusLost(FocusEvent e) {
        minStartDate_actionPerformed(null);
    }

    void maxStartDate_focusLost(FocusEvent e) {
        maxStartDate_actionPerformed(null);
    }

    void minEndDate_focusLost(FocusEvent e) {
        minEndDate_actionPerformed(null);
    }

    void maxEndDate_focusLost(FocusEvent e) {
        maxEndDate_actionPerformed(null);
    }

    void minStartHour_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss", Locale.US);
        try {
            Date date;
            if ((date = df.parse(minStartHour.getText())) == null)
                minStartHour.setText("");
            String hour = format("" + date.getHours());
            String minute = format("" + date.getMinutes());
            String second = format("" + date.getSeconds());
            String newer = hour + ":" + minute + ":" + second;
            minStartHour.setText(newer);
        } catch (Exception ex) {
            minStartHour.setText("");
        }
    }

    void maxStartHour_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss", Locale.US);
        try {
            Date date;
            if ((date = df.parse(maxStartHour.getText())) == null)
                maxStartHour.setText("");
            String hour = format("" + date.getHours());
            String minute = format("" + date.getMinutes());
            String second = format("" + date.getSeconds());
            String newer = hour + ":" + minute + ":" + second;
            maxStartHour.setText(newer);
        } catch (Exception ex) {
            maxStartHour.setText("");
        }
    }

    void minEndHour_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss", Locale.US);
        try {
            Date date;
            if ((date = df.parse(minEndHour.getText())) == null)
                minEndHour.setText("");
            String hour = format("" + date.getHours());
            String minute = format("" + date.getMinutes());
            String second = format("" + date.getSeconds());
            String newer = hour + ":" + minute + ":" + second;
            minEndHour.setText(newer);
        } catch (Exception ex) {
            minEndHour.setText("");
        }
    }

    void maxEndHour_actionPerformed(ActionEvent e) {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss", Locale.US);
        try {
            Date date;
            if ((date = df.parse(maxEndHour.getText())) == null)
                maxEndHour.setText("");
            String hour = format("" + date.getHours());
            String minute = format("" + date.getMinutes());
            String second = format("" + date.getSeconds());
            String newer = hour + ":" + minute + ":" + second;
            maxEndHour.setText(newer);
        } catch (Exception ex) {
            maxEndHour.setText("");
        }
    }

    void minStartHour_focusLost(FocusEvent e) {
        minStartHour_actionPerformed(null);
    }

    void maxStartHour_focusLost(FocusEvent e) {
        maxStartHour_actionPerformed(null);
    }

    void minEndHour_focusLost(FocusEvent e) {
        minEndHour_actionPerformed(null);
    }

    void maxEndHour_focusLost(FocusEvent e) {
        maxEndHour_actionPerformed(null);
    }

    void jCheckBox13_actionPerformed(ActionEvent e) {
        if (jCheckBox13.isSelected()) {
            jCheckBox14.setSelected(false);
            jCheckBox15.setSelected(false);
        }
    }

    void jCheckBox14_actionPerformed(ActionEvent e) {
        if (jCheckBox14.isSelected()) {
            jCheckBox13.setSelected(false);
            jCheckBox15.setSelected(false);
        }
    }

    void jCheckBox15_actionPerformed(ActionEvent e) {
        if (jCheckBox15.isSelected()) {
            jCheckBox14.setSelected(false);
            jCheckBox13.setSelected(false);
        }
    }

    void jCheckBox1_actionPerformed(ActionEvent e) {
        if (jCheckBox1.isSelected()) {
            jCheckBox2.setSelected(false);
            jCheckBox3.setSelected(false);
            jCheckBox4.setSelected(false);
            jCheckBox5.setSelected(false);
            jCheckBox6.setSelected(false);
            jCheckBox7.setSelected(false);
            jCheckBox8.setSelected(false);
            jCheckBox9.setSelected(false);
            jCheckBox10.setSelected(false);
            jCheckBox11.setSelected(false);
            jCheckBox12.setSelected(false);
        }
    }

    void jCheckBox2_actionPerformed(ActionEvent e) {
        if (jCheckBox2.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox3_actionPerformed(ActionEvent e) {
        if (jCheckBox3.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox4_actionPerformed(ActionEvent e) {
        if (jCheckBox4.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox5_actionPerformed(ActionEvent e) {
        if (jCheckBox5.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox6_actionPerformed(ActionEvent e) {
        if (jCheckBox6.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox7_actionPerformed(ActionEvent e) {
        if (jCheckBox7.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox8_actionPerformed(ActionEvent e) {
        if (jCheckBox8.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox9_actionPerformed(ActionEvent e) {
        if (jCheckBox9.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox10_actionPerformed(ActionEvent e) {
        if (jCheckBox10.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox11_actionPerformed(ActionEvent e) {
        if (jCheckBox11.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox12_actionPerformed(ActionEvent e) {
        if (jCheckBox12.isSelected()) {
            jCheckBox1.setSelected(false);
        }
    }

    void jCheckBox1119_actionPerformed(ActionEvent e) {
        if (jCheckBox1119.isSelected()) {
            jCheckBox16.setSelected(false);
            jCheckBox17.setSelected(false);
            jCheckBox18.setSelected(false);
            jCheckBox19.setSelected(false);
            jCheckBox110.setSelected(false);
            jCheckBox111.setSelected(false);
            jCheckBox112.setSelected(false);
            jCheckBox113.setSelected(false);
            jCheckBox114.setSelected(false);
            jCheckBox115.setSelected(false);
            jCheckBox116.setSelected(false);
            jCheckBox117.setSelected(false);
            jCheckBox118.setSelected(false);
            jCheckBox119.setSelected(false);
            jCheckBox1110.setSelected(false);
            jCheckBox1111.setSelected(false);
            jCheckBox1112.setSelected(false);
            jCheckBox1113.setSelected(false);
            jCheckBox1114.setSelected(false);
            jCheckBox1115.setSelected(false);
            jCheckBox1116.setSelected(false);
            jCheckBox1117.setSelected(false);
            jCheckBox1118.setSelected(false);
        }
    }

    void jCheckBox16_actionPerformed(ActionEvent e) {
        if (jCheckBox16.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox17_actionPerformed(ActionEvent e) {
        if (jCheckBox17.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox18_actionPerformed(ActionEvent e) {
        if (jCheckBox18.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox19_actionPerformed(ActionEvent e) {
        if (jCheckBox19.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox110_actionPerformed(ActionEvent e) {
        if (jCheckBox110.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox111_actionPerformed(ActionEvent e) {
        if (jCheckBox111.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox113_actionPerformed(ActionEvent e) {
        if (jCheckBox113.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox112_actionPerformed(ActionEvent e) {
        if (jCheckBox112.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox114_actionPerformed(ActionEvent e) {
        if (jCheckBox114.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox116_actionPerformed(ActionEvent e) {
        if (jCheckBox116.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox115_actionPerformed(ActionEvent e) {
        if (jCheckBox115.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox117_actionPerformed(ActionEvent e) {
        if (jCheckBox117.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox118_actionPerformed(ActionEvent e) {
        if (jCheckBox118.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox119_actionPerformed(ActionEvent e) {
        if (jCheckBox119.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1110_actionPerformed(ActionEvent e) {
        if (jCheckBox1110.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1111_actionPerformed(ActionEvent e) {
        if (jCheckBox1111.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1112_actionPerformed(ActionEvent e) {
        if (jCheckBox1112.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1113_actionPerformed(ActionEvent e) {
        if (jCheckBox1113.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1114_actionPerformed(ActionEvent e) {
        if (jCheckBox1114.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1115_actionPerformed(ActionEvent e) {
        if (jCheckBox1115.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1116_actionPerformed(ActionEvent e) {
        if (jCheckBox1116.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1117_actionPerformed(ActionEvent e) {
        if (jCheckBox1117.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox1118_actionPerformed(ActionEvent e) {
        if (jCheckBox1118.isSelected())
            jCheckBox1119.setSelected(false);
    }

    void jCheckBox11110_actionPerformed(ActionEvent e) {
        if (jCheckBox11110.isSelected()) {
            jCheckBox123.setSelected(false);
            jCheckBox122.setSelected(false);
            jCheckBox121.setSelected(false);
            jCheckBox120.setSelected(false);
            jCheckBox1129.setSelected(false);
            jCheckBox1128.setSelected(false);
            jCheckBox1127.setSelected(false);
            jCheckBox1126.setSelected(false);
            jCheckBox1125.setSelected(false);
            jCheckBox1124.setSelected(false);
            jCheckBox1123.setSelected(false);
            jCheckBox1122.setSelected(false);
            jCheckBox1121.setSelected(false);
            jCheckBox1120.setSelected(false);
            jCheckBox11119.setSelected(false);
            jCheckBox11118.setSelected(false);
            jCheckBox11117.setSelected(false);
            jCheckBox11116.setSelected(false);
            jCheckBox11115.setSelected(false);
            jCheckBox11114.setSelected(false);
            jCheckBox11113.setSelected(false);
            jCheckBox11112.setSelected(false);
            jCheckBox11111.setSelected(false);
        }
    }

    void jCheckBox123_actionPerformed(ActionEvent e) {
        if (jCheckBox123.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox122_actionPerformed(ActionEvent e) {
        if (jCheckBox122.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox121_actionPerformed(ActionEvent e) {
        if (jCheckBox121.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox120_actionPerformed(ActionEvent e) {
        if (jCheckBox120.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1129_actionPerformed(ActionEvent e) {
        if (jCheckBox1129.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1128_actionPerformed(ActionEvent e) {
        if (jCheckBox1128.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1127_actionPerformed(ActionEvent e) {
        if (jCheckBox1127.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1126_actionPerformed(ActionEvent e) {
        if (jCheckBox1126.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1125_actionPerformed(ActionEvent e) {
        if (jCheckBox1125.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1124_actionPerformed(ActionEvent e) {
        if (jCheckBox1124.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1123_actionPerformed(ActionEvent e) {
        if (jCheckBox1123.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1122_actionPerformed(ActionEvent e) {
        if (jCheckBox1122.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1121_actionPerformed(ActionEvent e) {
        if (jCheckBox1121.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox1120_actionPerformed(ActionEvent e) {
        if (jCheckBox1120.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11119_actionPerformed(ActionEvent e) {
        if (jCheckBox11119.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11118_actionPerformed(ActionEvent e) {
        if (jCheckBox11118.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11117_actionPerformed(ActionEvent e) {
        if (jCheckBox11117.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11116_actionPerformed(ActionEvent e) {
        if (jCheckBox11116.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11115_actionPerformed(ActionEvent e) {
        if (jCheckBox11115.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11114_actionPerformed(ActionEvent e) {
        if (jCheckBox11114.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11113_actionPerformed(ActionEvent e) {
        if (jCheckBox11113.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11112_actionPerformed(ActionEvent e) {
        if (jCheckBox11112.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void jCheckBox11111_actionPerformed(ActionEvent e) {
        if (jCheckBox11111.isSelected())
            jCheckBox11110.setSelected(false);
    }

    void search_actionPerformed(ActionEvent e) {
        SearchConversation sc = new SearchConversation();

        // Initiators
        if (initiators.size() > 0) sc.setInitiator(initiators);
        // Languages
        if (languages.size() > 0) sc.setLanguage(languages);
        // Ontologies
        if (ontologies.size() > 0) sc.setOntology(ontologies);

        // Dates
        SimpleDateFormat dfDate = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        SimpleDateFormat dfHour = new SimpleDateFormat("HH:mm:ss", Locale.US);
        String aux;
        Date date;
        Date hour;
        // Minimum start date
        try {
            aux = minStartDate.getText();
            if ((aux != null) && (!aux.equals(""))) {
                date = dfDate.parse(aux);
                aux = minStartHour.getText();
                if ((aux != null) && (!aux.equals(""))) {
                    hour = dfHour.parse(aux);
                    date.setHours(hour.getHours());
                    date.setMinutes(hour.getMinutes());
                    date.setSeconds(hour.getSeconds());
                }
                sc.setMinStartDate(date.getTime());
            }
        } catch (Exception ex) {
            System.err.println("Exception checking date");
        }
        // Maximum start date
        try {
            aux = maxStartDate.getText();
            if ((aux != null) && (!aux.equals(""))) {
                date = dfDate.parse(aux);
                aux = maxStartHour.getText();
                if ((aux != null) && (!aux.equals(""))) {
                    hour = dfHour.parse(aux);
                    date.setHours(hour.getHours());
                    date.setMinutes(hour.getMinutes());
                    date.setSeconds(hour.getSeconds());
                }
                sc.setMaxStartDate(date.getTime());
            }
        } catch (Exception ex) {
            System.err.println("Exception checking date");
        }
        // Minimum end date
        try {
            aux = minEndDate.getText();
            if ((aux != null) && (!aux.equals(""))) {
                date = dfDate.parse(aux);
                aux = minEndHour.getText();
                if ((aux != null) && (!aux.equals(""))) {
                    hour = dfHour.parse(aux);
                    date.setHours(hour.getHours());
                    date.setMinutes(hour.getMinutes());
                    date.setSeconds(hour.getSeconds());
                }
                sc.setMinEndDate(date.getTime());
            }
        } catch (Exception ex) {
            System.err.println("Exception checking date");
        }
        // Maximum end date
        try {
            aux = maxEndDate.getText();
            if ((aux != null) && (!aux.equals(""))) {
                date = dfDate.parse(aux);
                aux = maxEndHour.getText();
                if ((aux != null) && (!aux.equals(""))) {
                    hour = dfHour.parse(aux);
                    date.setHours(hour.getHours());
                    date.setMinutes(hour.getMinutes());
                    date.setSeconds(hour.getSeconds());
                }
                sc.setMaxEndDate(date.getTime());
            }
        } catch (Exception ex) {
            System.err.println("Exception checking date");
        }

        // Protocols
        LinkedList protocols = new LinkedList();
        if (!jCheckBox1.isSelected()) {
            if (jCheckBox2.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_REQUEST);
            if (jCheckBox3.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_QUERY);
            if (jCheckBox4.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_CONTRACT_NET);
            if (jCheckBox5.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_SUBSCRIBE);
            if (jCheckBox6.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_REQUEST_WHEN);
            if (jCheckBox7.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_ITERATED_CONTRACT_NET);
            if (jCheckBox8.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_ENGLISH_AUCTION);
            if (jCheckBox9.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_DUTCH_AUCTION);
            if (jCheckBox10.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_BROKERING);
            if (jCheckBox11.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_RECRUITING);
            if (jCheckBox12.isSelected()) protocols.add(FIPANames.InteractionProtocol.FIPA_PROPOSE);
        }
        if (protocols.size() > 0) sc.setProtocol(protocols);

        // Starting performatives
        LinkedList perfStart = new LinkedList();
        if (!jCheckBox1119.isSelected()) {
            if (jCheckBox16.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL));
            if (jCheckBox17.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.AGREE));
            if (jCheckBox18.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.CANCEL));
            if (jCheckBox19.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.CFP));
            if (jCheckBox110.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.CONFIRM));
            if (jCheckBox111.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.DISCONFIRM));
            if (jCheckBox112.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.FAILURE));
            if (jCheckBox113.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.INFORM));
            if (jCheckBox114.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.INFORM_IF));
            if (jCheckBox115.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.INFORM_REF));
            if (jCheckBox116.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.NOT_UNDERSTOOD));
            if (jCheckBox117.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.PROPAGATE));
            if (jCheckBox118.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.PROPOSE));
            if (jCheckBox119.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.PROXY));
            if (jCheckBox1110.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.QUERY_IF));
            if (jCheckBox1111.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.QUERY_REF));
            if (jCheckBox1112.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.REFUSE));
            if (jCheckBox1113.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL));
            if (jCheckBox1114.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.REQUEST));
            if (jCheckBox1115.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.REQUEST_WHEN));
            if (jCheckBox1116.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.REQUEST_WHENEVER));
            if (jCheckBox1117.isSelected()) perfStart.add(ACLMessage.getPerformative(ACLMessage.SUBSCRIBE));
            if (jCheckBox1118.isSelected()) perfStart.add("UNKNOWN");
        }

        if (perfStart.size() > 0) sc.setPerformStart(perfStart);

        // Ending performatives
        LinkedList perfEnd = new LinkedList();
        if (!jCheckBox11110.isSelected()) {
            if (jCheckBox123.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL));
            if (jCheckBox122.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.AGREE));
            if (jCheckBox121.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.CANCEL));
            if (jCheckBox120.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.CFP));
            if (jCheckBox1129.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.CONFIRM));
            if (jCheckBox1128.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.DISCONFIRM));
            if (jCheckBox1127.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.FAILURE));
            if (jCheckBox1126.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.INFORM));
            if (jCheckBox1125.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.INFORM_IF));
            if (jCheckBox1124.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.INFORM_REF));
            if (jCheckBox1123.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.NOT_UNDERSTOOD));
            if (jCheckBox1122.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.PROPAGATE));
            if (jCheckBox1121.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.PROPOSE));
            if (jCheckBox1120.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.PROXY));
            if (jCheckBox11119.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.QUERY_IF));
            if (jCheckBox11118.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.QUERY_REF));
            if (jCheckBox11117.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.REFUSE));
            if (jCheckBox11116.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL));
            if (jCheckBox11115.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.REQUEST));
            if (jCheckBox11114.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.REQUEST_WHEN));
            if (jCheckBox11113.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.REQUEST_WHENEVER));
            if (jCheckBox11112.isSelected()) perfEnd.add(ACLMessage.getPerformative(ACLMessage.SUBSCRIBE));
            if (jCheckBox11111.isSelected()) perfEnd.add("UNKNOWN");
        }

        if (perfEnd.size() > 0) sc.setPerformEnd(perfEnd);

        // Results
        String result;
        if (jCheckBox13.isSelected())
            result = "ANY";
        else if (jCheckBox14.isSelected())
            result = "Complete";
        else if (jCheckBox15.isSelected())
            result = "Incomplete";
        else
            result = "ANY";
        sc.setResult(result);

        Vector vec = sendQuery(sc);
        showResult(vec);
    }

    private Vector sendQuery(SearchConversation bc) {
        return abd.searchConversation(bc);
    }

    private void showResult(Vector conver) {
        if (frame5 == null) {
            frame5 = new WindowConv(abd, main);
            frame5.validate();
            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame5.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame5.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        }
        frame5.fill(conver);
        frame5.setVisible(true);
    }

    public void end() {
        if (frame2 != null) frame2.end();
        if (frame3 != null) frame3.end();
        if (frame4 != null) frame4.end();
        if (frame5 != null) frame5.end();
        setVisible(false);
        dispose();
    }

}