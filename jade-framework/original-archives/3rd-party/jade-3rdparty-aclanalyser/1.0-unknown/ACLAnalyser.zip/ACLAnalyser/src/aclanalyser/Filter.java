package aclanalyser;

import java.io.*;

public class Filter extends javax.swing.filechooser.FileFilter {

    public boolean accept(File file) {
        if (file.isDirectory())
            return true;
        else {
            String name = file.getName();
            if (name.length() > 4) {
                String extension = name.substring(name.length() - 4, name.length());
                if (extension.equals(".pro"))
                    return true;
                else
                    return false;
            } else
                return false;
        }
    }

    public String getDescription() {
        return "Accepts folders and .pro files";
    }
}