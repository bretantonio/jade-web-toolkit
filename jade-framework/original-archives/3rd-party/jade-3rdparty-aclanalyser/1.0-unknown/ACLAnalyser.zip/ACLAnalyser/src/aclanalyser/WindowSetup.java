package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Properties;
import java.io.File;
import java.io.*;

public class WindowSetup extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private JTextField jTextField2 = new JTextField();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JTextField jTextField3 = new JTextField();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JTextField jTextField4 = new JTextField();
    private JPasswordField jPasswordField1 = new JPasswordField();

    private DBAccess abd;
    private WindowMain window;

    // Build the frame
    public WindowSetup(DBAccess access, WindowMain w) {
        window = w;
        abd = access;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            fill();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cyclops.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Time for conversation (mseg): ");
        jLabel1.setBounds(new Rectangle(30, 110, 175, 22));
        contentPane.setLayout(null);
        this.setSize(new Dimension(371, 361));
        this.setTitle("Setup");
        jTextField1.setBounds(new Rectangle(208, 110, 118, 22));
        jTextField2.setBounds(new Rectangle(208, 215, 118, 22));
        jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
        jLabel3.setText("ROCK");
        jLabel3.setBounds(new Rectangle(74, 178, 100, 22));
        jLabel4.setText("K:");
        jLabel4.setBounds(new Rectangle(74, 215, 100, 22));
        jLabel5.setText("Bound:");
        jLabel5.setBounds(new Rectangle(74, 240, 100, 22));
        jTextField3.setBounds(new Rectangle(208, 240, 119, 22));
        jButton1.setBounds(new Rectangle(72, 294, 90, 25));
        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(193, 294, 90, 25));
        jLabel2.setBounds(new Rectangle(30, 25, 162, 22));
        jLabel2.setText("Usuario: ");
        jLabel6.setBounds(new Rectangle(30, 50, 162, 22));
        jLabel6.setText("Password: ");
        jTextField4.setBounds(new Rectangle(208, 25, 118, 22));
        jPasswordField1.setBounds(new Rectangle(208, 50, 118, 22));
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
        contentPane.add(jLabel5, null);
        contentPane.add(jLabel4, null);
        contentPane.add(jLabel3, null);
        contentPane.add(jTextField2, null);
        contentPane.add(jTextField3, null);
        contentPane.add(jLabel1, null);
        contentPane.add(jTextField1, null);
        contentPane.add(jLabel2, null);
        contentPane.add(jLabel6, null);
        contentPane.add(jTextField4, null);
        contentPane.add(jPasswordField1, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private void fill() {
        jTextField1.setText("" + ControlProtocol.MAX_TIME);
        jTextField2.setText("" + Rock.K);
        jTextField3.setText("" + Rock.bound);

        jTextField4.setText(getUser());
        jPasswordField1.setText(getPasswd());
    }

    private String getUser() {
        return System.getProperty("db_user");
    }

    private String getPasswd() {
        return System.getProperty("db_password");
    }

    private void setValues(String user, String pass) {
        Properties props = System.getProperties();

        props.setProperty("db_user", user);
        props.setProperty("db_password", pass);
    }

    void jButton1_actionPerformed(ActionEvent e) {
        String aux;
        long auxiliar;
        double auxiliar2;

        aux = jTextField1.getText();
        Long num = new Long(aux);
        auxiliar = num.longValue();
        ControlProtocol.MAX_TIME = auxiliar;

        aux = jTextField2.getText();
        Double number = new Double(aux);
        auxiliar2 = number.doubleValue();
        Rock.K = auxiliar2;

        aux = jTextField3.getText();
        number = new Double(aux);
        auxiliar2 = number.doubleValue();
        Rock.bound = auxiliar2;

        String usu = jTextField4.getText();
        String pass = jPasswordField1.getText();

        if ((!usu.equals(getUser())) || (!pass.equals(getPasswd()))) {
            setValues(usu, pass);
            abd.connect();
        }
        window.update();
        end();
    }

    void jButton2_actionPerformed(ActionEvent e) {
        window.update();
        end();
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}