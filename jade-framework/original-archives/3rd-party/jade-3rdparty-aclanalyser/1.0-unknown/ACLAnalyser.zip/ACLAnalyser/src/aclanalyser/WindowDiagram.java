package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedList;
import java.util.Vector;
import java.io.*;

public class WindowDiagram extends JFrame implements Termination {
    private JPanel contentPane;
    private CanvasPanel panel;
    private String conversation;

    // Build the frame
    public WindowDiagram(Vector agents, Vector messages, String conv) {
        conversation = conv;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            fillAgents(agents);
            fillMessages(messages);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "searchConv.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(556, 368));
        this.setTitle("Sequence diagram of conversation " + conversation);
        panel = new CanvasPanel();
        panel.setBounds(new Rectangle(0, 0, 556, 320));
        JScrollPane pc = new JScrollPane();
        pc.setBounds(new Rectangle(0, 0, 556, 320));
        pc.setColumnHeaderView(panel.canvAgent);
        pc.setViewportView(panel);

        contentPane.add(pc, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private void fillAgents(Vector agents) {
        String aux;
        for (int i = 0; i < agents.size(); i++) {
            aux = (String) agents.get(i);
            panel.addAgent(format(aux));
        }
    }

    private void fillMessages(Vector messages) {
        LocatedMessage me;
        Vector vector;
        LinkedList list;
        String aux;
        int type;

        for (int i = 0; i < messages.size(); i++) {
            me = (LocatedMessage) messages.get(i);
            vector = me.getReceivers();
            list = new LinkedList();
            for (int j = 0; j < vector.size(); j++) {
                aux = (String) vector.get(j);
                list.add(format(aux));
            }
            if (me.getValid().equals("T"))
                type = 0;
            else
                type = 1;
            panel.addMessage(format(me.getSender()), list, me.getPerformative(), type);
        }
    }

    private String format(String st) {
        int pos = st.indexOf("@");
        return st.substring(0, pos);
    }

    public void end() {
        setVisible(false);
        dispose();
    }

}