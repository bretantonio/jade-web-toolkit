package aclanalyser;

interface AgentMark {
    public void agentMarked(String id);
}