LCP=.

# Default locations of jars we depend on
DIRLIBS=../lib/*.jar
for i in ${DIRLIBS}
do
    if [ "$i" != "${DIRLIBS}" ] ; then
      if [ -z "$LCP" ] ; then
        LCP=$i
      else
        LCP="$i":$LCP
      fi
    fi
done

LCP=$LCP:ACLAnalyser.jar:../../../lib/jade.jar:../../../lib/jadeTools.jar:../../../lib/Base64.jar:../../../lib/iiop.jar

java -Ddb_connection=@db_connection@ -Ddb_driver=@db_driver@ -Ddb_user=@db_user@ -Ddb_password=@db_password@ -classpath "$LCP" -mx250M aclanalyser.DefaultProtocolsCreator -gui
