package aclanalyser;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.awt.event.*;
import java.awt.*;
import java.io.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.Spacer;
import org.jfree.chart.StandardLegend;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.StandardXYItemRenderer;
import org.jfree.chart.renderer.XYItemRenderer;
import org.jfree.data.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.data.time.*;

import java.util.Vector;

public class TimeSerie extends ApplicationFrame implements Termination {

    private DBAccess abd;

    public TimeSerie(String title, DBAccess access, String session) {

        super(title + " - Session: " + session);
        abd = access;

        XYDataset dataset = createDataset();

        JFreeChart chart = createChart(dataset);

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        chartPanel.setMouseZoomable(true, false);
        setContentPane(chartPanel);

        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cheese.gif"));
    }

    protected void processWindowEvent(WindowEvent e) {
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private JFreeChart createChart(XYDataset dataset) {

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Distribution of messages in time",
                "Time", "Messages Per Minute",
                dataset,
                true,
                true,
                false
        );

        chart.setBackgroundPaint(Color.white);

        StandardLegend sl = (StandardLegend) chart.getLegend();
        sl.setDisplaySeriesShapes(true);

        XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.lightGray);
        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);
        plot.setAxisOffset(new Spacer(Spacer.ABSOLUTE, 5.0, 5.0, 5.0, 5.0));
        plot.setDomainCrosshairVisible(true);
        plot.setRangeCrosshairVisible(true);

        XYItemRenderer renderer = plot.getRenderer();
        if (renderer instanceof StandardXYItemRenderer) {
            StandardXYItemRenderer rr = (StandardXYItemRenderer) renderer;
            rr.setPlotShapes(true);
            rr.setShapesFilled(true);
        }

        DateAxis axis = (DateAxis) plot.getDomainAxis();
        axis.setDateFormatOverride(new SimpleDateFormat("HH:mm"));

        return chart;
    }

    private XYDataset createDataset() {

        TimeSeries s1 = new TimeSeries("Messages", Minute.class);
        Vector vector = abd.getTimeSerie();
        TimeSerieCell cell;
        long min_date = -1;


        for (int i = 0; i < vector.size(); i++) {
            cell = (TimeSerieCell) vector.get(i);
            if (i == 0) min_date = cell.getDate();
            s1.add(new Minute(new java.util.Date(cell.getDate())), cell.getNumber());
        }
        if ((vector.size() < 6) && (vector.size() > 0)) {
            long date = min_date;
            for (int i = vector.size(); i < 6; i++) {
                date -= 60000;
                s1.add(new Minute(new java.util.Date(date)), 0);
            }
        }
        TimeSeriesCollection dataset = new TimeSeriesCollection();

        dataset.addSeries(s1);
        dataset.setDomainIsPointsInTime(false);

        return dataset;
    }

    static public TimeSerie execute(DBAccess abd, String session) {

        TimeSerie demo = new TimeSerie("Time Serie", abd, session);
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);

        return demo;
    }

    public void end() {
        setVisible(false);
        dispose();
    }

}