package aclanalyser;

import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.LinkedList;

public class CanvasPanel extends JPanel {

    public MMCanva canvAgent;
    public MMCanva canvMess;

    public CanvasPanel() {
        GridBagConstraints gbc;
        setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.weightx = 0.5;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.BOTH;
        canvAgent = new MMCanva(true, this, null);
        add(canvAgent, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 100;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 0.5;
        gbc.weighty = 1;


        canvMess = new MMCanva(false, this, canvAgent);
        add(canvMess, gbc);
    }

    public void addAgent(String name) {
        canvAgent.addAgent(new Agent(name));
    }

    public void addMessage(String or, LinkedList dest, String perf, int type) {
        canvMess.addMessage(new Message(or, dest, perf, type));
    }

}