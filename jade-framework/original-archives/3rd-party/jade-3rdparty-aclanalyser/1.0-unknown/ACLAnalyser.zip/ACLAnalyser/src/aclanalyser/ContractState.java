package aclanalyser;

import jade.core.*;

import java.util.*;

/**
 * Represents the state for a multiple conversation, i.e. a conversation
 * between one initiator and several participants.
 */
public class ContractState extends State {
    private LinkedList participants;

    /**
     * Creates a new instance of ContractState.
     * @param state Initial state.
     * @param init Initiator agent.
     * @param conv Related conversation.
     */
    public ContractState(int state, AID init, Conversation conv) {
        super(state, init, conv);
        participants = new LinkedList();
    }

    /**
     * Returns the state of a series of agents, if they have the same
     * state, or -1 otherwise.
     * @param agents List of agents.
     * @return Common state.
     */
    public int getState(Iterator agents) {
        AID agent;
        int state;

        agent = (AID) agents.next();
        state = getState(agent);

        while (agents.hasNext()) {
            agent = (AID) agents.next();
            if (state != getState(agent)) return -1;
        }
        return state;
    }

    /**
     * Returns the state of an agent in the conversation.
     * @param agent Requested agent.
     * @return Agent's state.
     */
    public int getState(AID agent) {
        int pos = position(agent);
        ParticipantCell aux;

        if (pos != -1) {
            aux = (ParticipantCell) participants.get(pos);
            return aux.getState();
        } else
            return 0;
    }

    private int position(AID agent) {
        int size = participants.size();
        int i;
        ParticipantCell aux;

        for (i = 0; i < size; i++) {
            aux = (ParticipantCell) participants.get(i);
            if (aux.getAgent().equals(agent)) break;
        }
        if (i == size) return -1;
        return i;

    }

    /**
     * Sets the state for a series of agents in the conversation.
     * @param state New state.
     * @param agents List of agents.
     */
    public void setState(int state, Iterator agents) {
        Object obj;
        AID agent;

        while (agents.hasNext()) {
            obj = agents.next();
            if (obj instanceof AID) {
                agent = (AID) obj;
                setState(state, agent);
            }
        }
    }

    /**
     * Sets the state of an agent in the conversation.
     * @param state New state.
     * @param agent Agent.
     */
    public void setState(int state, AID agent) {
        ParticipantCell aux;
        int pos = position(agent);

        if (pos == -1) {
            aux = new ParticipantCell(agent, state);
            participants.add(aux);
        } else {
            aux = (ParticipantCell) participants.get(pos);
            aux.setState(state);
        }
    }

    /**
     * Indicates if the conversation may be finished, depending on the state of its
     * participants.
     * @return Whether the conversation has finished or not.
     */
    public boolean end() {
        // It's finished if any participant is in OK_STATE
        // or at least one is in ERROR_STATE
        int size = participants.size();
        int i;
        ParticipantCell aux;

        for (i = 0; i < size; i++) {
            aux = (ParticipantCell) participants.get(i);
            if (aux.getState() == ControlProtocol.ERROR_STATE) {
                setState(ControlProtocol.ERROR_STATE);
                return true;
            } else if (aux.getState() != ControlProtocol.OK_STATE)
                return false;
        }
        setState(ControlProtocol.OK_STATE);
        return true;
    }

    /**
     * Sets an alarm for an agent, stopping if needed the possible existing one.
     * @param time Duration of the alarm.
     * @param agent Agent.
     */
    public void setAlarm(long time, AID agent) {
        ParticipantCell aux;
        int pos = position(agent);

        if (pos != -1) {
            aux = (ParticipantCell) participants.get(pos);
            Alarm alarm = aux.getAlarm();
            if (alarm != null) alarm.stop();
            alarm = new Alarm(time, this, agent);
            aux.setAlarm(alarm);
            alarm.start();
        }
    }

    /**
     * Stops an agent's alarm.
     * @param agent Agent.
     */
    public void stopAlarm(AID agent) {
        ParticipantCell aux;
        int pos = position(agent);

        if (pos != -1) {
            aux = (ParticipantCell) participants.get(pos);
            Alarm alarm = aux.getAlarm();
            if (alarm != null) {
                alarm.clean();
                alarm.stop();
            }
        }
    }

    /**
     * Notifies to the conversation that one alarm has expired,
     * modifying previously the agent's state in the conversation.
     * @param agent Agent with the expired alarm.
     */
    public synchronized void notification(AID agent) {
        ParticipantCell aux;
        int pos = position(agent);

        if (pos != -1) {
            aux = (ParticipantCell) participants.get(pos);
            switch (aux.getState()) {
                case ControlProtocol.POSSIBLE_OK_STATE:
                    {
                        aux.setState(ControlProtocol.OK_STATE);
                        conversation.notification();
                        break;
                    }
                case ControlProtocol.OK_STATE:
                    {
                        conversation.notification();
                        break;
                    }
                case ControlProtocol.ERROR_STATE:
                    {
                        conversation.notification();
                        break;
                    }
                default:
                    {
                        aux.setState(ControlProtocol.ERROR_STATE);
                        conversation.notification();
                        break;
                    }
            }
        }
    }

    private class ParticipantCell {
        private int state;
        private AID agent;
        private Alarm alarm;

        public ParticipantCell(AID ag, int stat) {
            state = stat;
            agent = (AID) ag.clone();
            alarm = null;
        }

        public AID getAgent() {
            return agent;
        }

        public int getState() {
            return state;
        }

        public void setState(int state) {
            this.state = state;
        }

        public void setAlarm(Alarm alarm) {
            this.alarm = alarm;
        }

        public Alarm getAlarm() {
            return alarm;
        }
    }

}