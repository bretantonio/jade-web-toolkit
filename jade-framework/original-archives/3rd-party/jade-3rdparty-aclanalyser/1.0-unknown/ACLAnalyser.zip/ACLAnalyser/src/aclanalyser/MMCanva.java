package aclanalyser;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import jade.core.AID;

public class MMCanva extends JPanel {

    private static final int timeUnitWidth = 20;
    private static final int xOffset = 38;

    private CanvasPanel panCan;
    private int horDim = 400;
    private int vertDim = 200;
    private boolean typeCanv;
    private Font font = new Font("SanSerif", Font.PLAIN, 10);
    private MMCanva otherCanv;
    public AgentList al;
    public MessageList ml;

    public MMCanva(boolean type, CanvasPanel panCan, MMCanva other) {
        super();
        otherCanv = other;
        typeCanv = type;
        al = new AgentList();
        ml = new MessageList();
        this.panCan = panCan;
        setDoubleBuffered(false);

        if (typeCanv)
            setPreferredSize(new Dimension(horDim, 50));
        else
            setPreferredSize(new Dimension(horDim, vertDim));
    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);

        int yDim = 0;
        int xSource = 0;
        int xDest = 0;

        int xCanvDim = 0;
        try {
            if (typeCanv == true) {

                Iterator it = al.getAgents();
                while (it.hasNext()) {

                    Agent agent = (Agent) it.next();

                    int x = Agent.yRet + (xCanvDim++) * 80;

                    if (agent.onCanv == false)
                        g.setColor(Color.gray);
                    else
                        g.setColor(Color.yellow);

                    g.draw3DRect(x, Agent.yRet, Agent.bRet, Agent.hRet, true);
                    g.fill3DRect(x, Agent.yRet, Agent.bRet, Agent.hRet, true);

                    g.setColor(Color.black);
                    FontMetrics fm = g.getFontMetrics();
                    String aName = agent.agentName;
                    int nameWidth = fm.stringWidth(aName);
                    if (nameWidth < Agent.bRet) {
                        g.drawString(aName, x + (Agent.bRet - nameWidth) / 2, Agent.yRet + (Agent.hRet / 2) + (fm.getAscent() / 2));
                    } else {
                        int len = aName.length();
                        String part1;
                        String part2;
                        String part3;
                        if (nameWidth < Agent.bRet * 2) {
                            part1 = aName.substring(0, len / 2);
                            part2 = aName.substring(len / 2);
                            g.drawString(part1, x + (Agent.bRet - fm.stringWidth(part1)) / 2, Agent.yRet + (Agent.hRet / 2) - (int) (fm.getAscent() * 0.2));
                            g.drawString(part2, x + (Agent.bRet - fm.stringWidth(part2)) / 2, Agent.yRet + (Agent.hRet / 2) + (int) (fm.getAscent() * 0.9));

                        } else if (nameWidth < Agent.bRet * 3) {
                            part1 = aName.substring(0, len / 3);
                            part2 = aName.substring(len / 3, 2 * len / 3);
                            part3 = aName.substring(2 * len / 3);
                            g.drawString(part1, x + (Agent.bRet - fm.stringWidth(part1)) / 2, Agent.yRet + (Agent.hRet / 2) - (int) (fm.getAscent() * 0.65));
                            g.drawString(part2, x + (Agent.bRet - fm.stringWidth(part2)) / 2, Agent.yRet + (Agent.hRet / 2) + (int) (fm.getAscent() * 0.3));
                            g.drawString(part3, x + (Agent.bRet - fm.stringWidth(part3)) / 2, Agent.yRet + (Agent.hRet / 2) + (int) (fm.getAscent() * 0.95));

                        } else {
                            int approxCharWidth = nameWidth / agent.agentName.length();
                            int charCount = Agent.bRet / approxCharWidth;
                            part1 = aName.substring(0, charCount);
                            if (aName.length() < (charCount * 2)) {
                                part2 = aName.substring(charCount);
                                part3 = "";
                            } else {
                                part2 = aName.substring(charCount, (charCount * 2));
                                if (charCount * 3 > aName.length()) {
                                    part3 = aName.substring(charCount * 2);
                                } else {
                                    part3 = aName.substring(charCount * 2, (charCount * 3));
                                }
                            }
                            g.drawString(part1, x + (Agent.bRet - fm.stringWidth(part1)) / 2, Agent.yRet + (Agent.hRet / 2) - (int) (fm.getAscent() * 0.65));
                            g.drawString(part2, x + (Agent.bRet - fm.stringWidth(part2)) / 2, Agent.yRet + (Agent.hRet / 2) + (int) (fm.getAscent() * 0.3));
                            g.drawString(part3, x + (Agent.bRet - fm.stringWidth(part3)) / 2, Agent.yRet + (Agent.hRet / 2) + (int) (fm.getAscent() * 0.95));
                        }
                    }
                }

                horDim = 100 + (xCanvDim * 80);
            }

            if ((typeCanv == false)) {

                int x1,x2,y;
                int xCoords[] = new int[3];
                int yCoords[] = new int[3];
                xCanvDim = otherCanv.al.size();

                Iterator it = ml.getMessages();
                int AllReceiver = 0;
                int receiverForAMessage = 0;
                while (it.hasNext()) {
                    Message mess = (Message) it.next();
                    String senderName = mess.getSender().getName();
                    xSource = otherCanv.al.getPos(senderName);
                    receiverForAMessage = 0;
                    for (Iterator i = mess.getAllReceiver(); i.hasNext();) {
                        receiverForAMessage++;
                        String receiverName = ((AID) i.next()).getName();
                        xDest = otherCanv.al.getPos(receiverName);

                        x1 = mess.getInitSec(xSource);
                        x2 = mess.getEndSec(xDest);
                        y = mess.getOrdSec(yDim++);

                        xCoords[0] = x2 - 6;
                        xCoords[1] = x2 - 6;
                        xCoords[2] = x2 + 2;
                        yCoords[0] = y - 5;
                        yCoords[1] = y + 5;
                        yCoords[2] = y;

                        if (x1 > x2) {
                            xCoords[0] = x2 + 10;
                            xCoords[1] = x2 + 10;
                            xCoords[2] = x2 + 2;
                        }

                        if (mess.getType() == 0)
                            g.setColor(Color.blue);
                        else
                            g.setColor(Color.red);
                        g.drawRect(x1 - 3, y - 4, 4, 8);
                        g.fillRect(x1 - 3, y - 4, 4, 8);
                        g.setFont(font);
                        FontMetrics fmPerf = g.getFontMetrics();
                        String perf = mess.getPerform();

                        int perfWidth = fmPerf.stringWidth(perf);
                        if (x2 > x1) {
                            g.drawString(perf, x1 + ((x2 - x1) / 2) - perfWidth / 2, y - 4);
                        } else {
                            g.drawString(perf, x2 + ((x1 - x2) / 2) - perfWidth / 2, y - 4);
                        }

                        for (int k = -1; k <= 1; k++) {
                            if (x2 > x1)
                                g.drawLine(x1, y + k, x2, y + k);
                            else
                                g.drawLine(x1, y + k, x2 + 4, y + k);
                        }

                        g.drawPolygon(xCoords, yCoords, 3);
                        g.fillPolygon(xCoords, yCoords, 3);
                    }
                    AllReceiver = AllReceiver + receiverForAMessage;
                }

                for (int num = 0; num < xCanvDim; num++) {
                    int x = Agent.yRet / 2 + num * 80;
                    g.setColor(new Color(0, 100, 50));
                    int counter = 0;
                    for (Iterator i = ml.getMessages(); i.hasNext();) {
                        Message msg = (Message) i.next();
                        int singleMsgCounter = 0;
                        for (Iterator j = msg.getAllReceiver(); j.hasNext();) {
                            j.next();
                            singleMsgCounter++;
                            msg.setMessageNumber(counter + singleMsgCounter);
                        }
                        counter = counter + singleMsgCounter;
                    }
                    g.drawLine(x + xOffset, 1, x + xOffset, timeUnitWidth * (counter + 1));
                }

                g.setColor(new Color(150, 50, 50));
                Integer msgNumWrapped;
                for (int t = 0; t <= AllReceiver; t++) {
                    msgNumWrapped = new Integer(t);
                    g.drawString(msgNumWrapped.toString(), 10, timeUnitWidth * (t) + 15);
                }
                horDim = 100 + (xCanvDim * 80);
                vertDim = 100 + (yDim * 20);
            }
        } catch (ConcurrentModificationException cme) {
        }
    }

    private void repaintBothCanvas() {
        MMCanva c1 = panCan.canvAgent;
        MMCanva c2 = panCan.canvMess;

        panCan.setPreferredSize(new Dimension(horDim, vertDim + 50));
        c1.setPreferredSize(new Dimension(horDim, 50));
        c2.setPreferredSize(new Dimension(horDim, vertDim));
        panCan.revalidate();
        c1.repaint();
        c2.repaint();
    }


    public void addAgent(Agent agent) {
        al.addAgent(agent);
        repaintBothCanvas();
    }

    public void removeAgent(String agentName) {
        try {
            al.removeAgent(agentName);
            repaintBothCanvas();
        } catch (Exception e) {
        }
    }

    public void removeAllAgents() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                al.removeAllAgents();
                ml.removeAllMessages();
                repaintBothCanvas();
            }
        });
    }

    public void addMessage(final Message mess) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ml.addMessage(mess);
                repaintBothCanvas();
            }
        });
    }

    public void removeAllMessages() {
        try {
            ml.removeAllMessages();
            repaintBothCanvas();
        } catch (Exception e) {
        }
    }

    private class MessageList {

        private List messages;

        public MessageList() {
            messages = new ArrayList(50);
        }

        public void addMessage(Message mess) {
            messages.add(mess);
        }

        public void removeMessages(String agentName) {

            Iterator it = messages.iterator();
            while (it.hasNext()) {
                Message mess = (Message) it.next();
                String senderName = mess.getSender().getName();
                String receiverName = ((AID) mess.getAllReceiver().next()).getName();
                if ((agentName.equalsIgnoreCase(senderName)) || (agentName.equals(receiverName))) {
                    it.remove();
                }
            }
        }

        public void removeAllMessages() {
            messages.clear();
        }

        public Iterator getMessages() {
            return messages.iterator();
        }

        public int size() {
            return messages.size();
        }
    }

    private class AgentList {

        public List agents;

        public AgentList() {
            agents = new ArrayList(50);
        }

        public void addAgent(Agent agent) {
            agents.add(agent);
        }

        public void removeAgent(String agentName) {
            Iterator it = agents.iterator();
            while (it.hasNext()) {
                Agent agent = (Agent) it.next();
                if (agentName.equals(agent.agentName) && agent.onCanv == true) {
                    agents.remove(agent);
                }
            }
        }

        public void removeAllAgents() {
            agents.clear();
        }

        public boolean isPresent(String agName) {
            Iterator it = agents.iterator();
            while (it.hasNext()) {
                Agent agent = (Agent) it.next();
                if (agent.equals(agName)) {
                    return true;
                }
            }
            return false;
        }

        public int getPos(String agName) {
            int i = 0;

            Iterator it = agents.iterator();
            while (it.hasNext()) {
                Agent agent = (Agent) it.next();
                if (agent.equals(agName)) {
                    return i;
                }
                i = i + 1;
            }

            return 0;
        }

        public Iterator getAgents() {
            return agents.iterator();
        }

        public int size() {
            return agents.size();
        }
    }

}