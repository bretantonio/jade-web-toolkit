package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class WindowSaveSession extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private DBAccess abd;
    private int mode;
    private WindowMain window;

    // Build the frame
    public WindowSaveSession(DBAccess access, int mode, WindowMain win) {
        window = win;
        abd = access;
        this.mode = mode;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cyclops.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Do you want to save the current session?");
        jLabel1.setBounds(new Rectangle(25, 36, 240, 19));
        contentPane.setLayout(null);
        this.setSize(new Dimension(284, 148));
        this.setTitle("Save session");
        jButton1.setBounds(new Rectangle(57, 84, 71, 24));
        jButton1.setText("Yes");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setText("No");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(139, 84, 71, 24));
        contentPane.add(jButton1, null);
        contentPane.add(jLabel1, null);
        contentPane.add(jButton2, null);

        update();
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            callNo();
        }
    }

    private void update() {
        validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        setVisible(true);
    }

    void jButton1_actionPerformed(ActionEvent e) {
        WindowIntroSession frame = new WindowIntroSession(this, abd.getSessionName());
        // Validate frames with preset sizes.
        // Pack frames with important size information. For instance about its design.
        frame.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        frame.setVisible(true);
    }

    public void end(boolean response, String name) {
        if (response) {
            abd.updateSessionName(name);
            window.response(mode);
            end();
        }
    }

    void jButton2_actionPerformed(ActionEvent e) {
        callNo();
    }

    private void callNo() {
        abd.removeSession();
        window.response(mode);
        end();
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}