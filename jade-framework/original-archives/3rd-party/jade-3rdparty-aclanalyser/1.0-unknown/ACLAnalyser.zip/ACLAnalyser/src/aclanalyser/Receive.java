package aclanalyser;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class Receive extends Agent {

    private int num = 0;
    private int maxim = 35000;
    private long startDate;
    private long endDate;

    protected void setup() {
        addBehaviour(new Reception());
    }

    private class Reception extends CyclicBehaviour {

        public void action() {
            ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.REQUEST));
            if (msg != null) {
                num++;
                if (num == 1)
                    startDate = System.currentTimeMillis();
                else if (num == maxim) {
                    endDate = System.currentTimeMillis();
                    System.out.println("Time = " + (endDate - startDate));
                }

                ACLMessage response = msg.createReply();
                response.setPerformative(ACLMessage.INFORM);
                send(response);
            } else // if no message has arrived, block the behaviour
                block();
        }
    }


}