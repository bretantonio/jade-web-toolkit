package aclanalyser;

import java.util.*;

import jade.lang.acl.*;
import jade.core.*;

import java.awt.*;
import javax.swing.*;

/**
 * Receives and analyzes all the messages intercepted by the Debugger.
 * Saves the detected conversations, watching their evolutions. This way it knows
 * when a conversation has ended and forces it to be stored in database.
 */
public class ControlProtocol {

    // final variables
    public static final int ERROR_STATE = -1;
    public static final int NOT_PRESENT = -1;
    public static final int PRESENT = -2;
    public static final int OK_STATE = 10;
    public static final int POSSIBLE_OK_STATE = OK_STATE - 1;
    public static final int MAX_STATES = OK_STATE;
    public static final int MAX_AGENTS = 1200;
    public static final int MAX_MESSAGES = 200000;
    public static final int MAX_ELEMENTS = 10000;
    public static final int MAX_MES_SEC = 10000;
    public static final String INITIATOR = "INITIATOR";
    public static final String PARTICIPANT = "PARTICIPANT";
    public static final String ANY_ROL = "ANY";
    public static final String UNKNOWN_ROL = "Rol Unknown";
    public static final String SIMPLE = "Simple";
    public static final String MULTIPLE = "Multiple";
    public static final String UNKNOWN_PROTOCOL = "UNKNOWN";
    public static final int TIMEOUT = 0;
    public static final int NORMAL = 1;

    // configurable variables
    public static long MAX_TIME = 180000; // 180 seconds

    private LinkedList listConversations;
    private LinkedList listProtocols;
    private DBAccess abd;
    private WindowMain mainWindow = null;
    private boolean sniff = false;
    private jade.core.Agent agent;

    /**
     * Creates a new ControlProtocol.
     * @param agent Agent performing the debugging, which is in charge of sending the
     * messages to be analyzed.
     */
    public ControlProtocol(jade.core.Agent agent) {
        this.agent = agent;
        abd = new DBAccess(this);
        abd.connect();
        mainWindow = startMainScreen();
        listProtocols = Protocol.loadDefaultProtocols();
        listConversations = new LinkedList();
    }

    /**
     * Analyzes and manages a new received message.
     * @param sms Message to be analyzed.
     * @param date Message sending date.
     */
    public void addMessage(ACLMessage sms, long date) {
        Conversation conv;
        int pos = position(sms);
        boolean value = true; // whether the message is correct or not

        if (sniff()) {
            if (pos == -1) {
                // any message should contain the fields ontology and language
                // any initial message should have filled the protocol field
                conv = new Conversation(sms.getConversationId(), sms.getProtocol(), sms.getOntology(), sms.getLanguage(), sms.getSender(), ACLMessage.getPerformative(sms.getPerformative()), date, this);
                addText("Conversation detected: " + sms.getConversationId());
                listConversations.add(conv);
                Protocol protoc = getProtocol(sms.getProtocol());
                if (protoc == null) {
                    value = false;
                    conv.setProtocol(ControlProtocol.UNKNOWN_PROTOCOL);
                    conv.setState(ERROR_STATE);
                } else
                    conv.setObjectProtocol(protoc);
            } else {
                conv = (Conversation) listConversations.get(pos);

                // just in case a conversation's alarm starts at the same instant
                // as a message of that conversation arrives
                if (conv.blocked()) {
                    addMessage(sms, date);
                }
                conv.setPerformEnd(ACLMessage.getPerformative(sms.getPerformative()));
            }

            addText("Message of conversation " + sms.getConversationId() + " sent by " + sms.getSender().getName());

            if (value) value = checkMessage(conv, sms);
            if (value) value = changeState(conv, sms);

            conv.addMessage(sms, value, date);
            review(conv, NORMAL);
        }
    }

    private boolean checkMessage(Conversation conv, ACLMessage sms) {
        if (!conv.getOntology().equals(sms.getOntology()))
            return false;
        else if (!conv.getLanguage().equals(sms.getLanguage()))
            return false;
        else if (sms.getProtocol() == null)
            return true;
        else if (!conv.getProtocol().equals(sms.getProtocol()))
            return false;
        else
            return true;
    }

    private boolean changeState(Conversation conv, ACLMessage sms) {
        // Changes the conversation's state
        // Returns true if the message is correct, false otherwise

        Protocol protocol = conv.getObjectProtocol();
        int perf = sms.getPerformative();
        int state = conv.getState();
        int nextState, newState;
        String rol1,rol2;

        if (state == 0) conv.updateState(sms.getAllReceiver());

        rol1 = conv.getRol(sms.getSender());
        rol2 = conv.getRol((AID) sms.getAllReceiver().next());

        if (protocol.getType().equals(ControlProtocol.SIMPLE)) {
            nextState = protocol.nextState(state, ACLMessage.getPerformative(perf), rol1, rol2);

            if (nextState == ControlProtocol.ERROR_STATE) {
                if (state == 0) conv.setState(ControlProtocol.ERROR_STATE);
                return false;
            } else if (nextState == ControlProtocol.OK_STATE) {
                conv.stopAlarm(sms.getSender());
                conv.setState(ControlProtocol.OK_STATE);
                return true;
            } else {
                if (sms.getReplyByDate() == null)
                    conv.setAlarm(-1);
                else
                    conv.setAlarm(sms.getReplyByDate().getTime());
                conv.setState(nextState);
                return true;
            }
        } else {
            // we first compute the state of the participant or participants
            if (rol1.equals(ControlProtocol.INITIATOR))
                newState = conv.getState(sms.getAllReceiver());
            else
                newState = conv.getState(sms.getSender());

            nextState = protocol.nextState(newState, ACLMessage.getPerformative(perf), rol1, rol2);

            if (nextState == ControlProtocol.ERROR_STATE) {
                if (state == 0) conv.setState(ControlProtocol.ERROR_STATE, sms.getAllReceiver());
                return false;
            } else if ((nextState == ControlProtocol.OK_STATE) && (rol1.equals(ControlProtocol.PARTICIPANT))) {
                conv.setState(ControlProtocol.OK_STATE, sms.getSender());
                conv.stopAlarm(sms.getSender());
                return true;
            } else if ((nextState == ControlProtocol.OK_STATE) && (rol1.equals(ControlProtocol.INITIATOR))) {
                conv.setState(ControlProtocol.OK_STATE, sms.getAllReceiver());
                conv.stopAlarm(sms.getAllReceiver());
                return true;
            } else if (rol1.equals(ControlProtocol.INITIATOR)) {
                conv.setState(nextState, sms.getAllReceiver());
                if (sms.getReplyByDate() == null)
                    conv.setAlarm(-1, sms.getAllReceiver());
                else
                    conv.setAlarm(sms.getReplyByDate().getTime(), sms.getAllReceiver());
                return true;
            } else {
                conv.setState(nextState, sms.getSender());
                if (sms.getReplyByDate() == null)
                    conv.setAlarm(-1, sms.getSender());
                else
                    conv.setAlarm(sms.getReplyByDate().getTime(), sms.getSender());
                return true;
            }
        }
    }

    private int position(ACLMessage sms) {
        int size = listConversations.size();
        int i;
        Conversation conv;

        for (i = 0; i < size; i++) {
            conv = (Conversation) listConversations.get(i);
            if (conv.getId().equals(sms.getConversationId())) break;
        }
        if (i == size) i = -1;
        return i;
    }

    /**
     * Checks if the conversation may be finished.
     * @param conv Conversation to be checked.
     * @param mode Indicates the ending mode of the conversation: normal or due to timeout.
     */
    public void review(Conversation conv, int mode) {
        if (conv.end()) {
            // to store in DB
            abd.introduce(conv, mode);
            if (mode == NORMAL)
                addText("Conversation " + conv.getId() + " finished correctly");
            else
                addText("Conversation " + conv.getId() + " finished for timeout");
            // to remove from the list of active conversations
            remove(conv);
        }
        conv.unblock();
    }

    private void remove(Conversation conv) {
        int size = listConversations.size();
        int i;
        Conversation aux;

        for (i = 0; i < size; i++) {
            aux = (Conversation) listConversations.get(i);
            if (conv.getId() == aux.getId()) {
                listConversations.remove(i);
                break;
            }
        }
    }

    private WindowMain startMainScreen() {
        WindowMain frame = new WindowMain(abd, this);

        // validate frames with preset sizes
        // pack frames with useful preferential size information. For example, of its design.
        frame.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        frame.setVisible(true);

        return frame;
    }


    private Protocol getProtocol(String name) {
        Protocol aux = null;
        int i;

        for (i = 0; i < listProtocols.size(); i++) {
            aux = (Protocol) listProtocols.get(i);
            if (aux.getName().equals(name)) break;
        }
        if (i < listProtocols.size())
            return aux;
        else
            return null;
    }

    /**
     * Adds a new protocol to the list of active protocols.
     * @param prot Protocol to be added.
     */
    public void addProtocol(Protocol prot) {
        addText("Protocol " + prot.getName() + " loaded");
        listProtocols.add(prot);
    }

    /**
     * Removes a protocol from the list of active protocols.
     * @param prot Protocol to be removed.
     * @return true if the protocol may be removed from the list, false if the protocol isn't in the list.
     */
    public boolean delProtocol(Protocol prot) {
        for (int i = 0; i < listProtocols.size(); i++)
            if (prot.equals(listProtocols.get(i))) {
                listProtocols.remove(i);
                addText("Protocol " + prot.getName() + " removed");
                return true;
            }

        return false;
    }

    /**
     * Returns the list of active protocols.
     * @return The set of Protocol objects which belong to the list of active protocols.
     */
    public Vector getListProt() {
        Vector vector = new Vector();
        for (int i = 0; i < listProtocols.size(); i++)
            vector.add(listProtocols.get(i));
        return vector;
    }

    /**
     * Returns a list of the names of the active protocols.
     * @return The set of names of the Protocol objects of the list of active protocols.
     */
    public LinkedList getNameProt() {
        LinkedList list = new LinkedList();
        Protocol prot;
        for (int i = 0; i < listProtocols.size(); i++) {
            prot = (Protocol) listProtocols.get(i);
            list.add(prot.getName());
        }
        return list;
    }

    /**
     * Tells to the main window to add a text to the log panel.
     * @param text Text to be added.
     */
    public synchronized void addText(final String text) {
        Runnable addSms = new Runnable() {
            public void run() {
                mainWindow.addText(text);
            }
        };
        SwingUtilities.invokeLater(addSms);
    }

    private synchronized boolean sniff() {
        return sniff;
    }

    /**
     * Indicates whether the received messages should be analyzed or to directly discard them.
     * @param value Indicates whether the received messages should be intercepted or not.
     */
    public synchronized void doSniff(boolean value) {
        sniff = value;
    }

    /**
     * Makes the debugging agent to end its execution.
     */
    public void stopAgent() {
        agent.doDelete();
    }

    /**
     * Indicates to the main window that the DB connection has been lost.
     */
    public void invalidSession() {
        if (mainWindow != null)
            mainWindow.invalidSession();
    }
}