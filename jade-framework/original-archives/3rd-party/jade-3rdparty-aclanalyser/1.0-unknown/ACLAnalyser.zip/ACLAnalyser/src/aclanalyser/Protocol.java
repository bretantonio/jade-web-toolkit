package aclanalyser;

import java.util.*;
import java.io.*;

import jade.domain.*;
import jade.lang.acl.*;

/**
 * Represents a communications protocol, following the philosophy of the FIPA
 * interaction protocols.
 */
public class Protocol implements Serializable {
    private String name;
    private String type;
    private Vector[] states;

    /**
     * Creates a new protocol providing its name and its type.
     * @param name Name of the protocol.
     * @param type Type of the protocol.
     */
    public Protocol(String name, String type) {
        this.name = name;
        this.type = type;
        states = new Vector[ControlProtocol.MAX_STATES];
    }

    /**
     * Adds a new cell to the protocol, providing all its fields.
     * @param perf Performative of the message.
     * @param rol1 Role of the message sender agent.
     * @param rol2 Role of the message receiver agent.
     * @param initState Agent's initial state.
     * @param finalState Agent's final state.
     */
    public void addElement(String perf, String rol1, String rol2, int initState, int finalState) {
        ProtocolCell cp = new ProtocolCell(initState, perf, rol1, rol2, finalState);

        if (states[initState] == null) states[initState] = new Vector();

        states[initState].add(cp);
    }

    /**
     * Gets a string representation of this protocol.
     * @return Name of the protocol.
     */
    public String toString() {
        return name;
    }

    /**
     * Compare two protocols by comparing their names.
     * @param obj Protocol to be compared.
     * @return Whether they are the same or not.
     */
    public boolean equals(Object obj) {
        Protocol prot = (Protocol) obj;
        return (name.equals(prot.getName()));
    }

    /**
     * Stores the protocol into a disk file.
     * @param file Name of the destination file.
     */
    public void saveProtocol(String file) {
        try {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
            fos.close();
        } catch (Exception e) {
            System.err.println("Unable to store protocol " + e);
        }
    }

    /**
     * Gets the protocol from a disk file.
     * @param name Name of the file.
     * @return Retrieved protocol.
     */
    public static Protocol loadProtocol(String name) {
        try {
            FileInputStream fis = new FileInputStream(name);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Protocol p = (Protocol) ois.readObject();
            return p;
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Unable to retrieve protocol " + e);
            return null;
        }
    }

    /**
     * Loads and returns the FIPA default protocols (which must be stored in
     * disk files).
     * @return List of protocols.
     */
    public static LinkedList loadDefaultProtocols() {
        LinkedList list = new LinkedList();
        Protocol request = Protocol.loadProtocol("protocol" + File.separator + "fipa-request.pro");
        list.add(request);
        Protocol subscribe = Protocol.loadProtocol("protocol" + File.separator + "fipa-subscribe.pro");
        list.add(subscribe);
        Protocol query = Protocol.loadProtocol("protocol" + File.separator + "fipa-query.pro");
        list.add(query);
        Protocol contract = Protocol.loadProtocol("protocol" + File.separator + "fipa-contract-net.pro");
        list.add(contract);
        Protocol iter = Protocol.loadProtocol("protocol" + File.separator + "fipa-iterated-contract-net.pro");
        list.add(iter);
        Protocol propose = Protocol.loadProtocol("protocol" + File.separator + "fipa-propose.pro");
        list.add(propose);
        Protocol broker = Protocol.loadProtocol("protocol" + File.separator + "fipa-brokering.pro");
        list.add(broker);
        Protocol requestWhen = Protocol.loadProtocol("protocol" + File.separator + "fipa-request-when.pro");
        list.add(requestWhen);
        Protocol auctionEnglish = Protocol.loadProtocol("protocol" + File.separator + "fipa-auction-english.pro");
        list.add(auctionEnglish);
        Protocol auctionDutch = Protocol.loadProtocol("protocol" + File.separator + "fipa-auction-dutch.pro");
        list.add(auctionDutch);
        Protocol recruit = Protocol.loadProtocol("protocol" + File.separator + "fipa-recruiting.pro");
        list.add(recruit);

        return list;
    }

    /**
     * Returns the type of the protocol.
     * @return Type of the protocol.
     */
    public String getType() {
        return type;
    }

    /**
     * Returns the name of the protocol.
     * @return Name of the protocol.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the final state reached, after receiving a particular message in a
     * particular initial state.
     * @param initialState Initial state.
     * @param per Performative of the message.
     * @param rol1 Role of the message's sender.
     * @param rol2 Role of the message's receiver.
     * @return Final state reached.
     */
    public int nextState(int initialState, String per, String rol1, String rol2) {
        Vector vector = states[initialState];
        ProtocolCell cp;
        int finalState = ControlProtocol.ERROR_STATE;

        for (int i = 0; i < vector.size(); i++) {
            cp = (ProtocolCell) vector.get(i);
            if (per.equals(cp.getPerform()) && match(rol1, cp.getRolSender()) && match(rol2, cp.getRolReceiver())) {
                finalState = cp.getState();
                break;
            }
        }

        return finalState;
    }

    private boolean match(String rol1, String rol2) {
        if (rol1.equals(rol2)) return true;
        if (rol2.equals(ControlProtocol.ANY_ROL)) return true;
        return false;
    }

    private class Enum implements Enumeration {
        private int state = 0;
        private int post_state = 0; // next cell to access

        public boolean hasMoreElements() {
            // check if there are more in the same vector
            if (states[state].size() > post_state) return true;

            // check if there are more used states
            for (int i = state + 1; i < ControlProtocol.MAX_STATES; i++)
                if ((states[i] != null) && (states[i].size() > 0)) return true;

            return false;
        }

        public Object nextElement() {
            if (states[state].size() > post_state) {
                return states[state].get(post_state++);
            } else {
                post_state = 0;
                for (int i = state + 1; i < ControlProtocol.MAX_STATES; i++) {
                    if ((states[i] != null) && (states[i].size() > 0)) {
                        state = i;
                        return states[state].get(post_state++);
                    }
                }
                return null;
            }
        }
    }

    /**
     * Gets an iterator to cover the cells of the protocol.
     * @return Iterator for the cell of the protocol.
     */
    public Enumeration getEnumeration() {
        return new Enum();
    }

    /**
     * Creates the default FIPA protocols and saves them into disk files.
     */
    public static void createDefaultProtocols() {
        Protocol request = new Protocol(FIPANames.InteractionProtocol.FIPA_REQUEST, ControlProtocol.SIMPLE);
        request.addElement(ACLMessage.getPerformative(ACLMessage.REQUEST), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        request.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        request.addElement(ACLMessage.getPerformative(ACLMessage.AGREE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, 1);
        request.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        request.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        request.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 2);
        request.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        request.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);

        request.saveProtocol("protocol" + File.separator + request.getName() + ".pro");

        Protocol query = new Protocol(FIPANames.InteractionProtocol.FIPA_QUERY, ControlProtocol.SIMPLE);
        query.addElement(ACLMessage.getPerformative(ACLMessage.QUERY_IF), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        query.addElement(ACLMessage.getPerformative(ACLMessage.QUERY_REF), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        query.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        query.addElement(ACLMessage.getPerformative(ACLMessage.AGREE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, 1);
        query.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        query.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        query.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 2);
        query.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        query.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);

        query.saveProtocol("protocol" + File.separator + query.getName() + ".pro");

        Protocol contract = new Protocol(FIPANames.InteractionProtocol.FIPA_CONTRACT_NET, ControlProtocol.MULTIPLE);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.CFP), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, ControlProtocol.POSSIBLE_OK_STATE);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, ControlProtocol.POSSIBLE_OK_STATE, ControlProtocol.OK_STATE);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.PROPOSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, ControlProtocol.POSSIBLE_OK_STATE, 1);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, ControlProtocol.POSSIBLE_OK_STATE, 3);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, ControlProtocol.OK_STATE);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 2);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 3);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 2, 3);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);
        contract.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);

        contract.saveProtocol("protocol" + File.separator + contract.getName() + ".pro");

        Protocol subscribe = new Protocol(FIPANames.InteractionProtocol.FIPA_SUBSCRIBE, ControlProtocol.SIMPLE);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.SUBSCRIBE), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.AGREE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, 2);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, 2);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, 2);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 3);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 2, 3);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);
        subscribe.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);

        subscribe.saveProtocol("protocol" + File.separator + subscribe.getName() + ".pro");

        Protocol requestWhen = new Protocol(FIPANames.InteractionProtocol.FIPA_REQUEST_WHEN, ControlProtocol.SIMPLE);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.REQUEST_WHEN), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.AGREE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, 2);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 3);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 2, 3);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);
        requestWhen.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);

        requestWhen.saveProtocol("protocol" + File.separator + requestWhen.getName() + ".pro");

        Protocol iterContract = new Protocol(FIPANames.InteractionProtocol.FIPA_ITERATED_CONTRACT_NET, ControlProtocol.MULTIPLE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.CFP), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, ControlProtocol.POSSIBLE_OK_STATE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, ControlProtocol.POSSIBLE_OK_STATE, ControlProtocol.OK_STATE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.PROPOSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, ControlProtocol.POSSIBLE_OK_STATE, 1);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, ControlProtocol.POSSIBLE_OK_STATE, 3);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, ControlProtocol.OK_STATE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.CFP), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, ControlProtocol.POSSIBLE_OK_STATE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 2);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 3);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 2, 3);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);
        iterContract.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);

        iterContract.saveProtocol("protocol" + File.separator + iterContract.getName() + ".pro");

        Protocol englishAuction = new Protocol(FIPANames.InteractionProtocol.FIPA_ENGLISH_AUCTION, ControlProtocol.MULTIPLE);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.CFP), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 2);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.NOT_UNDERSTOOD), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.PROPOSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, 3);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 3, ControlProtocol.OK_STATE);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 3, 4);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.CFP), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 4, 2);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 4, ControlProtocol.OK_STATE);
        englishAuction.addElement(ACLMessage.getPerformative(ACLMessage.REQUEST), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 4, ControlProtocol.OK_STATE);

        englishAuction.saveProtocol("protocol" + File.separator + englishAuction.getName() + ".pro");

        Protocol dutchAuction = new Protocol(FIPANames.InteractionProtocol.FIPA_DUTCH_AUCTION, ControlProtocol.MULTIPLE);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.CFP), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 2);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.NOT_UNDERSTOOD), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.PROPOSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, 3);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 3, ControlProtocol.OK_STATE);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 3, 4);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.CFP), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 4, 2);
        dutchAuction.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 4, ControlProtocol.OK_STATE);

        dutchAuction.saveProtocol("protocol" + File.separator + dutchAuction.getName() + ".pro");

        Protocol broker = new Protocol(FIPANames.InteractionProtocol.FIPA_BROKERING, ControlProtocol.SIMPLE);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.PROXY), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.AGREE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, 2);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 4);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, 3);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 2, 4);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 3, 3);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 3, 4);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 4, ControlProtocol.OK_STATE);
        broker.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 4, ControlProtocol.OK_STATE);

        broker.saveProtocol("protocol" + File.separator + broker.getName() + ".pro");

        Protocol propose = new Protocol(FIPANames.InteractionProtocol.FIPA_PROPOSE, ControlProtocol.SIMPLE);
        propose.addElement(ACLMessage.getPerformative(ACLMessage.PROPOSE), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        propose.addElement(ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        propose.addElement(ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        propose.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 2);
        propose.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        propose.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);

        propose.saveProtocol("protocol" + File.separator + propose.getName() + ".pro");

        Protocol recruit = new Protocol(FIPANames.InteractionProtocol.FIPA_RECRUITING, ControlProtocol.SIMPLE);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.PROXY), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 0, 1);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.REFUSE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, ControlProtocol.OK_STATE);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.AGREE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 1, 2);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 1, 5);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, ControlProtocol.OK_STATE);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 2, 3);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.ANY_ROL, 2, 4);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 2, 5);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.ANY_ROL, ControlProtocol.ANY_ROL, 4, ControlProtocol.OK_STATE);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 4, 5);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.ANY_ROL, ControlProtocol.INITIATOR, 3, ControlProtocol.OK_STATE);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.CANCEL), ControlProtocol.INITIATOR, ControlProtocol.PARTICIPANT, 3, 5);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.FAILURE), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 5, ControlProtocol.OK_STATE);
        recruit.addElement(ACLMessage.getPerformative(ACLMessage.INFORM), ControlProtocol.PARTICIPANT, ControlProtocol.INITIATOR, 5, ControlProtocol.OK_STATE);

        recruit.saveProtocol("protocol" + File.separator + recruit.getName() + ".pro");

        System.out.println("");
        System.out.println("Default protocols loaded!");
        System.out.println("");
    }
}