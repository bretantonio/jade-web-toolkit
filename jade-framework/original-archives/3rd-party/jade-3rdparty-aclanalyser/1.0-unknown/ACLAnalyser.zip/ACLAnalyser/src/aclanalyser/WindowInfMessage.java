package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class WindowInfMessage extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JLabel jLabel9 = new JLabel();
    private JLabel jLabel10 = new JLabel();
    private JLabel jLabel11 = new JLabel();
    private JLabel jLabel12 = new JLabel();
    private JLabel jLabel13 = new JLabel();
    private JLabel jLabel22 = new JLabel();
    private JLabel jLabel14 = new JLabel();
    private JLabel jLabel15 = new JLabel();
    private JLabel jLabel16 = new JLabel();
    private JLabel jLabel17 = new JLabel();
    private JLabel jLabel18 = new JLabel();
    private JLabel jLabel19 = new JLabel();
    private JLabel jLabel110 = new JLabel();
    private JLabel jLabel20 = new JLabel();
    private JLabel jLabel24 = new JLabel();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTextArea jTextArea1 = new JTextArea();
    private JLabel jLabel21 = new JLabel();
    private JScrollPane jScrollPane2 = new JScrollPane();
    private JList jList1 = new JList();

    // Build the frame
    public WindowInfMessage(LocatedMessage message) {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            fill(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "message.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Identification:");
        jLabel1.setBounds(new Rectangle(48, 40, 90, 15));
        contentPane.setLayout(null);
        this.setSize(new Dimension(626, 370));
        this.setTitle("Message information");
        jLabel2.setBounds(new Rectangle(48, 65, 90, 15));
        jLabel2.setText("Date:");
        jLabel4.setBounds(new Rectangle(48, 115, 90, 15));
        jLabel4.setText("Protocol:");
        jLabel5.setBounds(new Rectangle(48, 140, 90, 15));
        jLabel5.setText("Ontology:");
        jLabel6.setBounds(new Rectangle(48, 165, 90, 15));
        jLabel6.setText("Language:");
        jLabel22.setBounds(new Rectangle(48, 190, 90, 15));
        jLabel22.setText("Performative:");
        jLabel7.setBounds(new Rectangle(48, 215, 90, 15));
        jLabel7.setText("Encoding:");
        jLabel8.setBounds(new Rectangle(48, 240, 90, 15));
        jLabel8.setText("Size (bytes):");
        jLabel9.setBounds(new Rectangle(48, 265, 90, 15));
        jLabel9.setText("Right:");
        jLabel10.setBounds(new Rectangle(48, 290, 90, 15));
        jLabel10.setText("Late:");
        jLabel3.setBounds(new Rectangle(48, 90, 90, 15));
        jLabel3.setText("Sender:");
        jLabel11.setText("");
        jLabel11.setBounds(new Rectangle(133, 40, 253, 15));
        jLabel12.setBounds(new Rectangle(133, 65, 253, 15));
        jLabel12.setText("");
        jLabel13.setBounds(new Rectangle(133, 90, 253, 15));
        jLabel13.setText("");
        jLabel14.setBounds(new Rectangle(133, 115, 253, 15));
        jLabel14.setText("");
        jLabel15.setBounds(new Rectangle(133, 140, 253, 15));
        jLabel15.setText("");
        jLabel16.setBounds(new Rectangle(133, 165, 253, 15));
        jLabel16.setText("");
        jLabel17.setBounds(new Rectangle(133, 215, 253, 15));
        jLabel17.setText("");
        jLabel18.setBounds(new Rectangle(133, 240, 253, 15));
        jLabel18.setText("");
        jLabel19.setBounds(new Rectangle(133, 265, 253, 15));
        jLabel19.setText("");
        jLabel110.setBounds(new Rectangle(133, 290, 253, 15));
        jLabel110.setText("");
        jLabel24.setBounds(new Rectangle(133, 190, 254, 15));
        jLabel24.setText("");
        jLabel20.setText("Content:");
        jLabel20.setBounds(new Rectangle(406, 32, 131, 17));
        jScrollPane1.setBounds(new Rectangle(406, 56, 198, 112));
        jTextArea1.setBounds(new Rectangle(406, 56, 198, 112));
        jLabel21.setText("Receivers:");
        jLabel21.setBounds(new Rectangle(406, 187, 81, 19));
        jScrollPane2.setBounds(new Rectangle(406, 210, 198, 112));
        jList1.setBounds(new Rectangle(406, 210, 198, 112));
        contentPane.add(jLabel1, null);
        contentPane.add(jLabel2, null);
        contentPane.add(jLabel9, null);
        contentPane.add(jLabel8, null);
        contentPane.add(jLabel7, null);
        contentPane.add(jLabel6, null);
        contentPane.add(jLabel5, null);
        contentPane.add(jLabel4, null);
        contentPane.add(jLabel3, null);
        contentPane.add(jLabel22, null);
        contentPane.add(jLabel10, null);
        contentPane.add(jLabel11, null);
        contentPane.add(jLabel12, null);
        contentPane.add(jLabel13, null);
        contentPane.add(jLabel14, null);
        contentPane.add(jLabel15, null);
        contentPane.add(jLabel16, null);
        contentPane.add(jLabel17, null);
        contentPane.add(jLabel18, null);
        contentPane.add(jLabel19, null);
        contentPane.add(jLabel110, null);
        contentPane.add(jLabel20, null);
        contentPane.add(jLabel24, null);
        contentPane.add(jScrollPane1, null);
        contentPane.add(jList1, null);
        contentPane.add(jLabel21, null);
        contentPane.add(jScrollPane2, null);
        contentPane.add(jTextArea1, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private void fill(LocatedMessage message) {
        jLabel11.setText(message.getId());
        jLabel12.setText("" + message.getDate());
        jLabel13.setText(message.getSender());
        jLabel14.setText(message.getProtocol());
        jLabel15.setText(message.getOntology());
        jLabel16.setText(message.getLanguage());
        jLabel17.setText(message.getEncoding());
        jLabel24.setText(message.getPerformative());
        jLabel18.setText("" + message.getSize());
        if (message.getValid().equals("T"))
            jLabel19.setText("YES");
        else
            jLabel19.setText("NO");
        if (message.getLate().equals("T"))
            jLabel110.setText("YES");
        else
            jLabel110.setText("NO");

        String cont = message.getContent();
        if (cont.equals("null")) cont = "";
        jTextArea1.append(cont);
        jTextArea1.setEditable(false);
        jScrollPane1.getViewport().setView(jTextArea1);

        jList1.setListData(message.getReceivers());
        jScrollPane2.getViewport().setView(jList1);
    }

    public void end() {
        setVisible(false);
        dispose();
    }

}