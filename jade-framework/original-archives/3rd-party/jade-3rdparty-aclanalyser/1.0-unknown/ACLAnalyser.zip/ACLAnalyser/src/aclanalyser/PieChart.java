package aclanalyser;

import java.awt.Color;
import java.util.LinkedList;
import java.awt.event.*;
import java.awt.*;
import java.io.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieItemLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.DefaultPieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChart extends ApplicationFrame implements Termination {

    private ConversationStats ec = null;
    private MessageStats em = null;
    private LinkedList list = null;

    public PieChart(String title, Object obj, LinkedList names, String session) {
        super(title + " - Session: " + session);
        if (obj instanceof ConversationStats) {
            ec = (ConversationStats) obj;
            list = names;
        } else
            em = (MessageStats) obj;

        DefaultPieDataset data = new DefaultPieDataset();
        fill(data);
        JFreeChart chart = ChartFactory.createPieChart(title, // title
                data, // data
                true, // include legend
                true,
                false
        );

        chart.setBackgroundPaint(Color.lightGray);
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelGenerator(new StandardPieItemLabelGenerator("{0} = {1} ({2})")); // old PiePlot.NAME_AND_PERCENT_LABELS
        plot.setNoDataMessage("No data available");

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        setContentPane(chartPanel);

        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cheese.gif"));
    }

    protected void processWindowEvent(WindowEvent e) {
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private void fill(DefaultPieDataset data) {
        if (ec != null) {
            // It's a conversation's graph
            String prot;
            int aux;
            int adding = 0;
            for (int i = 0; i < list.size(); i++) {
                prot = (String) list.get(i);
                aux = ec.getNumProtocol(prot);
                adding = adding + aux;
                data.setValue(prot, new Double(aux));
            }
            data.setValue("Other", new Double(ec.getNumConv() - adding));
        } else {
            // It's a message's graph
            data.setValue("Petition", new Double(em.getProposal()));
            data.setValue("Reject Petition", new Double(em.getRejectProposal()));
            data.setValue("Accept Petition", new Double(em.getAcceptProposal()));
            data.setValue("Information", new Double(em.getInformation()));
            data.setValue("Error", new Double(em.getError()));
            data.setValue("Sending Message", new Double(em.getPropagateMessages()));
        }
    }

    static public PieChart execute(String text, Object obj, LinkedList names, String session) {

        PieChart demo = new PieChart(text, obj, names, session);
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);

        return demo;
    }

    public void end() {
        setVisible(false);
        dispose();
    }

}