package aclanalyser;

public class Session {
    private int number;
    private String name;
    private String date;

    public Session(int num, String name, String date) {
        number = num;
        this.name = name;
        this.date = date;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }
}