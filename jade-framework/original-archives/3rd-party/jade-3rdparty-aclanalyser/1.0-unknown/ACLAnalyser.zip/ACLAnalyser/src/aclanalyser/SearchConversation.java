package aclanalyser;

import java.util.*;

public class SearchConversation {

    private String identifier = null;
    private long minStartDate = -1;
    private long maxStartDate = -1;
    private long minEndDate = -1;
    private long maxEndDate = -1;
    private Vector initiator = null;
    private Vector ontology = null;
    private Vector language = null;
    private LinkedList protocol = null;
    private LinkedList performativeStart = null;
    private LinkedList performativeEnd = null;
    private String result = "ANY";

    public String getIdentifier() {
        return identifier;
    }

    public String getResult() {
        return result;
    }

    public Vector getInitiator() {
        return initiator;
    }

    public Vector getOntology() {
        return ontology;
    }

    public Vector getLanguage() {
        return language;
    }

    public LinkedList getProtocol() {
        return protocol;
    }

    public LinkedList getPerformStart() {
        return performativeStart;
    }

    public LinkedList getPerformEnd() {
        return performativeEnd;
    }

    public long getMinStartDate() {
        return minStartDate;
    }

    public long getMaxStartDate() {
        return maxStartDate;
    }

    public long getMinEndDate() {
        return minEndDate;
    }

    public long getMaxEndDate() {
        return maxEndDate;
    }

    public void setIdentifier(String aux) {
        identifier = aux;
    }

    public void setResult(String res) {
        result = res;
    }

    public void setProtocol(LinkedList list) {
        protocol = (LinkedList) list.clone();
    }

    public void setPerformStart(LinkedList list) {
        performativeStart = (LinkedList) list.clone();
    }

    public void setPerformEnd(LinkedList list) {
        performativeEnd = (LinkedList) list.clone();
    }

    public void setInitiator(Vector vec) {
        initiator = (Vector) vec.clone();
    }

    public void setOntology(Vector vec) {
        ontology = (Vector) vec.clone();
    }

    public void setLanguage(Vector vec) {
        language = (Vector) vec.clone();
    }

    public void setMinStartDate(long date) {
        minStartDate = date;
    }

    public void setMaxStartDate(long date) {
        maxStartDate = date;
    }

    public void setMinEndDate(long date) {
        minEndDate = date;
    }

    public void setMaxEndDate(long date) {
        maxEndDate = date;
    }

    public void print() {
        // Initiators
        System.out.println("Initiators: " + initiator);
        // Languages
        System.out.println("Languages: " + language);
        // Ontologies
        System.out.println("Ontologies " + ontology);
        // Dates
        System.out.println("Dates:");
        if (minStartDate != -1) {
            System.out.println("Minimum start date: " + minStartDate);
        }
        if (maxStartDate != -1) {
            System.out.println("Maximum start date: " + maxStartDate);
        }
        if (minEndDate != -1) {
            System.out.println("Minimum end date: " + minEndDate);
        }
        if (maxEndDate != -1) {
            System.out.println("Maximum end date: " + maxEndDate);
        }
        // Protocols
        if (protocol != null) {
            System.out.println("Protocols: ");
            for (int i = 0; i < protocol.size(); i++) {
                System.out.print(protocol.get(i) + ",");
            }
            System.out.println();
        }
        // Performative start
        System.out.println("Perf. start:");
        if (performativeStart != null) {
            for (int i = 0; i < performativeStart.size(); i++) {
                System.out.print(performativeStart.get(i) + ",");
            }
            System.out.println();
        }
        // Performative end
        System.out.println("Perf. end:");
        if (performativeEnd != null) {
            for (int i = 0; i < performativeEnd.size(); i++) {
                System.out.print(performativeEnd.get(i) + ",");
            }
            System.out.println();
        }
        // Result
        System.out.println("Result: " + result);
    }
}