package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import javax.swing.table.*;
import java.io.*;

public class WindowLoadSession extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JScrollPane scroll = new JScrollPane();
    private JTable jTable1;
    private DefaultTableModel model;
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();

    private Vector sessions;
    private DBAccess abd;
    private WindowMain window;

    // Build the frame
    public WindowLoadSession(DBAccess access, WindowMain win) {
        abd = access;
        window = win;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            fill();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cyclops.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Sessions:");
        jLabel1.setBounds(new Rectangle(31, 24, 74, 17));
        contentPane.setLayout(null);
        this.setSize(new Dimension(413, 370));
        this.setTitle("Load Session");
        jButton1.setBounds(new Rectangle(120, 294, 78, 27));
        jButton1.setText("Load");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(225, 294, 78, 27));

        Vector vector = new Vector();

        vector.add("Number");
        vector.add("Name");
        vector.add("Date");
        model = new DefaultTableModel(vector, 0);
        jTable1 = new JTable(model);

        jTable1.setBounds(new Rectangle(37, 57, 336, 220));
        jTable1.setSelectionMode(0);  // we allow only 1-row selection

        JTableHeader anHeader = jTable1.getTableHeader();
        anHeader.setReorderingAllowed(false);

        scroll = new JScrollPane(jTable1);
        scroll.setBounds(new Rectangle(37, 57, 336, 220));

        contentPane.add(jLabel1, null);
        contentPane.add(scroll, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            abd.createNewSession();
            window.update();
            end();
        }
    }

    private void fill() {
        sessions = abd.getSessions();
        Session session;

        for (int i = 0; i < sessions.size(); i++) {
            session = (Session) sessions.get(i);
            Object[] data = {new Integer(session.getNumber()), session.getName(), session.getDate()};
            model.addRow(data);
        }
    }

    void jButton1_actionPerformed(ActionEvent e) {
        int i = jTable1.getSelectedRow();
        Integer newSession = (Integer) model.getValueAt(i, 0);
        abd.loadSession(newSession.intValue());
        window.update();
        end();
    }

    void jButton2_actionPerformed(ActionEvent e) {
        abd.createNewSession();
        window.update();
        end();
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}