package aclanalyser;

import java.util.*;

import jade.core.*;
import jade.core.behaviours.*;
import jade.domain.JADEAgentManagement.*;
import jade.domain.introspection.*;
import jade.domain.FIPAAgentManagement.Envelope;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.lang.acl.ACLCodec;
import jade.lang.acl.StringACLCodec;
import jade.content.onto.basic.Action;
import jade.proto.SimpleAchieveREInitiator;
import jade.tools.ToolAgent;

/**
 * The Debugger is an agent with the purpose of intercept the communications made
 * inside JADE in order to be able to debug them; it's the communication between JADE
 * and the tool.
 */
public class Debugger extends ToolAgent {

    private ControlProtocol cp;
    private LinkedList agents;
    static final String ADD = "add";
    static final String GET = "get";

    /**
     * Creates an instance of the Debugger agent.
     */
    public Debugger() {
        super();
        agents = new LinkedList();
        cp = new ControlProtocol(this);
    }

    private class SniffListenerBehaviour extends CyclicBehaviour {

        private MessageTemplate listenSniffTemplate;

        SniffListenerBehaviour() {
            listenSniffTemplate = MessageTemplate.MatchConversationId(getName() + "-event");
        }

        public void action() {
            ACLMessage current = receive(listenSniffTemplate);
            if (current != null) {
                try {
                    Occurred o = (Occurred) getContentManager().extractContent(current);
                    EventRecord er = o.getWhat();
                    Event ev = er.getWhat();
                    String content;
                    Envelope env;
                    if (ev instanceof SentMessage) {
                        content = ((SentMessage) ev).getMessage().getPayload();
                        env = ((SentMessage) ev).getMessage().getEnvelope();
                    } else
                        return;

                    ACLCodec codec = new StringACLCodec();
                    ACLMessage tmp = codec.decode(content.getBytes());
                    tmp.setEnvelope(env);

                    // here is the message
                    if (er.getWhen() == null)
                        cp.addMessage(tmp, -1);
                    else
                        cp.addMessage(tmp, er.getWhen().getTime());
                } catch (Throwable e) {
                    System.err.println("Serious problem occurred in the Debugger!");
                    e.printStackTrace();
                }
            } else
                block();
        }
    }

    private SequentialBehaviour AMSSubscribe = new SequentialBehaviour();

    class SnifferAMSListenerBehaviour extends AMSListenerBehaviour {

        protected void installHandlers(Map handlersTable) {

            handlersTable.put(IntrospectionVocabulary.BORNAGENT, new EventHandler() {
                public void handle(Event ev) {
                    BornAgent ba = (BornAgent) ev;
                    AID agent = ba.getAgent();
                    if (!agent.equals(getAID()))
                        modifyAgents(agent, ADD);
                }
            });

        }
    }

    private class AgentSniffBehaviour extends WakerBehaviour {

        public AgentSniffBehaviour(jade.core.Agent a, long time) {
            super(a, time);
        }

        public void handleElapsedTimeout() {
            LinkedList news = modifyAgents(null, GET);
            if ((news != null) && (news.size() > 0)) {
                SniffOn so = new SniffOn();
                so.setSniffer(getAID());
                AID ag;
                for (int i = 0; i < news.size(); i++) {
                    ag = (AID) news.get(i);
                    if (check(ag)) {
                        cp.addText("Agent " + ag.getName() + " detected");
                        // do sniff to this agent
                        so.addSniffedAgents(ag);
                    }
                }
                java.util.Iterator it = so.getAllSniffedAgents();
                if (it.hasNext()) {
                    ACLMessage requestMsg = null;
                    try {
                        Action a = new Action();
                        a.setActor(getAMS());
                        a.setAction(so);

                        requestMsg = getRequest();
                        requestMsg.setOntology(JADEManagementOntology.NAME);
                        getContentManager().fillContent(requestMsg, a);
                    } catch (Exception fe) {
                        fe.printStackTrace();
                    }

                    addBehaviour(new SimpleAchieveREInitiator(Debugger.this, requestMsg));
                }
            }
            reset(500);
        }
    }


    /**
     * This method is invoked when the agent is introduces in the platform,
     * and it's in charge of start running the behaviours of the agent.
     */
    public void toolSetup() {

        // Send 'subscribe' messages to the AMS
        AMSSubscribe.addSubBehaviour(new SenderBehaviour(this, getSubscribe()));

        // Manage the incoming 'inform' messages
        AMSSubscribe.addSubBehaviour(new SnifferAMSListenerBehaviour());

        addBehaviour(AMSSubscribe);
        addBehaviour(new SniffListenerBehaviour());
        addBehaviour(new AgentSniffBehaviour(this, 500));
    }

    private boolean check(AID a) {
        String name = a.getLocalName();

        if (name.equalsIgnoreCase("rma") || name.equalsIgnoreCase("df") || name.equalsIgnoreCase("ams"))
            return false;
        else if (name.length() > getLocalName().length() + 4) {
            if (name.substring(0, getLocalName().length() + 4).equalsIgnoreCase(getLocalName() + "-on-"))
                return false;
            else
                return true;
        } else
            return true;
    }

    private synchronized LinkedList modifyAgents(AID agent, String modo) {
        if (modo.equals(ADD)) {
            agents.add(agent);
            return null;
        } else {
            LinkedList copy = (LinkedList) agents.clone();
            while (agents.size() > 0) agents.removeFirst();
            return copy;
        }
    }

}