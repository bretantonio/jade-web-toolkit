package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedList;
import java.io.*;

public class WindowInfGroup extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JList jList1 = new JList();
    private JLabel jLabel9 = new JLabel();
    private JScrollPane jScrollPane1 = new JScrollPane();

    private DBAccess abd;
    private LinkedList agents;
    private String name;

    // Build the frame
    public WindowInfGroup(String name, LinkedList list, DBAccess access) {
        abd = access;
        this.name = name;
        agents = (LinkedList) list.clone();
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            fill();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "graph.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Name:");
        jLabel1.setBounds(new Rectangle(62, 34, 64, 17));
        contentPane.setLayout(null);
        this.setSize(new Dimension(400, 400));
        this.setTitle("Information of group " + name);
        jLabel2.setBounds(new Rectangle(62, 64, 64, 17));
        jLabel2.setText("N# agents:");
        jLabel3.setBounds(new Rectangle(62, 94, 177, 17));
        jLabel3.setText("N# messages (group inside):");
        jLabel4.setText("Size messages (group inside):");
        jLabel4.setBounds(new Rectangle(62, 124, 177, 17));
        jLabel5.setText("");
        jLabel5.setBounds(new Rectangle(256, 34, 89, 17));
        jLabel6.setBounds(new Rectangle(256, 64, 89, 17));
        jLabel6.setText("");
        jLabel7.setBounds(new Rectangle(256, 94, 89, 17));
        jLabel7.setText("");
        jLabel8.setBounds(new Rectangle(256, 124, 89, 17));
        jLabel8.setText("");
        jList1.setBounds(new Rectangle(76, 204, 260, 155));
        jLabel9.setText("Agents:");
        jLabel9.setBounds(new Rectangle(76, 176, 92, 20));
        jScrollPane1.setBounds(new Rectangle(76, 204, 260, 155));
        contentPane.add(jLabel1, null);
        contentPane.add(jLabel2, null);
        contentPane.add(jLabel3, null);
        contentPane.add(jLabel4, null);
        contentPane.add(jLabel5, null);
        contentPane.add(jLabel6, null);
        contentPane.add(jLabel7, null);
        contentPane.add(jLabel8, null);
        contentPane.add(jList1, null);
        contentPane.add(jLabel9, null);
        contentPane.add(jScrollPane1, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private void fill() {
        jLabel5.setText(name);
        jLabel6.setText("" + agents.size());

        jLabel7.setText("" + abd.getMessagesInsideGroup(agents));
        jLabel8.setText("" + abd.getSizeInsideGroup(agents));

        jList1.setListData(agents.toArray());
        jScrollPane1.getViewport().setView(jList1);
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}