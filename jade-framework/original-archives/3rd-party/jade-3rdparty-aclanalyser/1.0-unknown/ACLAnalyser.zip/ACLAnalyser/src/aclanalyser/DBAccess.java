package aclanalyser;

import java.sql.*;
import java.util.*;

import jade.lang.acl.*;
import jade.core.*;
import jade.domain.*;
import jade.domain.FIPAAgentManagement.*;

/**
 * This is the only class which communicates with the data base, so
 * it's the only one which receives all the requests for retrieving any information
 * from the DB and for storing it.
 */
public class DBAccess {

    private Statement stmt;
    private int id = 0;
    private int session = -1;
    private boolean connected;
    private ControlProtocol cp;

    /**
     * Builds a new instance of DBAccess
     * @param control The associated ControlProtocol object
     */
    public DBAccess(ControlProtocol control) {
        cp = control;
        connected = false;
        try {
            Class.forName(System.getProperty("db_driver"));
        } catch (Exception e) {
            System.err.println("Unable to load the data base driver!");
            cp.stopAgent();
        }
    }

    /**
     * Connects to the data base, starting a new session.
     */
    public synchronized void connect() {
        String user = getUser();
        String passwd = getPasswd();

        try {
            Connection connection = DriverManager.getConnection(System.getProperty("db_connection"), user, passwd);
            stmt = connection.createStatement();
        } catch (Exception e) {
            System.err.println("Unable to connect to the data base");
            e.printStackTrace();
            connected = false;
            cp.invalidSession();
            session = -1;
            return;
        }
        connected = true;
        createNewSession();
    }

    /**
     * Tells whether the connection to the data base is successful or not.
     * @return Whether the connection is set or not.
     */
    public boolean isConnected() {
        return connected;
    }

    private String getUser() {
        return System.getProperty("db_user");
    }

    private String getPasswd() {
        return System.getProperty("db_password");
    }

    /**
     * Changes the active session, from the current active session to a new one.
     */
    public synchronized void createNewSession() {
        if (connected) {
            int id = newIdSession();

            long curDate = System.currentTimeMillis();

            String query = "INSERT INTO Sessions VALUES('" + id + "','UNKNOWN" + id + "','" + curDate + "')";
            try {
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to create a new session: " + e);
            }

            session = id;
        }
    }

    /**
     * Removes from the data base all the information related to the active session.
     */
    public synchronized void removeSession() {
        if (connected) {

            String query;

            // remove receivers
            query = "DELETE FROM Receivers WHERE IdSession='" + session + "'";
            try {
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to remove receivers: " + e);
            }

            // remove messages
            query = "DELETE FROM Messages WHERE IdSession='" + session + "'";
            try {
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to remove messages: " + e);
            }

            // remove conversations
            query = "DELETE FROM Conversations WHERE IdSession='" + session + "'";
            try {
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to remove conversations: " + e);
            }

            // remove the session
            query = "DELETE FROM Sessions WHERE Identifier='" + session + "'";
            try {
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to remove session: " + e);
            }
        }

    }

    /**
     * Updates the name of the active session.
     * @param name Name of the session.
     */
    public synchronized void updateSessionName(String name) {
        if (connected) {
            String query = "UPDATE Sessions SET Name='" + name + "' WHERE Identifier='" + session + "'";
            try {
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to update session name: " + e);
            }
        }
    }

    /**
     * Returns the name of the active session.
     * @return Name of the session.
     */
    public synchronized String getSessionName() {
        if (connected) {
            String query,aux = null;

            try {
                query = "SELECT Name FROM Sessions WHERE Identifier='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getString(1);
                rs.close();
            } catch (Exception ex) {
                System.err.println("Error getting session name " + ex);
                return null;
            }
            return aux;
        }
        return "INVALID SESSION";
    }

    private synchronized int newIdSession() {
        if (connected) {
            String query;
            int aux;
            Vector used = new Vector();

            try {
                query = "SELECT Identifier FROM Sessions";
                ResultSet rs = stmt.executeQuery(query);
                while (rs.next()) {
                    aux = rs.getInt("Identifier");
                    used.add(new Integer(aux));
                }
                rs.close();
            } catch (Exception ex) {
                System.err.println("Error getting session identifier " + ex);
                return -1;
            }

            for (int i = 0; i < Integer.MAX_VALUE; i++) {
                if (!used.contains(new Integer(i))) return i;
            }
            return -1;
        }
        return -1;
    }

    /**
     * Inserts a new conversation in the data base.
     * @param conv Conversation to be inserted.
     * @param mode Reason for conversation's end: normal or timeout.
     */
    public synchronized void introduce(Conversation conv, int mode) {
        if (connected) {
            char state;

            // if the conversation was already inserted it's because the message
            // arrived late; the conversation was already ended
            if (present(conv))
                introduceMessages(conv, true);
            else {
                if (conv.getState() == ControlProtocol.OK_STATE)
                    state = 'T';
                else
                    state = 'F';

                try {
                    long date = conv.getDate();

                    // the final date will be the one from the last received message
                    // (if it ended ok), or the current one (if timeout)
                    //java.util.Date date2;
                    long date2;
                    if (mode == ControlProtocol.TIMEOUT)
                        date2 = System.currentTimeMillis();
                    else
                        date2 = conv.maxDate();

                    String query = "INSERT INTO Conversations VALUES('" + session + "','" + conv.getId() + "','" + conv.getOntology() + "','" + conv.getLanguage() + "','" + conv.getProtocol() + "','" + conv.getInitiator().getName() + "','" + date + "','" + date2 + "','" + conv.getPerformStart() + "','" + conv.getPerformEnd() + "','" + state + "')";
                    stmt.executeUpdate(query);
                } catch (SQLException e) {
                    System.err.println("Unable to insert conversation " + e);
                }
                introduceMessages(conv, false);
            }
        }
    }

    private void introduceMessages(Conversation conv, boolean isLate) {
        MessageCell mc;
        char state;
        char late;
        long size;

        if (isLate)
            late = 'T';
        else
            late = 'F';

        while ((mc = conv.getMessageCell()) != null) {
            if (mc.getValue())
                state = 'T';
            else
                state = 'F';

            // if it arrived late is erroneous
            if (isLate) state = 'F';

            ACLMessage sms = mc.getMessage();
            long date = mc.getDate();
            size = computeSize(sms);

            String query = "INSERT INTO Messages VALUES('" + session + "','" + id + "','" + conv.getId() + "','" + date + "','" + state + "','" + ACLMessage.getPerformative(sms.getPerformative()) + "','" + sms.getEncoding() + "','" + sms.getSender().getName() + "','" + sms.getContent() + "','" + sms.getOntology() + "','" + sms.getLanguage() + "','" + sms.getProtocol() + "'," + size + ",'" + late + "')";

            try {
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to insert message " + e);
            }
            introduceReceivers(sms, date);
            id = (id + 1) % ControlProtocol.MAX_MES_SEC;
        }
    }

    private long computeSize(ACLMessage sms) {
        ACLCodec codec;
        String coder = null;
        String aux = FIPANames.ACLCodec.STRING;
        Envelope enve = sms.getEnvelope();
        if (enve != null)
            aux = enve.getAclRepresentation();

        if (aux.equalsIgnoreCase(FIPANames.ACLCodec.STRING))
            coder = "jade.lang.acl.StringACLCodec";
        else if (aux.equalsIgnoreCase(FIPANames.ACLCodec.BITEFFICIENT))
            coder = "sonera.fipa.acl.BitEffACLCodec";
        else if (aux.equals(FIPANames.ACLCodec.XML))
            coder = "jade.content.lang.xml.XMLCodec";

        if (coder == null) coder = "jade.lang.acl.StringACLCodec";

        try {
            codec = (ACLCodec) Class.forName(coder).newInstance();
            byte[] bytes = codec.encode(sms);
            return bytes.length;
        } catch (Exception e) {
            return new jade.lang.acl.StringACLCodec().encode(sms).length;
        }
    }

    private void introduceReceivers(ACLMessage sms, /*String*/ long date) {
        java.util.Iterator it = sms.getAllReceiver();
        AID agent;

        while (it.hasNext()) {
            agent = (AID) it.next();
            try {
                String query = "INSERT INTO Receivers VALUES('" + session + "','" + id + "','" + sms.getConversationId() + "','" + date + "','" + agent.getName() + "')";
                stmt.executeUpdate(query);
            } catch (SQLException e) {
                System.err.println("Unable to insert receiver " + e);
            }
        }
    }

    private boolean present(Conversation conv) {
        boolean exit = false;

        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Conversations WHERE (Identifier='" + conv.getId() + "') AND (IdSession='" + session + "')");
            while (rs.next())
                exit = true;
            rs.close();
            return exit;
        } catch (SQLException e) {
            System.err.println("Error checking conversation duplicity.");
            return false;
        }
    }

    /**
     * Search the desired conversations in the current session.
     * @param sc Contains the criteria that must match the searched conversations.
     * @return List of found conversations.
     */
    public synchronized Vector searchConversation(SearchConversation sc) {
        if (connected) {
            String query = "";
            Vector aux;
            String auxil;

            // Identifier
            if ((auxil = sc.getIdentifier()) != null) {
                query = "(Identifier='" + auxil + "')";
            }
            // Initiators
            if ((aux = sc.getInitiator()) != null) {
                if (!query.equals("")) query = query + " AND ";
                query = "(Initiator='" + aux.get(0) + "'";
                for (int i = 1; i < aux.size(); i++) {
                    query = query + " OR Initiator='" + aux.get(i) + "'";
                }
                query = query + ")";
            }
            // Ontologies
            if ((aux = sc.getOntology()) != null) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(Ontology='" + aux.get(0) + "'";
                for (int i = 1; i < aux.size(); i++) {
                    query = query + " OR Ontology='" + aux.get(i) + "'";
                }
                query = query + ")";
            }
            // Languages
            if ((aux = sc.getLanguage()) != null) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(Language='" + aux.get(0) + "'";
                for (int i = 1; i < aux.size(); i++) {
                    query = query + " OR Language='" + aux.get(i) + "'";
                }
                query = query + ")";
            }

            java.util.LinkedList aux2;
            // Protocols
            if ((aux2 = sc.getProtocol()) != null) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(Protocol='" + aux2.get(0) + "'";
                for (int i = 1; i < aux2.size(); i++) {
                    query = query + " OR Protocol='" + aux2.get(i) + "'";
                }
                query = query + ")";
            }

            // Performative start
            if ((aux2 = sc.getPerformStart()) != null) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(PerformStart='" + aux2.get(0) + "'";
                for (int i = 1; i < aux2.size(); i++) {
                    query = query + " OR PerformStart='" + aux2.get(i) + "'";
                }
                query = query + ")";
            }

            // Performative end
            if ((aux2 = sc.getPerformEnd()) != null) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(PerformEnd='" + aux2.get(0) + "'";
                for (int i = 1; i < aux2.size(); i++) {
                    query = query + " OR PerformEnd='" + aux2.get(i) + "'";
                }
                query = query + ")";
            }

            // Dates
            long aux3;
            if ((aux3 = sc.getMinStartDate()) != -1) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(StartDate>'" + aux3 + "')";
            }
            if ((aux3 = sc.getMaxStartDate()) != -1) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(StartDate<'" + aux3 + "')";
            }
            if ((aux3 = sc.getMinEndDate()) != -1) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(EndDate>'" + aux3 + "')";
            }
            if ((aux3 = sc.getMaxEndDate()) != -1) {

                if (!query.equals("")) query = query + " AND ";
                query = query + "(EndDate<'" + aux3 + "')";
            }

            // Result
            if (sc.getResult().equals("Complete")) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(State='T')";
            } else if (sc.getResult().equals("Incomplete")) {
                if (!query.equals("")) query = query + " AND ";
                query = query + "(State='F')";
            }

            if (!query.equals(""))
                query = query + " AND (IdSession='" + session + "')";
            else
                query = "(IdSession='" + session + "')";

            query = "WHERE " + query;

            Vector result = new Vector();
            try {
                query = "SELECT StartDate,EndDate,Identifier,Protocol,Ontology,Language,Initiator,State,PerformStart,PerformEnd FROM Conversations " + query;

                ResultSet rs = stmt.executeQuery(query);

                LocatedConversation conv;
                String id,pro,onto,lang,ini,st,perfStart,perfEnd,date1,date2;
                long startDate,endDate;

                while (rs.next()) {
                    id = rs.getString("Identifier");
                    pro = rs.getString("Protocol");
                    onto = rs.getString("Ontology");
                    lang = rs.getString("Language");
                    ini = rs.getString("Initiator");
                    st = rs.getString("State");
                    date1 = rs.getString(1);
                    date2 = rs.getString(2);
                    startDate = new Long(date1).longValue();
                    endDate = new Long(date2).longValue();

                    perfStart = rs.getString("PerformStart");
                    perfEnd = rs.getString("PerformEnd");

                    conv = new LocatedConversation(id, ini, pro, onto, lang, startDate, endDate, perfStart, perfEnd, st);

                    result.add(conv);
                }
                rs.close();
                return result;
            } catch (Exception ex) {
                return result;
            }
        }
        return null;
    }

    /**
     * Returns the statistics of the conversations of the current session.
     * @param protocols List of active protocols.
     * @return Statistics of the conversations.
     */
    public synchronized ConversationStats getConversationStats(java.util.LinkedList protocols) {
        if (connected) {
            ConversationStats cs = new ConversationStats();
            String query;
            int totNum = 0;
            int aux;

            // Total number of conversations
            try {
                query = "SELECT COUNT(*) FROM Conversations WHERE IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                totNum = rs.getInt(1);
                rs.close();
                cs.setNumConv(totNum);
            } catch (Exception ex) {
                System.err.println("Error getting total number of conversations " + ex);
            }

            // Number of complete and incomplete conversations
            try {
                query = "SELECT COUNT(*) FROM Conversations WHERE State='T' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                cs.setNumCompleteConv(aux);
                cs.setNumIncompleteConv(totNum - aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of complete conversations");
            }

            // Protocols
            String prot;
            for (int i = 0; i < protocols.size(); i++) {
                prot = (String) protocols.get(i);
                try {
                    query = "SELECT COUNT(*) FROM Conversations WHERE Protocol='" + prot + "' AND IdSession='" + session + "'";
                    ResultSet rs = stmt.executeQuery(query);
                    rs.next();
                    aux = rs.getInt(1);
                    rs.close();
                    cs.setNumProtocol(aux, prot);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    System.err.println("Error getting number of conversations of protocol " + prot);
                }
            }

            return cs;
        }
        return null;
    }

    /**
     * Returns the statistics of the messages of the current session.
     * @return Statistics of the messages.
     */
    public synchronized MessageStats getMessageStats() {
        if (connected) {
            MessageStats ms = new MessageStats();
            String query;
            int totNum = 0;
            int aux;

            // Total number of messages
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                totNum = rs.getInt(1);
                rs.close();
                ms.setNumMessages(totNum);
            } catch (Exception ex) {
                System.err.println("Error getting total number of messages " + ex);
            }

            // Number of correct and incorrect messages
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE Valid='T' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setNumOKMessages(aux);
                ms.setNumErrorMessages(totNum - aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of correct messages " + ex);
            }

            // Number of late messages
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE Late='T' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setNumLateMessages(aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of late messages " + ex);
            }

            // Number of messages of type requested
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE ((Performative='" + ACLMessage.getPerformative(ACLMessage.REQUEST) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.REQUEST_WHEN) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.REQUEST_WHENEVER) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.CFP) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.PROPOSE) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.SUBSCRIBE) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.QUERY_IF) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.QUERY_REF) + "')) AND (IdSession='" + session + "')";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setQueryRef(aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of request messages " + ex);
            }

            // Number of messages of type accepted
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE ((Performative='" + ACLMessage.getPerformative(ACLMessage.AGREE) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.ACCEPT_PROPOSAL) + "')) AND (IdSession='" + session + "')";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setAcceptProposal(aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of accept messages " + ex);
            }

            // Number of messages of type rejected
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE ((Performative='" + ACLMessage.getPerformative(ACLMessage.REFUSE) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.REJECT_PROPOSAL) + "')) AND (IdSession='" + session + "')";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setRejectProposal(aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of reject messages " + ex);
            }

            // Number of messages of type information
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE ((Performative='" + ACLMessage.getPerformative(ACLMessage.INFORM) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.INFORM_IF) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.INFORM_REF) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.CONFIRM) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.DISCONFIRM) + "')) AND (IdSession='" + session + "')";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setInformation(aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of informative messages " + ex);
            }

            // Number of messages of type error
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE ((Performative='" + ACLMessage.getPerformative(ACLMessage.FAILURE) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.NOT_UNDERSTOOD) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.CANCEL) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.UNKNOWN) + "')) AND (IdSession='" + session + "')";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setError(aux);
            } catch (Exception ex) {
                System.err.println("Error getting number of error messages " + ex);
            }

            // Number of messages of type redirection
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE ((Performative='" + ACLMessage.getPerformative(ACLMessage.PROXY) + "')OR(Performative='" + ACLMessage.getPerformative(ACLMessage.PROPAGATE) + "')) AND (IdSession='" + session + "')";
                ResultSet rs = stmt.executeQuery(query);
                rs.next();
                aux = rs.getInt(1);
                rs.close();
                ms.setPropagate(aux);
            } catch (Exception ex) {
                System.err.println("Error getting number or redirected messages " + ex);
            }
            return ms;
        }
        return null;
    }

    /**
     * Returns a matrix with the amount of sent messages between each pair of system
     * agents, in the current session
     * @return Matrix of the current session.
     */
    public synchronized Matrix getMatrix() {
        if (connected) {
            String[] agents = new String[ControlProtocol.MAX_AGENTS];
            int[][] messages = new int[ControlProtocol.MAX_AGENTS][ControlProtocol.MAX_AGENTS];
            long[][] bytes = new long[ControlProtocol.MAX_AGENTS][ControlProtocol.MAX_AGENTS];

            int[] senders = new int[ControlProtocol.MAX_MESSAGES];
            String[] ids = new String[ControlProtocol.MAX_MESSAGES];
            String[] dates = new String[ControlProtocol.MAX_MESSAGES];
            long[] sizes = new long[ControlProtocol.MAX_MESSAGES];
            int[] idMessage = new int[ControlProtocol.MAX_MESSAGES];
            int i,j;
            int pos = 0;
            int num_sms = 0;
            String ag;
            String query;
            String rec;

            try {
                query = "SELECT IdMessage,Identifier,Date,Sender,Size FROM Messages WHERE IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);
                ResultSet rs2;
                while (rs.next()) {
                    ag = rs.getString("Sender");
                    for (i = 0; i < pos; i++)
                        if (agents[i].equals(ag)) break;
                    if (i == pos)
                        agents[pos++] = ag;

                    senders[num_sms] = i;
                    idMessage[num_sms] = rs.getInt("IdMessage");
                    sizes[num_sms] = rs.getLong("Size");
                    dates[num_sms] = rs.getString(3);
                    ids[num_sms++] = rs.getString("Identifier");
                }
                rs.close();

                if (num_sms == 0) return null;

                for (int m = 0; m < num_sms; m++) {
                    query = "SELECT Receiver FROM Receivers WHERE IdMessage=" + idMessage[m] + " AND Identifier='" + ids[m] + "' AND Date='" + dates[m] + "' AND IdSession='" + session + "'";
                    rs2 = stmt.executeQuery(query);
                    while (rs2.next()) {
                        rec = rs2.getString("Receiver");
                        for (j = 0; j < pos; j++)
                            if (agents[j].equals(rec)) break;
                        if (j == pos)
                            agents[pos++] = rec;

                        messages[senders[m]][j]++;
                        bytes[senders[m]][j] = bytes[senders[m]][j] + sizes[m];
                    }
                    rs2.close();
                }
            } catch (Exception ex) {
                System.err.println("Error getting matrix " + ex);
            }

            Matrix matrix = new Matrix(pos);
            matrix.setAgents(agents);
            matrix.setSizes(bytes);
            matrix.setMessages(messages);

            return matrix;
        }
        return null;
    }

    /**
     * Returns the statistics of an agent.
     * @param agent Name of the agent.
     * @return Statistics of the agent.
     */
    public synchronized AgentStats getAgentStats(String agent) {
        if (connected) {
            AgentStats as = new AgentStats();
            String query;
            int num;
            long num2;

            // Total number of conversations
            try {
                query = "SELECT COUNT(*) FROM Conversations WHERE Initiator='" + agent + "' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                rs.next();
                num = rs.getInt(1);
                as.setNumConversations(num);
            } catch (Exception ex) {
                System.err.println("Error getting number of conversations" + ex);
            }

            // Number of correct conversations
            try {
                query = "SELECT COUNT(*) FROM Conversations WHERE Initiator='" + agent + "' AND State='T' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                rs.next();
                num = rs.getInt(1);
                as.setNumConversationsOK(num);
            } catch (Exception ex) {
                System.err.println("Error getting number of correct conversations " + ex);
            }

            // Number of messages
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE Sender='" + agent + "' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                rs.next();
                num = rs.getInt(1);
                as.setNumMessagesSent(num);
            } catch (Exception ex) {
                System.err.println("Error getting number of sent messages " + ex);
            }

            // Number of correct messages
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE Sender='" + agent + "' AND Valid='T' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                rs.next();
                num = rs.getInt(1);
                as.setNumMessagesOK(num);
            } catch (Exception ex) {
                System.err.println("Error getting number of messages correctly sent " + ex);
            }

            // Number of late messages
            try {
                query = "SELECT COUNT(*) FROM Messages WHERE Sender='" + agent + "' AND Late='T' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                rs.next();
                num = rs.getInt(1);
                as.setNumMessagesLate(num);
            } catch (Exception ex) {
                System.err.println("Error getting number of messages sent too late " + ex);
            }

            // Number of received messages
            try {
                query = "SELECT COUNT(*) FROM Receivers WHERE Receiver='" + agent + "' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                rs.next();
                num = rs.getInt(1);
                as.setNumMessagesRec(num);
            } catch (Exception ex) {
                System.err.println("Error getting number of received messages " + ex);
            }

            // Number of bytes of sent messages
            try {
                query = "SELECT Size FROM Messages WHERE Sender='" + agent + "' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                num2 = 0;
                while (rs.next()) {
                    num2 = num2 + rs.getLong(1);
                }
                as.setBytesOut(num2);
            } catch (Exception ex) {
                System.err.println("Error getting number of bytes received " + ex);
            }

            // Number of bytes of received messages
            try {
                query = "SELECT m.Size FROM Messages AS m, Receivers AS r WHERE m.IdMessage=r.IdMessage AND m.Identifier=r.Identifier AND m.Date=r.Date AND r.Receiver='" + agent + "' AND r.IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                num2 = 0;
                while (rs.next()) {
                    num2 = num2 + rs.getLong(1);
                }
                as.setBytesIn(num2);
            } catch (Exception ex) {
                System.err.println("Error getting number of bytes sent " + ex);
            }

            return as;
        }
        return null;
    }

    /**
     * Returns the set of sent and received messages by a particular agent.
     * @param agent Name of the agent.
     * @return List of messages.
     */
    public synchronized Vector searchMessages(String agent) {
        if (connected) {
            // messages sent and received by the agent
            Vector messages = new Vector();
            String query;

            messages.add("   Sent:");
            try {
                query = "SELECT IdMessage,Identifier,Date,Protocol,Language,Ontology,Encoding,Performative,Valid,Late,Size,Content FROM Messages WHERE Sender='" + agent + "' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                String id,pro,onto,lang,encod,perf,cont,late,valid;
                long size;
                String date;
                int idMessage;

                while (rs.next()) {
                    idMessage = rs.getInt("IdMessage");
                    id = rs.getString("Identifier");
                    pro = rs.getString("Protocol");
                    onto = rs.getString("Ontology");
                    lang = rs.getString("Language");
                    encod = rs.getString("Encoding");
                    date = rs.getString(3);
                    perf = rs.getString("Performative");
                    valid = rs.getString("Valid");
                    late = rs.getString("Late");
                    size = rs.getLong("Size");
                    cont = rs.getString("Content");

                    messages.add(new LocatedMessage(idMessage, id, date, valid, perf, encod, agent, cont, onto, lang, pro, size, late));
                }

            } catch (Exception ex) {
                System.err.println("Error getting sent messages " + ex);
            }

            messages.add("----------------");
            messages.add("   Received:");

            try {
                query = "SELECT m.IdMessage,m.Identifier,m.Date,m.Protocol,m.Language,m.Ontology,m.Encoding,m.Sender,m.Performative,m.Valid,m.Late,m.Size,m.Content FROM Messages AS m, Receivers AS r WHERE m.Identifier=r.Identifier AND m.Date=r.Date AND r.Receiver='" + agent + "' AND r.IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                String id,pro,onto,lang,encod,perf,cont,late,valid,sender;
                long size;
                String date;
                int idMessage;

                while (rs.next()) {
                    idMessage = rs.getInt("IdMessage");
                    id = rs.getString("Identifier");
                    pro = rs.getString("Protocol");
                    onto = rs.getString("Ontology");
                    lang = rs.getString("Language");
                    encod = rs.getString("Encoding");
                    date = rs.getString(3);
                    sender = rs.getString("Sender");
                    perf = rs.getString("Performative");
                    valid = rs.getString("Valid");
                    late = rs.getString("Late");
                    size = rs.getLong("Size");
                    cont = rs.getString("Content");

                    messages.add(new LocatedMessage(idMessage, id, date, valid, perf, encod, sender, cont, onto, lang, pro, size, late));
                }

            } catch (Exception ex) {
                System.err.println("Error getting received messages " + ex);
            }

            return fillReceivers(messages);
        }
        return null;
    }

    private Vector fillReceivers(Vector messages) {
        Object obj;
        LocatedMessage lm;
        Vector aux;

        for (int i = 0; i < messages.size(); i++) {
            if ((obj = messages.get(i)) instanceof LocatedMessage) {
                lm = (LocatedMessage) obj;
                try {
                    String query = "SELECT Receiver FROM Receivers WHERE (IdMessage=" + lm.getIdMessage() + ") AND (Identifier='" + lm.getId() + "') AND (Date='" + lm.getDate() + "') AND IdSession='" + session + "'";
                    ResultSet rs = stmt.executeQuery(query);
                    aux = new Vector();

                    while (rs.next()) {
                        aux.add(rs.getString(1));
                    }

                    rs.close();
                    lm.setReceivers(aux);
                } catch (Exception ex) {
                    System.err.println("Error getting receivers " + ex);
                }
            }
        }
        return messages;
    }

    private long getMinDate() {
        long date;
        long minDate = System.currentTimeMillis();

        String result;

        try {
            String query = "SELECT Date FROM Messages WHERE IdSession='" + session + "'";
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                result = rs.getString(1);
                date = new Long(result).longValue();
                if (date < minDate)
                    minDate = date;
            }

            rs.close();

            return minDate;

        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("Error getting minimum date " + ex);
        }
        return -1;
    }

    private long getMaxDate() {
        long date;
        long maxDate = 0;
        String result;

        try {
            String query = "SELECT Date FROM Messages WHERE IdSession='" + session + "'";
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                result = rs.getString(1);
                date = new Long(result).longValue();
                if (date > maxDate)
                    maxDate = date;
            }

            rs.close();

            return maxDate;

        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("Error getting maximum date " + ex);
        }
        return -1;
    }

    private int getMessageDate(long str, long end) {
        try {
            long startDate = str;
            long endDate = end;
            String query = "SELECT COUNT(*) FROM Messages WHERE (Date>='" + startDate + "') AND (Date<='" + endDate + "') AND IdSession='" + session + "'";
            ResultSet rs = stmt.executeQuery(query);

            rs.next();
            int result = rs.getInt(1);
            rs.close();

            return result;

        } catch (Exception ex) {
            System.err.println("Error getting receivers " + ex);
        }

        return 0;
    }

    /**
     * Returns the amount of messages sent in each minute, along the current session.
     * @return List of messages/minute.
     */
    public synchronized Vector getTimeSerie() {
        if (connected) {
            long minDate = getMinDate();

            long maxDate = getMaxDate();

            long aux;
            int num;
            TimeSerieCell cell;
            Vector vector = new Vector();

            aux = minDate + 60000;

            while (minDate < maxDate) {
                num = getMessageDate(minDate, aux);
                cell = new TimeSerieCell(minDate, num);
                vector.add(cell);

                minDate += 60000;
                aux = minDate + 60000;
            }

            return vector;
        }

        return null;
    }

    /**
     * Returns the number of messages interchanged between the members of a group
     * of agents, ones with others.
     * @param agents List of agents of the group.
     * @return Number of interchanged messages.
     */
    public int getMessagesInsideGroup(java.util.LinkedList agents) {
        if (connected) {
            Matrix matrix = getMatrix();
            int message = 0;
            String ag1,ag2;
            int agent1,agent2;
            for (int i = 0; i < agents.size() - 1; i++) {
                ag1 = (String) agents.get(i);
                agent1 = matrix.getAgentByName(ag1);
                for (int j = i + 1; j < agents.size(); j++) {
                    ag2 = (String) agents.get(j);
                    agent2 = matrix.getAgentByName(ag2);
                    message = message + matrix.getMesssage(agent1, agent2) + matrix.getMesssage(agent2, agent1);
                }
            }

            return message;
        }
        return -1;
    }

    /**
     * Returns the total size of the messages interchanged between the members of a
     * group of agents, ones with others.
     * @param agents List of agents of the group.
     * @return Total size of the interchanged messages.
     */
    public long getSizeInsideGroup(java.util.LinkedList agents) {
        if (connected) {
            Matrix matrix = getMatrix();
            long size = 0;
            String ag1,ag2;
            int agent1,agent2;
            for (int i = 0; i < agents.size() - 1; i++) {
                ag1 = (String) agents.get(i);
                agent1 = matrix.getAgentByName(ag1);
                for (int j = i + 1; j < agents.size(); j++) {
                    ag2 = (String) agents.get(j);
                    agent2 = matrix.getAgentByName(ag2);
                    size = size + matrix.getSize(agent1, agent2) + matrix.getSize(agent2, agent1);
                }
            }
            return size;
        }
        return -1;
    }

    /**
     * Returns the list of messages of a conversation.
     * @param conversation Name of the conversation.
     * @return List of messages.
     */
    public synchronized Vector searchMessagesConv(String conversation) {
        if (connected) {
            Vector messages = new Vector();
            String query;

            try {
                query = "SELECT IdMessage,date,Sender,Protocol,Language,Ontology,Encoding,Performative,Valid,Late,Size,Content FROM Messages WHERE Identifier='" + conversation + "' AND IdSession='" + session + "' ORDER BY Date";
                ResultSet rs = stmt.executeQuery(query);

                String pro,onto,lang,encod,perf,cont,late,valid,sender;
                long size;
                String date;
                int idMessage;

                while (rs.next()) {
                    idMessage = rs.getInt("IdMessage");
                    pro = rs.getString("Protocol");
                    onto = rs.getString("Ontology");
                    lang = rs.getString("Language");
                    encod = rs.getString("Encoding");
                    date = rs.getString(2);
                    perf = rs.getString("Performative");
                    valid = rs.getString("Valid");
                    late = rs.getString("Late");
                    size = rs.getLong("Size");
                    cont = rs.getString("Content");
                    sender = rs.getString("Sender");

                    messages.add(new LocatedMessage(idMessage, conversation, date, valid, perf, encod, sender, cont, onto, lang, pro, size, late));
                }

            } catch (Exception ex) {
                System.err.println("Error getting messages from conversation " + ex);
                return null;
            }
            return fillReceivers(messages);
        }
        return null;
    }

    /**
     * Returns the set of agents involved in some way in a conversation.
     * @param conversation Name of the conversation.
     * @return List of the participant agents.
     */
    public synchronized Vector searchParticipants(String conversation) {
        if (connected) {
            Vector participants = new Vector();
            String query,aux;

            try {
                query = "SELECT Sender FROM Messages WHERE Identifier='" + conversation + "' AND IdSession='" + session + "'";
                ResultSet rs = stmt.executeQuery(query);

                while (rs.next()) {
                    aux = rs.getString(1);
                    if (!participants.contains(aux)) participants.add(aux);
                }
                rs.close();

                query = "SELECT Receiver FROM Receivers WHERE Identifier='" + conversation + "' AND IdSession='" + session + "'";
                ResultSet rs2 = stmt.executeQuery(query);

                while (rs2.next()) {
                    aux = rs2.getString(1);
                    if (!participants.contains(aux)) participants.add(aux);
                }
                rs2.close();
            } catch (Exception ex) {
                System.err.println("Error getting the participants of the conversation " + ex);
                return null;
            }
            return participants;
        }
        return null;
    }

    /**
     * Returns the set of the sessions stored in data base .
     * @return List of sessions.
     */
    public synchronized Vector getSessions() {
        if (connected) {
            Vector vector = new Vector();
            String query,description,date;
            int number;
            Session session;

            try {
                query = "SELECT Identifier,Name,Date FROM Sessions";
                ResultSet rs = stmt.executeQuery(query);

                while (rs.next()) {
                    number = rs.getInt("Identifier");
                    description = rs.getString("Name");
                    date = rs.getString(3);
                    session = new Session(number, description, date);
                    vector.add(session);
                }
                rs.close();
            } catch (Exception ex) {
                System.err.println("Error getting sessions " + ex);
                return null;
            }
            return vector;
        }
        return null;
    }

    /**
     * Load as active session a session stored in the data base.
     * @param newSes Number of the session.
     */
    public synchronized void loadSession(int newSes) {
        if (connected)
            session = newSes;
    }
}