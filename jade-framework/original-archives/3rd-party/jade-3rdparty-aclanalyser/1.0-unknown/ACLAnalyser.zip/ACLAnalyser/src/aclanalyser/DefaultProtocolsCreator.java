package aclanalyser;

/**
 * Creates default FIPA protocols. This class should be invoked directly.
 */
public class DefaultProtocolsCreator {

    public static void main(String[] args) {
        Protocol.createDefaultProtocols();
    }

}
