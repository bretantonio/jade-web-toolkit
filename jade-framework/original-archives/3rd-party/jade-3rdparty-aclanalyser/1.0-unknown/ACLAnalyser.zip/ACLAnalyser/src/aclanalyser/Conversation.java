package aclanalyser;

import java.util.*;

import jade.lang.acl.*;
import jade.core.*;

/**
 * Represents a conversation, being watched by an instance of ControlProtocol,
 * before being introduced in the data base.
 */
public class Conversation {

    private String ontology;
    private String language;
    private String conversationId;
    private String protocol;
    private Protocol objectProtocol;
    private String performStart;
    private String performEnd;
    private long date;

    private LinkedList listMessages;
    private ControlProtocol controlProtocol;
    private State state;

    private boolean block;

    /**
     * Creates a new Conversation, initializing some of its fields.
     * @param convId Identifier of the conversation.
     * @param prot Name of the protocol.
     * @param ont Name of the ontology.
     * @param lang Name of the language.
     * @param sender Agent starting the conversation.
     * @param perf First performative of the conversation.
     * @param time Starting date.
     * @param cp Instance of ControlProtocol watching over this conversation.
     */
    public Conversation(String convId, String prot, String ont, String lang, AID sender, String perf, long time, ControlProtocol cp) {
        language = lang;
        ontology = ont;
        conversationId = convId;
        protocol = prot;
        performStart = perf;
        performEnd = perf;
        state = new State(0, sender, this);
        listMessages = new LinkedList();
        date = time;
        controlProtocol = cp;
    }

    /**
     * Adds a message to the set of messages of the conversation.
     * @param sms Message to be added.
     * @param value Whether the message is correct or not.
     * @param date Message's sending date.
     */
    public void addMessage(ACLMessage sms, boolean value, long date) {
        MessageCell cm = new MessageCell(sms, value, date);
        listMessages.add(cm);
    }

    /**
     * Gets the state of the conversation.
     * @return State of the conversation.
     */
    public int getState() {
        return state.getState();
    }

    /**
     * Gets the state of a participant in the conversation.
     * @param ag Agent.
     * @return State of the participant.
     */
    public int getState(AID ag) {
        return state.getState(ag);
    }

    /**
     * Gets the state of a series of participants in the conversation.
     * @param agents List of agents.
     * @return State of the participants.
     */
    public int getState(Iterator agents) {
        return state.getState(agents);
    }

    /**
     * Gets the ontology of the conversation.
     * @return Ontology of the conversation.
     */
    public String getOntology() {
        return ontology;
    }

    /**
     * Gets the language of the conversation.
     * @return Language of the conversation.
     */
    public String getLanguage() {
        return language;
    }

    /**
     * Gets the name of the protocol of the conversation.
     * @return Name of the protocol.
     */
    public String getProtocol() {
        return protocol;
    }

    /**
     * Gets the protocol of the conversation.
     * @return Protocol of the conversation.
     */
    public Protocol getObjectProtocol() {
        return objectProtocol;
    }

    /**
     * Gets the identifier of the conversation.
     * @return Identifier of the conversation.
     */
    public String getId() {
        return conversationId;
    }

    /**
     * Sets the name of the protocol of the conversation.
     * @param prot Name of the protocol.
     */
    public void setProtocol(String prot) {
        protocol = prot;
    }

    /**
     * Sets the protocol of the conversation.
     * @param protoc Protocol of the conversation.
     */
    public void setObjectProtocol(Protocol protoc) {
        objectProtocol = protoc;
    }

    /**
     * Sets the state of the conversation.
     * @param state State of the conversation.
     */
    public void setState(int state) {
        this.state.setState(state);
    }

    /**
     * Gets the initiator agent of the conversation.
     * @return Initiator agent.
     */
    public AID getInitiator() {
        return state.getInitiator();
    }

    /**
     * Updates the state of the conversation, signaling whether the conversation is
     * simple or multiple, and indicating the conversation's participants.
     * @param agents List of participant agents.
     */
    public void updateState(Iterator agents) {
        if (objectProtocol.getType().equals(ControlProtocol.MULTIPLE)) {
            ContractState ec = new ContractState(-1, state.getInitiator(), this);
            state = ec;
        } else {
            AID ag = (AID) agents.next();
            RestState er = new RestState(state.getState(), state.getInitiator(), ag, this);
            state = er;
        }
    }

    /**
     * Sets the name of the ending performative of the conversation.
     * @param perf Name of the performative.
     */
    public void setPerformEnd(String perf) {
        performEnd = perf;
    }

    /**
     * Gets the starting performative of the conversation.
     * @return Name of the performative.
     */
    public String getPerformStart() {
        return performStart;
    }

    /**
     * Gets the ending performative of the conversation.
     * @return Name of the performative.
     */
    public String getPerformEnd() {
        return performEnd;
    }

    /**
     * Sets the state for a series of participants in a multiple conversation.
     * @param stat State for the participants.
     * @param agents List of participants.
     */
    public void setState(int stat, Iterator agents) {
        ContractState cs = (ContractState) state;
        cs.setState(stat, agents);
    }

    /**
     * Sets the state for a participant of a multiple conversation.
     * @param state State for the participant.
     * @param agent Participant.
     */
    public void setState(int state, AID agent) {
        ContractState cs = (ContractState) this.state;
        cs.setState(state, agent);
    }

    /**
     * Gets the participant of a multiple conversation.
     * @return Participant.
     */
    public AID getParticipant() {
        RestState res = (RestState) state;
        return res.getParticipant();
    }

    /**
     * Gets the starting date of a conversation.
     * @return Conversation's starting date.
     */
    public long getDate() {
        return date;
    }

    /**
     * Gets the rol of an agent in a conversation.
     * @param ag Agent.
     * @return Agent's rol.
     */
    public String getRol(AID ag) {
        return state.getRol(ag);
    }

    /**
     * Indicates if the conversation has finished.
     * @return true if the conversation has finished, false otherwise.
     */
    public synchronized boolean end() {
        return state.end();
    }

    /**
     * Sets an alarm for a series of participants of a conversation, which is defined
     * by an expiration date or by a default value if date is null.
     * @param date Alarm's expiration date.
     * @param agents List of agents.
     */
    public void setAlarm(long date, Iterator agents) {
        long time = computeTime(date);

        while (agents.hasNext()) {
            AID agent = (AID) agents.next();
            state.setAlarm(time, agent);
        }
    }

    /**
     * Sets an alarm for a participant in the conversation, which is defined
     * by an expiration date or by a default value if date is null.
     * @param date Alarm's expiration date.
     * @param agent Participant agent.
     */
    public void setAlarm(long date, AID agent) {
        long time = computeTime(date);
        state.setAlarm(time, agent);
    }

    /**
     * Sets an alarm for a conversation, which is defined
     * by an expiration date or by a default value if date is null.
     * @param date Alarm's expiration date.
     */
    public void setAlarm(long date) {
        long time = computeTime(date);
        state.setAlarm(time, null);
    }

    private long computeTime(long date) {
        long time = ControlProtocol.MAX_TIME;

        if (date != -1) {
            long now = System.currentTimeMillis();
            time = date - now;
        }
        return time;
    }

    /**
     * Stops an existing alarm for a series of participants in the conversation.
     * @param agents List of agents.
     */
    public void stopAlarm(Iterator agents) {
        while (agents.hasNext()) {
            AID agent = (AID) agents.next();
            state.stopAlarm(agent);
        }
    }

    /**
     * Stops an existing alarm for a participant in the conversation.
     * @param agent Participant agent.
     */
    public void stopAlarm(AID agent) {
        state.stopAlarm(agent);
    }

    /**
     * Tells the instance of ControlProtocol to check if the conversation has finished,
     * and if so to store it in the data base.
     */
    public void notification() {
        controlProtocol.review(this, ControlProtocol.TIMEOUT);
    }

    /**
     * Blocks the conversation if it wasn't already blocked.
     * @return If the blocking succeeded.
     */
    public synchronized boolean blocked() {
        if (block)
            return true;
        else {
            block = true;
            return false;
        }
    }

    /**
     * Unblocks the conversation.
     */
    public void unblock() {
        block = false;
    }

    /**
     * Returns the first message from the list of messages of the conversation,
     * and it removes it from the list.
     * @return A message of the conversation if there are still left, null otherwise.
     */
    public MessageCell getMessageCell() {
        MessageCell mc;

        if (listMessages.size() > 0) {
            mc = (MessageCell) listMessages.get(0);
            listMessages.remove(0);
            return mc;
        } else
            return null;
    }

    /**
     * Gets the date of the last message sent that belongs to this conversation.
     * @return Last message's sending date.
     */
    public long maxDate() {
        long date = -1;
        MessageCell mc;

        for (int i = 0; i < listMessages.size(); i++) {
            mc = (MessageCell) listMessages.get(i);
            if (i == 0)
                date = mc.getDate();
            else if (mc.getDate() > date)
                date = mc.getDate();
        }
        return date;
    }
}