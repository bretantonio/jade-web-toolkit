package aclanalyser;

import jade.lang.acl.*;

/**
 * Saves a message of a conversation along with related information.
 */
public class MessageCell {
    private ACLMessage message;
    private boolean value;
    private long date;

    /**
     * Creates a instance of MessageCell by filling all its fields.
     * @param sms Message to save.
     * @param val Whether the message is correct or not.
     * @param date Message's sent date.
     */
    public MessageCell(ACLMessage sms, boolean val, long date) {
        message = (ACLMessage) sms.clone();
        value = val;
        this.date = date;
    }

    /**
     * Gets the message's sent date.
     * @return Sent date.
     */
    public long getDate() {
        return date;
    }

    /**
     * Gets the correctness of the message.
     * @return Whether the message is correct or not.
     */
    public boolean getValue() {
        return value;
    }

    /**
     * Gets the message.
     * @return Saved message.
     */
    public ACLMessage getMessage() {
        return message;
    }
}
