package aclanalyser;

import java.util.LinkedList;

public class ConversationStats {
    private int numConv;
    private int numCompleteConv;
    private int numIncompleteConv;
    private LinkedList protocol = new LinkedList();

    public int getNumConv() {
        return numConv;
    }

    public int getNumCompleteConv() {
        return numCompleteConv;
    }

    public int getNumIncompleteConv() {
        return numIncompleteConv;
    }

    public int getNumProtocol(String name) {
        ConvProt cp;
        for (int i = 0; i < protocol.size(); i++) {
            cp = (ConvProt) protocol.get(i);
            if (cp.getName().equals(name)) return cp.getNum();
        }
        return 0;
    }

    public void setNumConv(int aux) {
        numConv = aux;
    }

    public void setNumCompleteConv(int aux) {
        numCompleteConv = aux;
    }

    public void setNumIncompleteConv(int aux) {
        numIncompleteConv = aux;
    }

    public void setNumProtocol(int aux, String name) {
        ConvProt cp = new ConvProt(aux, name);
        protocol.add(cp);
    }

    private class ConvProt {
        private int num;
        private String name;

        public ConvProt(int number, String name) {
            num = number;
            this.name = name;
        }

        public int getNum() {
            return num;
        }

        public String getName() {
            return name;
        }
    }
}