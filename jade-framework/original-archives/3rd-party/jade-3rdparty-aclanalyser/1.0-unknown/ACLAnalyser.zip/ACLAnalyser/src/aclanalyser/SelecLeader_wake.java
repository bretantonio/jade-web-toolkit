package aclanalyser;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

import java.util.LinkedList;

public class SelecLeader_wake extends Agent {

    private int identifier;
    private int maxim;
    private int conv = 0;
    private LinkedList neighbors;
    private LinkedList messages;

    protected void setup() {
        Double value = new Double(Math.random() * 1000);
        identifier = value.intValue();
        maxim = identifier;
        try {
            Thread.sleep(55000);
        } catch (Exception ec) {
            System.out.println("Error sleeping");
        }
        neighbors = new LinkedList();
        messages = new LinkedList();
        computeNeighbors();
        addBehaviour(new SendNeighborsBehaviour(identifier));
        addBehaviour(new ReceiveIdent());
        addBehaviour(new SendAgreeBehaviour(this, 500));
    }

    private void computeNeighbors() {
        String name = getName();
        int pos1 = name.indexOf("--");
        int pos2 = name.indexOf("@");
        String number = name.substring(pos1 + 2, pos2);
        String part1 = name.substring(0, pos1 + 2);
        String part2 = name.substring(pos2, name.length());

        Integer num = Integer.valueOf(number);
        if (num.intValue() > 0) {
            Integer nei = new Integer(num.intValue() - 1);
            String neighbor = part1 + nei + part2;
            neighbors.add(new AID(neighbor, false));
        }

        if (num.intValue() < (Example1.NUM_AGENTS - 1)) {
            Integer nei = new Integer(num.intValue() + 1);
            String neighbor = part1 + nei + part2;
            neighbors.add(new AID(neighbor, false));
        }
    }

    private class SendNeighborsBehaviour extends OneShotBehaviour {

        private int deliver;

        public SendNeighborsBehaviour(int env) {
            super();
            deliver = env;
        }

        public void action() {
            // send a message to its neighbors with the fact 'deliver'
            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
            AID receiv;

            for (int i = 0; i < neighbors.size(); i++) {
                receiv = (AID) neighbors.get(i);
                message.addReceiver(receiv);
            }

            message.setContent("" + deliver);
            message.setProtocol("fipa-unimur");
            message.setLanguage("l1");
            message.setOntology("o1");
            message.setConversationId(getLocalName() + "-" + (conv++));

            send(message);
        }
    }

    private class ReceiveIdent extends CyclicBehaviour {

        public void action() {
            ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.INFORM));
            if (msg != null) {
                String number = msg.getContent();
                int num = Integer.valueOf(number).intValue();
                if (num > maxim) {
                    maxim = num;
                    addBehaviour(new SendNeighborsBehaviour(maxim));
                }
                // deliver agreement
                addSms(msg);
            } else // if no message has arrived, block the behaviour
                block();
        }
    }

    class SendAgreeBehaviour extends WakerBehaviour {

        private ACLMessage sms;

        public SendAgreeBehaviour(Agent a, long time) {
            super(a, time);
        }

        public void handleElapsedTimeout() {
            LinkedList list = getSms();
            ACLMessage sms,response;

            for (int i = 0; i < list.size(); i++) {
                sms = (ACLMessage) list.get(i);
                response = sms.createReply();
                response.setPerformative(ACLMessage.AGREE);
                send(response);
            }
            reset(500);
        }
    }

    private synchronized void addSms(ACLMessage sms) {
        messages.add(sms);
    }

    private synchronized LinkedList getSms() {
        LinkedList list = (LinkedList) messages.clone();
        for (int i = 0; i < messages.size(); i++)
            messages.removeFirst();
        return list;
    }

}