package aclanalyser;

import jade.core.Agent;
import jade.domain.FIPAAgentManagement.*;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.WakerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

import jade.wrapper.*;

import java.awt.*;

/**
 * Creates NUM_AGENTS (100) agents. Use the debugger to sniff and check conversations,
 * stats, etc. This class uses the Leader algorithm.
 */
public class Example1 extends Agent {

    public static final int NUM_AGENTS = 100;
    public static final long WAIT = 100000;

    private int responses = 0;
    private boolean correct = true;
    private int leader = -1;

    protected void setup() {

        try {
            // creates the agent description of itself
            DFAgentDescription dfd = new DFAgentDescription();
            dfd.setName(getAID());
            // register the description with the DF
            DFService.register(this, dfd);
        } catch (FIPAException e) {
            e.printStackTrace();
        }

        String[] agents = new String[NUM_AGENTS];
        for (int i = 0; i < NUM_AGENTS; i++)
            agents[i] = getLocalName() + "--" + i;

        try {
            // gets a container controller for creating new agents
            PlatformController container = getContainerController();
            for (int i = 0; i < NUM_AGENTS; i++) {
                //Thread.sleep(100);
                container.createNewAgent(agents[i], "aclanalyser.SelecLeader", null).start();
            }
            addBehaviour(new receiveMessage());
            addBehaviour(new informResultBehaviour(this, WAIT + 50000));
        } catch (Exception any) {
            any.printStackTrace();
        }
    }

    private class receiveMessage extends CyclicBehaviour {

        public void action() {
            ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.INFORM));
            if (msg != null) {
                String num = msg.getContent();
                Integer aux = new Integer(num);
                int number = aux.intValue();
                responses++;
                if (leader == -1)
                    leader = number;
                else if (leader != number) correct = false;
            } else // if no message has arrived, block the behaviour
                block();
        }
    }

    private class informResultBehaviour extends WakerBehaviour {
        //informa del leader seleccionado y acaba el agent
        Agent agent;

        public informResultBehaviour(Agent a, long time) {
            super(a, time);
            agent = a;
        }

        public void handleElapsedTimeout() {
            String result;

            if ((correct) && (responses == NUM_AGENTS))
                result = "The leader is: " + leader;
            else
                result = "Error getting leader";

            // print in a screen the result
            Response frame = new Response();

            frame.validate();

            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
            frame.setVisible(true);
            frame.setResult(result);

            agent.doDelete();
        }
    }

}