package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.io.*;
import java.io.*;

public class WindowMain extends JFrame implements Termination {
    static final int NEW_SESSION = 0;
    static final int LOAD_SESSION = 1;
    static final int END = 2;

    private ControlProtocol control;
    private DBAccess abd;
    private JFileChooser jFileChooser1;
    private LogFilter filter;
    private WindowSearchConv windowSearchConv = null;
    private WindowGraph windowGraph = null;
    private WindowStatistics windowStats = null;
    private WindowProtocol windowProtocol = null;
    private WindowSetup windowSetup = null;
    private WindowLoadSession windowLoadSession = null;
    private Vector persistentWindows = new Vector();
    private Vector sessionWindows = new Vector();
    private Vector messages = new Vector();
    private String session;
    private boolean doLog = false;

    private JPanel contentPane;
    private JMenuItem jMenuItem1 = new JMenuItem();
    private JMenuItem jMenuItem2 = new JMenuItem();
    private JMenuItem jMenuItem3 = new JMenuItem();
    private JMenuItem jMenuItem4 = new JMenuItem();
    private JMenuItem jMenuItem5 = new JMenuItem();
    private JMenuItem jMenuItem6 = new JMenuItem();
    private JMenuItem jMenuItem7 = new JMenuItem();
    private JMenuItem jMenuItem8 = new JMenuItem();
    private JMenuItem jMenuItem9 = new JMenuItem();
    private JMenuItem jMenuItem10 = new JMenuItem();
    private JMenuItem jMenuItem11 = new JMenuItem();
    private JMenuBar jMenuBar1 = new JMenuBar();
    private JMenu jMenu2 = new JMenu();
    private JMenu jMenu1 = new JMenu();
    private JMenu jMenu3 = new JMenu();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JList jList1 = new JList();
    private JCheckBoxMenuItem jCheckBoxMenuItem1 = new JCheckBoxMenuItem();
    private JCheckBoxMenuItem jCheckBoxMenuItem2 = new JCheckBoxMenuItem();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();
    private JButton jButton5 = new JButton();

    // We build the frame
    public WindowMain(DBAccess access, ControlProtocol cp) {
        control = cp;
        abd = access;
        session = abd.getSessionName();
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cyclops.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(462, 367));
        this.setTitle("Session " + session);
        jList1.setBounds(new Rectangle(21, 43, 417, 257));
        jScrollPane1.setBounds(new Rectangle(21, 43, 417, 257));

        jMenuItem1.setText("Search conversations");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem1_actionPerformed(e);
            }
        });
        jMenuItem1.setIcon(new ImageIcon("images" + File.separator + "searchConv.gif"));

        jMenuItem2.setText("Graph of Agents");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem2_actionPerformed(e);
            }
        });
        jMenuItem2.setIcon(new ImageIcon("images" + File.separator + "graph.gif"));

        jMenuItem3.setText("Statistics");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem3_actionPerformed(e);
            }
        });
        jMenuItem3.setIcon(new ImageIcon("images" + File.separator + "cheese.gif"));

        jMenuItem4.setText("Protocols");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem4_actionPerformed(e);
            }
        });
        jMenuItem4.setIcon(new ImageIcon("images" + File.separator + "tie.gif"));

        jMenuItem5.setText("Clear Log");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem5_actionPerformed(e);
            }
        });

        jMenuItem6.setText("Load Log");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem6_actionPerformed(e);
            }
        });

        jMenuItem7.setText("Save Log");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem7_actionPerformed(e);
            }
        });

        jCheckBoxMenuItem2.setText("Do log");
        jCheckBoxMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBoxMenuItem2_actionPerformed(e);
            }
        });

        jMenuItem8.setText("Exit");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem8_actionPerformed(e);
            }
        });
        jMenuItem8.setIcon(new ImageIcon("images" + File.separator + "exit.gif"));

        jMenuItem9.setText("New Session");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem9_actionPerformed(e);
            }
        });

        jMenuItem10.setText("Load Session");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem10_actionPerformed(e);
            }
        });

        jMenuItem11.setText("Setup");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jMenuItem11_actionPerformed(e);
            }
        });

        jCheckBoxMenuItem1.setText("Sniff");
        jCheckBoxMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jCheckBoxMenuItem1_actionPerformed(e);
            }
        });

        jMenu1.setText("Actions");
        jMenu1.add(jMenuItem1);
        jMenu1.add(jMenuItem2);
        jMenu1.add(jMenuItem3);
        jMenu1.add(jMenuItem4);
        jMenu1.add(new JPopupMenu.Separator());
        jMenu1.add(jMenuItem11);
        jMenu1.add(new JPopupMenu.Separator());
        jMenu1.add(jMenuItem8);
        jMenu2.setText("Log");
        jMenu2.add(jMenuItem5);
        jMenu2.add(jMenuItem6);
        jMenu2.add(jMenuItem7);
        jMenu2.add(new JPopupMenu.Separator());
        jMenu2.add(jCheckBoxMenuItem2);
        jMenu3.setText("Session");
        jMenu3.add(jMenuItem9);
        jMenu3.add(jMenuItem10);
        jMenu3.add(new JPopupMenu.Separator());
        jMenu3.add(jCheckBoxMenuItem1);
        jMenuBar1.add(jMenu1);
        jMenuBar1.add(jMenu2);
        jMenuBar1.add(jMenu3);

        jButton1.setBounds(new Rectangle(23, 9, 31, 28));
        jButton1.setText("");
        jButton1.setToolTipText("Search conversations");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton1.setIcon(new ImageIcon("images" + File.separator + "searchConv.gif"));
        jButton2.setText("");
        jButton2.setToolTipText("Graph of Agents");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(56, 9, 31, 28));
        jButton2.setIcon(new ImageIcon("images" + File.separator + "graph.gif"));
        jButton3.setText("");
        jButton3.setToolTipText("Statistics");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton3.setBounds(new Rectangle(89, 9, 31, 28));
        jButton3.setIcon(new ImageIcon("images" + File.separator + "cheese.gif"));
        jButton4.setText("");
        jButton4.setToolTipText("Protocols");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jButton4.setBounds(new Rectangle(122, 9, 31, 28));
        jButton4.setIcon(new ImageIcon("images" + File.separator + "tie.gif"));
        jButton5.setText("");
        jButton5.setToolTipText("Exit");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton5_actionPerformed(e);
            }
        });
        jButton5.setBounds(new Rectangle(175, 8, 34, 31));
        jButton5.setIcon(new ImageIcon("images" + File.separator + "exit.gif"));

        contentPane.add(jScrollPane1, null);
        contentPane.add(jList1, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
        contentPane.add(jButton3, null);
        contentPane.add(jButton4, null);
        contentPane.add(jButton5, null);
        this.setJMenuBar(jMenuBar1);

        filter = new LogFilter();
        jFileChooser1 = new JFileChooser();
        jFileChooser1.addChoosableFileFilter(filter);

        jList1.setListData(messages);
        jScrollPane1.getViewport().setView(jList1);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            callExit();
        }
    }

    synchronized void jMenuItem1_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            callSearchConv();
    }

    synchronized void jMenuItem2_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            callGraph();
    }

    synchronized void jMenuItem3_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            callStat();
    }

    synchronized void jMenuItem4_actionPerformed(ActionEvent e) {
        callProtocol();
    }

    synchronized void jMenuItem11_actionPerformed(ActionEvent e) {
        callSetup();
    }

    synchronized void jMenuItem5_actionPerformed(ActionEvent e) {
        messages = new Vector();
        jList1.setListData(messages);
        jScrollPane1.getViewport().setView(jList1);
    }

    synchronized void jMenuItem6_actionPerformed(ActionEvent e) {
        int a = jFileChooser1.showOpenDialog(this);
        if (a == JFileChooser.APPROVE_OPTION) {
            File file = jFileChooser1.getSelectedFile();
            if ((file.isFile()) && (filter.accept(file))) {
                // Open file
                messages = new Vector();
                BufferedReader br = null;
                try {
                    br = new BufferedReader(new FileReader(file.getAbsolutePath()));
                } catch (Exception ex) {
                    System.err.println("Error reading log file " + ex);
                }

                try {
                    String line = br.readLine();

                    while (line != null) {
                        messages.add(line);
                        line = br.readLine();
                    }

                } catch (Exception ex) {
                    System.err.println("Error reading line from log file " + ex);
                }

                jList1.setListData(messages);
                jScrollPane1.getViewport().setView(jList1);
            }
        }
    }

    synchronized void jMenuItem7_actionPerformed(ActionEvent e) {
        int a = jFileChooser1.showSaveDialog(this);
        if (a == JFileChooser.APPROVE_OPTION) {
            File file = jFileChooser1.getSelectedFile();
            if (filter.accept(file)) {
                try {
                    file.createNewFile();
                    if (file.isFile()) {
                        String nombre = file.getAbsolutePath();
                        file.delete();
                        BufferedWriter bw = new BufferedWriter(new FileWriter(nombre));
                        String message;
                        for (int i = 0; i < messages.size(); i++) {
                            message = (String) messages.get(i);
                            bw.write(message, 0, message.length());
                            bw.newLine();
                            bw.flush();
                        }
                        bw.close();
                    }
                } catch (Exception ex) {
                    System.err.println("Error creating protocol file " + ex);
                }
            }
        }
    }

    synchronized void jMenuItem8_actionPerformed(ActionEvent e) {
        callExit();
    }

    synchronized void jMenuItem9_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            endSession(NEW_SESSION);
    }

    synchronized void jMenuItem10_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            endSession(LOAD_SESSION);
    }

    synchronized void jCheckBoxMenuItem1_actionPerformed(ActionEvent e) {
        control.doSniff(jCheckBoxMenuItem1.getState());
    }

    synchronized void jCheckBoxMenuItem2_actionPerformed(ActionEvent e) {
        doLog = !doLog;
    }

    public synchronized void addText(String text) {
        if (doLog) {
            GregorianCalendar date = new GregorianCalendar();

            String day = "" + date.get(Calendar.DAY_OF_MONTH);
            String month = "" + (date.get(Calendar.MONTH) + 1);
            String year = "" + date.get(Calendar.YEAR);
            String hour = "" + date.get(Calendar.HOUR_OF_DAY);
            String minute = "" + date.get(Calendar.MINUTE);
            String second = "" + date.get(Calendar.SECOND);

            String curDate = day + "/" + month + "/" + year + " " + hour + ":" + minute + ":" + second;
            text = curDate + "   " + text;
            messages.add(text);
            jList1.setListData(messages);
            jScrollPane1.getViewport().setView(jList1);
        }
    }

    private synchronized void endSession(int mode) {
        WindowSaveSession windowSaveSession = new WindowSaveSession(abd, mode, this);

        // save persistent windows
        if (windowGraph != null) persistentWindows.add(windowGraph);
        if (windowStats != null) persistentWindows.add(windowStats);
        windowGraph = null;
        windowStats = null;
        // remove remaining windows
        if (windowSearchConv != null) windowSearchConv.end();
        if (windowProtocol != null) windowProtocol.end();
        if (windowLoadSession != null) windowLoadSession.end();
        // including the session ones
        Termination aux;
        for (int i = 0; i < sessionWindows.size(); i++) {
            aux = (Termination) sessionWindows.get(i);
            aux.end();
        }
    }

    public synchronized void response(int mode) {
        if (mode == NEW_SESSION) {
            abd.createNewSession();
            session = abd.getSessionName();
            this.setTitle("Session " + session);
            messages = new Vector();
            jList1.setListData(messages);
            jScrollPane1.getViewport().setView(jList1);
        } else if (mode == LOAD_SESSION) {
            if (windowLoadSession == null)
                windowLoadSession = new WindowLoadSession(abd, this);

            // Validate frames with preset sizes.
            // Pack frames with important size information. For instance about its design.
            windowLoadSession.validate();

            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = windowLoadSession.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            windowLoadSession.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
            windowLoadSession.setVisible(true);
            messages = new Vector();
            jList1.setListData(messages);
            jScrollPane1.getViewport().setView(jList1);
        } else {
            end();
        }
    }

    public void update() {
        windowLoadSession = null;
        session = abd.getSessionName();
        this.setTitle("Session " + session);
    }

    void jButton1_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            callSearchConv();
    }

    void jButton2_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            callGraph();
    }

    void jButton3_actionPerformed(ActionEvent e) {
        if (abd.isConnected())
            callStat();
    }

    void jButton4_actionPerformed(ActionEvent e) {
        callProtocol();
    }

    void jButton5_actionPerformed(ActionEvent e) {
        callExit();
    }

    private void callSearchConv() {

        if (windowSearchConv != null) windowSearchConv.end();

        windowSearchConv = new WindowSearchConv(abd, this);
        // Validate frames with preset sizes.
        // Pack frames with important size information. For instance about its design.
        windowSearchConv.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = windowSearchConv.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        windowSearchConv.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        windowSearchConv.setVisible(true);
    }

    private void callGraph() {
        if (windowGraph != null) {
            windowGraph.end();
        }

        windowGraph = new WindowGraph(abd, this);
        // Validate frames with preset sizes.
        // Pack frames with important size information. For instance about its design.
        windowGraph.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = windowGraph.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        windowGraph.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        windowGraph.setVisible(true);
    }

    private void callStat() {
        if (windowStats != null)
            windowStats.end();

        windowStats = new WindowStatistics(control, abd);
        // Validate frames with preset sizes.
        // Pack frames with important size information. For instance about its design.
        windowStats.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = windowStats.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        windowStats.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        windowStats.setVisible(true);

    }

    private void callProtocol() {
        if (windowProtocol != null) windowProtocol.end();

        windowProtocol = new WindowProtocol(control);
        // Validate frames with preset sizes.
        // Pack frames with important size information. For instance about its design.
        windowProtocol.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = windowProtocol.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        windowProtocol.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        windowProtocol.setVisible(true);
    }

    private void callSetup() {
        if (windowSetup != null) windowSetup.end();

        windowSetup = new WindowSetup(abd, this);
        // Validate frames with preset sizes.
        // Pack frames with important size information. For instance about its design.
        windowSetup.validate();

        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = windowSetup.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        windowSetup.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        windowSetup.setVisible(true);
    }

    private void callExit() {
        // we ask to save current session
        WindowSaveSession windowSaveSession = new WindowSaveSession(abd, END, this);
    }

    public void end() {
        // makes agent to finish
        control.stopAgent();

        removeAllWindows();

        setVisible(false);
        dispose();
    }

    public void invalidSession() {
        removeAllWindows();
        session = abd.getSessionName();
        this.setTitle("Session " + session);
    }

    public void removeAllWindows() {
        // clean all windows
        removeLocal();

        // including the session ones
        removeSession();

        // including the persistent ones
        removePersistent();
    }

    private void removeLocal() {
        if (windowSearchConv != null) windowSearchConv.end();
        if (windowGraph != null) windowGraph.end();
        if (windowStats != null) windowStats.end();
        if (windowProtocol != null) windowProtocol.end();
        if (windowLoadSession != null) windowLoadSession.end();
        if (windowSetup != null) windowSetup.end();
    }

    private void removeSession() {
        Termination aux;

        for (int i = 0; i < sessionWindows.size(); i++) {
            aux = (Termination) sessionWindows.get(i);
            aux.end();
        }
    }

    private void removePersistent() {
        Termination aux;

        for (int i = 0; i < persistentWindows.size(); i++) {
            aux = (Termination) persistentWindows.get(i);
            aux.end();
        }
    }

    public void setWindowSession(Termination frame) {
        sessionWindows.add(frame);
    }

    public void setPersistentWindow(Termination frame) {
        persistentWindows.add(frame);
    }
}