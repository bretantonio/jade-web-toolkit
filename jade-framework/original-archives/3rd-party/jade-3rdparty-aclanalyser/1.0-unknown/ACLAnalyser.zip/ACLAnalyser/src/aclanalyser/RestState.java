package aclanalyser;

import jade.core.*;

/**
 * Represents the state for a single conversations, i.e. a conversation between
 * an initiator and a participant.
 */
public class RestState extends State {
    private AID participant;

    /**
     * Creates and initializes a new instance of RestState.
     * @param sta Initial state.
     * @param init Initiator agent.
     * @param agent Participant agent.
     * @param conv Related conversation.
     */
    public RestState(int sta, AID init, AID agent, Conversation conv) {
        super(sta, init, conv);
        participant = (AID) agent.clone();
    }

    /**
     * Gets the participant agent of the conversation.
     * @return Participant agent.
     */
    public AID getParticipant() {
        return participant;
    }

    /**
     * Gets the role of an agent in the conversation.
     * @param ag Requested agent.
     * @return Role of the agent.
     */
    public String getRol(AID ag) {
        if (super.getRol(ag).equals(ControlProtocol.INITIATOR))
            return ControlProtocol.INITIATOR;
        else if (ag.equals(participant))
            return ControlProtocol.PARTICIPANT;
        else
            return ControlProtocol.UNKNOWN_ROL;
    }
}