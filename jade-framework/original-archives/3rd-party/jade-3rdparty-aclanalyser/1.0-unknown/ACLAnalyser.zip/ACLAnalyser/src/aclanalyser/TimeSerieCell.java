package aclanalyser;

public class TimeSerieCell {
    private int num;
    private long date;

    public TimeSerieCell(long date, int number) {
        num = number;
        this.date = date;
    }

    public int getNumber() {
        return num;
    }

    public long getDate() {
        return date;
    }
}