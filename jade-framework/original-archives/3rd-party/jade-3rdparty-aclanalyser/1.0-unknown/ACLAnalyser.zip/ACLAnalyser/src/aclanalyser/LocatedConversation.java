package aclanalyser;

public class LocatedConversation {
    private String identifier;
    private String protocol;
    private String ontology;
    private String language;
    private String state;
    private String initiator;
    private long startDate;
    private long endDate;
    private String performStart;
    private String performEnd;

    public LocatedConversation(String id, String ini, String prot, String onto, String lang, long startDate, long endDate, String perfStart, String perfEnd, String sta) {
        identifier = id;
        protocol = prot;
        ontology = onto;
        language = lang;
        state = sta;
        initiator = ini;
        this.startDate = startDate;
        this.endDate = endDate;
        performStart = perfStart;
        performEnd = perfEnd;
    }

    public String toString() {
        return identifier;
    }

    public String getId() {
        return identifier;
    }

    public String getProtocol() {
        return protocol;
    }

    public String getOntology() {
        return ontology;
    }

    public String getLanguage() {
        return language;
    }

    public String getStat() {
        return state;
    }

    public String getInitiator() {
        return initiator;
    }

    public String getInitialPerf() {
        return performStart;
    }

    public String getFinalPerf() {
        return performEnd;
    }

    public long getInitialDate() {
        return startDate;
    }

    public long getFinalDate() {
        return endDate;
    }
}