package aclanalyser;

interface Termination {
    public void end();
}