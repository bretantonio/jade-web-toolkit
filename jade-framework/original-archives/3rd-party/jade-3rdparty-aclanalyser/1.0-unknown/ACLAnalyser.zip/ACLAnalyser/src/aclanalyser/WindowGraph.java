package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

public class WindowGraph extends JFrame implements AgentMark, Termination {
    private Graph graph;
    private DBAccess abd;
    private String session;
    private WindowGraphSchema winGraphSchema = null;
    private WindowMain main;

    private JPanel contentPane;
    private JScrollPane jPanel1;
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JLabel jLabel1 = new JLabel();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();
    private JButton jButton5 = new JButton();

    // Build the frame
    public WindowGraph(DBAccess access, WindowMain win) {
        main = win;
        abd = access;
        session = abd.getSessionName();
        graph = new Graph(access, this);
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jPanel1 = graph.showGraphMessages();
            graph.catchMouse();
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "graph.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(555, 375));
        this.setTitle("Graph of Agents - Session: " + session);
        jPanel1.setBackground(Color.white);
        jPanel1.setBounds(new Rectangle(16, 13, 387, 311));

        jButton1.setBounds(new Rectangle(420, 33, 119, 32));
        jButton1.setText("Arrange");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(420, 114, 119, 32));
        jButton2.setText("Refresh");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jLabel1.setText("Change size");
        jLabel1.setBounds(new Rectangle(434, 181, 85, 18));
        jButton3.setBounds(new Rectangle(422, 213, 48, 22));
        jButton3.setFont(new java.awt.Font("Dialog", 0, 15));
        jButton3.setText("+");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton4.setText("-");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jButton4.setBounds(new Rectangle(473, 213, 48, 22));
        jButton4.setFont(new java.awt.Font("Dialog", 0, 15));

        jButton5.setText("Show schema");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton5_actionPerformed(e);
            }
        });
        jButton5.setBounds(new Rectangle(420, 283, 119, 32));

        contentPane.add(jPanel1, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
        contentPane.add(jButton3, null);
        contentPane.add(jButton4, null);
        contentPane.add(jButton5, null);
        contentPane.add(jLabel1, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    synchronized void jButton1_actionPerformed(ActionEvent e) {
        graph.sort();
    }

    synchronized void jButton2_actionPerformed(ActionEvent e) {
        // if it's the current session
        String ses = abd.getSessionName();
        if (ses.equals(session))
            graph.refresh();
    }

    public synchronized void agentMarked(String agent) {
        // if it's the current session
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            WindowInfAgent frame = new WindowInfAgent(agent, abd, main);
            // Validate frames with preset sizes.
            // Pack frames with important size information. For instance, about its design.
            frame.validate();

            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
            frame.setVisible(true);

            main.setWindowSession(frame);
        }
    }

    synchronized void jButton3_actionPerformed(ActionEvent e) {
        graph.moreSize();
    }

    synchronized void jButton4_actionPerformed(ActionEvent e) {
        graph.lessSize();
    }

    synchronized void jButton5_actionPerformed(ActionEvent e) {
        // if the current session
        String ses = abd.getSessionName();
        if ((ses.equals(session)) && (abd.getMatrix() != null)) {
            Rock rock = new Rock(abd);
            rock.algorithm();
            LinkedList[] groups = rock.getGroups();
            graph.colour(groups);
            graph.sort();

            if (winGraphSchema != null)
                winGraphSchema.end();

            winGraphSchema = new WindowGraphSchema(abd, groups, session);
            // Validate frames with preset sizes.
            // Pack frames with important size information. For instance, about its design.
            winGraphSchema.validate();

            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = winGraphSchema.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            winGraphSchema.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
            winGraphSchema.setVisible(true);

            main.setPersistentWindow(winGraphSchema);
        }
    }

    public synchronized void refresh() {
        // if it's the current session
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            graph.refresh();
            graph.sort();
        }
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}