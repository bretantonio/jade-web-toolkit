package aclanalyser;

import jade.core.AID;

public class Agent {

    public static int i = 0;
    public static final int hRet = 30;
    public static final int bRet = 50;
    public static final int yRet = 20;
    public String agentName;
    private AID myAID;

    public boolean onCanv;

    public Agent(String localName) {
        myAID = new AID(localName, AID.ISLOCALNAME);
        agentName = localName;
        onCanv = true;
    }

    public boolean equals(Object o) {

        if (o instanceof Agent) {
            Agent ag = (Agent) o;
            return agentName.equalsIgnoreCase(ag.agentName);
        } else {
            return myAID.equals(o);
        }
    }

}