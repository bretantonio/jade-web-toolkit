package aclanalyser;

import java.io.*;

/**
 * This class represents the basis of a protocol, as a protocol is composed of many
 * instances of this class. It shows the behaviour of the protocol for a particular
 * situation. It shows how the state changes depending on the received message and on
 * who is sending and receiving it.
 */
public class ProtocolCell implements Serializable {
    private int initialState;
    private String performative;
    private String rolSender;
    private String rolReceiver;
    private int nextState;

    /**
     * Creates a new instance of ProtcolCell, providing all its fields.
     * @param initSta Initial state.
     * @param perf Performative of the message.
     * @param role1 Message sender role.
     * @param role2 Message receiver role.
     * @param sta Final state.
     */
    public ProtocolCell(int initSta, String perf, String role1, String role2, int sta) {
        initialState = initSta;
        performative = perf;
        rolSender = role1;
        rolReceiver = role2;
        nextState = sta;
    }

    /**
     * Returns a string representation of ProtocolCell.
     * @return A description of the cell.
     */
    public String toString() {
        return "Performative " + performative + " SendRole " + rolSender + " ReceivRole " + rolReceiver + " FinalSta " + nextState;
    }

    /**
     * Returns the initial state of the cell.
     * @return Initial state.
     */
    public int getInitialState() {
        return initialState;
    }

    /**
     * Returns the sender role of the cell.
     * @return Sender role.
     */
    public String getRolSender() {
        return rolSender;
    }

    /**
     * Returns the receiver role of the cell.
     * @return Receiver role.
     */
    public String getRolReceiver() {
        return rolReceiver;
    }

    /**
     * Returns the performative of the cell.
     * @return Performative.
     */
    public String getPerform() {
        return performative;
    }

    /**
     * Returns the final state of the cell.
     * @return Final state.
     */
    public int getState() {
        return nextState;
    }
}