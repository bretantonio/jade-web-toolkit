package aclanalyser;

public class MessageStats {
    private int numMessages = 0;
    private int numOKMessages = 0;
    private int numErrorMessages = 0;
    private int numLateMessages = 0;
    private int proposal = 0;
    private int rejectProposal = 0;
    private int acceptProposal = 0;
    private int error = 0;
    private int information = 0;
    private int propagateMessages = 0;

    public int getNumMessages() {
        return numMessages;
    }

    public int getNumOKMessages() {
        return numOKMessages;
    }

    public int getNumErrorMessages() {
        return numErrorMessages;
    }

    public int getNumLateMessages() {
        return numLateMessages;
    }

    public int getProposal() {
        return proposal;
    }

    public int getRejectProposal() {
        return rejectProposal;
    }

    public int getAcceptProposal() {
        return acceptProposal;
    }

    public int getError() {
        return error;
    }

    public int getInformation() {
        return information;
    }

    public int getPropagateMessages() {
        return propagateMessages;
    }

    public int getRest() {
        return (numMessages - proposal - acceptProposal - rejectProposal - propagateMessages - error - information);
    }

    public void setNumMessages(int aux) {
        numMessages = aux;
    }

    public void setNumOKMessages(int aux) {
        numOKMessages = aux;
    }

    public void setNumErrorMessages(int aux) {
        numErrorMessages = aux;
    }

    public void setNumLateMessages(int aux) {
        numLateMessages = aux;
    }

    public void setQueryRef(int aux) {
        proposal = aux;
    }

    public void setAcceptProposal(int aux) {
        acceptProposal = aux;
    }

    public void setRejectProposal(int aux) {
        rejectProposal = aux;
    }

    public void setError(int aux) {
        error = aux;
    }

    public void setInformation(int aux) {
        information = aux;
    }

    public void setPropagate(int aux) {
        propagateMessages = aux;
    }

}