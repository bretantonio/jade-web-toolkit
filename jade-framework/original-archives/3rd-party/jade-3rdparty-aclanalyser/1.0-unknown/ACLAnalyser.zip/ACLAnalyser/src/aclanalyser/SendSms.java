package aclanalyser;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;

public class SendSms extends Agent {

    private int conv = 0;
    private int max_conv = 4000;

    protected void setup() {
        try {
            Thread.sleep(2400);
        } catch (Exception e) {
        }
        addBehaviour(new Send());
    }

    private class Send extends SimpleBehaviour {

        public void action() {
            // send a message to its neighbors with the fact 'send'
            ACLMessage message = new ACLMessage(ACLMessage.REQUEST);
            AID receiv = new AID("da0@myComputer:1099/JADE", false);

            message.addReceiver(receiv);
            message.setProtocol("fipa-request");
            message.setLanguage("l1");
            message.setOntology("o1");
            message.setConversationId(getLocalName() + "-" + (conv++));

            send(message);
        }

        public boolean done() {
            if (conv == max_conv)
                return true;
            else
                return false;
        }
    }
}