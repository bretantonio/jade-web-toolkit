package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedList;
import java.util.Vector;
import javax.swing.table.*;
import java.io.*;

public class WindowStatistics extends JFrame implements Termination {
    private ControlProtocol cp;
    private DBAccess abd;
    private ConversationStats cs;
    private MessageStats ms;
    private String session;
    private PieChart windowChartPerfor = null;
    private PieChart windowChartProtocol = null;
    private TimeSerie timeSerie = null;

    private JPanel contentPane;
    private JTabbedPane jTabbedPane1 = new JTabbedPane();
    private JPanel conversation = new JPanel();
    private JPanel message = new JPanel();
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JLabel jLabel20 = new JLabel();
    private JLabel jLabel21 = new JLabel();
    private JLabel jLabel22 = new JLabel();
    private JLabel jLabel23 = new JLabel();
    private JLabel jLabel24 = new JLabel();
    private JLabel jLabel25 = new JLabel();
    private JLabel jLabel26 = new JLabel();
    private JLabel jLabel27 = new JLabel();
    private JLabel jLabel28 = new JLabel();
    private JButton jButton3 = new JButton();
    private JLabel jLabel29 = new JLabel();
    private JLabel jLabel210 = new JLabel();
    private JLabel jLabel211 = new JLabel();
    private JLabel jLabel212 = new JLabel();
    private JLabel jLabel213 = new JLabel();
    private JLabel jLabel214 = new JLabel();
    private JLabel jLabel215 = new JLabel();
    private JLabel jLabel216 = new JLabel();
    private JLabel jLabel217 = new JLabel();
    private JLabel jLabel218 = new JLabel();
    private JLabel jLabel219 = new JLabel();
    private JLabel jLabel2110 = new JLabel();
    private JButton jButton4 = new JButton();
    private JTable jTable1;
    private DefaultTableModel model;
    private JScrollPane jScrollPane1;

    // Build the frame
    public WindowStatistics(ControlProtocol control, DBAccess access) {
        cp = control;
        abd = access;
        LinkedList list = cp.getNameProt();
        cs = abd.getConversationStats(list);
        ms = abd.getMessageStats();

        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            fill();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "cheese.gif"));
        session = abd.getSessionName();
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(594, 360));
        this.setTitle("General statistics - Session " + session);
        jTabbedPane1.setBounds(new Rectangle(9, 11, 423, 300));
        jLabel1.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel1.setText("N# conversations:");
        jLabel1.setBounds(new Rectangle(37, 11, 117, 17));
        conversation.setLayout(null);
        jLabel2.setBounds(new Rectangle(37, 27, 166, 17));
        jLabel2.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2.setText("N# successful conversations:");
        jLabel3.setBounds(new Rectangle(37, 43, 182, 17));
        jLabel3.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel3.setText("N# unsuccessful conversations:");
        jLabel4.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel4.setText("");
        jLabel4.setBounds(new Rectangle(233, 11, 32, 14));
        jLabel5.setBounds(new Rectangle(233, 27, 32, 14));
        jLabel5.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel5.setText("");
        jLabel6.setBounds(new Rectangle(233, 43, 32, 14));
        jLabel6.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel6.setText("");
        jLabel7.setText("Distribution by protocol");
        jLabel7.setBounds(new Rectangle(33, 75, 165, 16));

        jButton1.setBounds(new Rectangle(271, 231, 106, 28));
        jButton1.setText("Show chart");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });

        jButton2.setBounds(new Rectangle(457, 113, 104, 27));
        jButton2.setText("Refresh");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        message.setLayout(null);
        jLabel20.setBounds(new Rectangle(37, 11, 117, 17));
        jLabel20.setText("N# messages:");
        jLabel20.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel21.setBounds(new Rectangle(37, 27, 117, 17));
        jLabel21.setText("N# right messages:");
        jLabel21.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel22.setBounds(new Rectangle(37, 43, 117, 17));
        jLabel22.setText("N# wrong messages:");
        jLabel22.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel23.setBounds(new Rectangle(37, 59, 117, 17));
        jLabel23.setText("N# late messages:");
        jLabel23.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel24.setBounds(new Rectangle(233, 11, 32, 14));
        jLabel24.setText("");
        jLabel24.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel25.setBounds(new Rectangle(233, 27, 32, 14));
        jLabel25.setText("");
        jLabel25.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel26.setBounds(new Rectangle(233, 43, 32, 14));
        jLabel26.setText("");
        jLabel26.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel27.setBounds(new Rectangle(233, 59, 32, 14));
        jLabel27.setText("");
        jLabel27.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel28.setBounds(new Rectangle(34, 90, 283, 16));
        jLabel28.setText("Distribution by performative (grouped by purpose)");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton3.setText("Show chart");
        jButton3.setBounds(new Rectangle(254, 231, 132, 28));
        jLabel29.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel29.setText("Type Petition:");
        jLabel29.setBounds(new Rectangle(38, 115, 119, 18));
        jLabel210.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel210.setText("Type Reject Petition:");
        jLabel210.setBounds(new Rectangle(38, 135, 117, 17));
        jLabel211.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel211.setText("Type Accept Petition:");
        jLabel211.setBounds(new Rectangle(38, 155, 112, 17));
        jLabel212.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel212.setText("Type Information:");
        jLabel212.setBounds(new Rectangle(38, 175, 117, 17));
        jLabel213.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel213.setText("Type Error:");
        jLabel213.setBounds(new Rectangle(38, 195, 117, 17));
        jLabel214.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel214.setText("Type Sending Message:");
        jLabel214.setBounds(new Rectangle(38, 215, 125, 17));
        jLabel215.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel215.setText("");
        jLabel215.setBounds(new Rectangle(194, 115, 32, 14));
        jLabel216.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel216.setText("");
        jLabel216.setBounds(new Rectangle(194, 135, 32, 14));
        jLabel217.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel217.setText("");
        jLabel217.setBounds(new Rectangle(194, 155, 32, 14));
        jLabel218.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel218.setText("");
        jLabel218.setBounds(new Rectangle(194, 175, 32, 14));
        jLabel219.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel219.setText("");
        jLabel219.setBounds(new Rectangle(194, 195, 32, 14));
        jLabel2110.setFont(new java.awt.Font("Dialog", 0, 11));
        jLabel2110.setText("");
        jLabel2110.setBounds(new Rectangle(194, 215, 32, 14));
        contentPane.add(jTabbedPane1, null);
        jTabbedPane1.add(conversation, "Conversation");
        jButton4.setBounds(new Rectangle(254, 191, 132, 28));
        jButton4.setText("Show time serie");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });

        Vector vector = new Vector();
        vector.add("Protocol");
        vector.add("N# Conversations");

        model = new DefaultTableModel(vector, 0);
        jTable1 = new JTable(model);

        jTable1.setBounds(new Rectangle(37, 107, 223, 150));
        jTable1.setSelectionMode(0);  // we only allow 1-row selection

        JTableHeader anHeader = jTable1.getTableHeader();
        anHeader.setReorderingAllowed(false);

        jScrollPane1 = new JScrollPane(jTable1);
        jScrollPane1.setBounds(new Rectangle(37, 107, 223, 150));

        conversation.add(jLabel1, null);
        conversation.add(jLabel2, null);
        conversation.add(jLabel3, null);
        conversation.add(jLabel4, null);
        conversation.add(jLabel5, null);
        conversation.add(jLabel6, null);
        conversation.add(jLabel7, null);
        conversation.add(jButton1, null);
        conversation.add(jScrollPane1, null);
        jTabbedPane1.add(message, "Message");
        message.add(jLabel24, null);
        message.add(jLabel25, null);
        message.add(jLabel26, null);
        message.add(jLabel27, null);
        message.add(jLabel23, null);
        message.add(jLabel21, null);
        message.add(jLabel22, null);
        message.add(jLabel20, null);
        message.add(jLabel28, null);
        message.add(jButton3, null);
        message.add(jLabel210, null);
        message.add(jLabel211, null);
        message.add(jLabel212, null);
        message.add(jLabel213, null);
        message.add(jLabel214, null);
        message.add(jLabel29, null);
        message.add(jLabel215, null);
        message.add(jLabel216, null);
        message.add(jLabel217, null);
        message.add(jLabel218, null);
        message.add(jLabel219, null);
        message.add(jLabel2110, null);
        message.add(jButton4, null);
        contentPane.add(jButton2, null);
    }

    private void fill() {
        // conversation
        jLabel4.setText("" + cs.getNumConv());
        jLabel5.setText("" + cs.getNumCompleteConv());
        jLabel6.setText("" + cs.getNumIncompleteConv());

        LinkedList list = cp.getNameProt();

        cleanTable();
        String prot;

        for (int i = 0; i < list.size(); i++) {
            prot = (String) list.get(i);
            Object[] data = {prot, new Integer(cs.getNumProtocol(prot))};
            model.addRow(data);
        }

        // message
        jLabel24.setText("" + ms.getNumMessages());
        jLabel25.setText("" + ms.getNumOKMessages());
        jLabel26.setText("" + ms.getNumErrorMessages());
        jLabel27.setText("" + ms.getNumLateMessages());
        jLabel215.setText("" + ms.getProposal());
        jLabel216.setText("" + ms.getRejectProposal());
        jLabel217.setText("" + ms.getAcceptProposal());
        jLabel218.setText("" + ms.getInformation());
        jLabel219.setText("" + ms.getError());
        jLabel2110.setText("" + ms.getPropagateMessages());
    }

    private void cleanTable() {
        int num = jTable1.getRowCount();
        for (int i = 0; i < num; i++)
            model.removeRow(0);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    synchronized void jButton1_actionPerformed(ActionEvent e) {
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            if (windowChartProtocol != null) windowChartProtocol.end();
            windowChartProtocol = PieChart.execute("Distribution of conversation by protocol", cs, cp.getNameProt(), session);
        }
    }

    synchronized void jButton2_actionPerformed(ActionEvent e) {
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            LinkedList list = cp.getNameProt();
            cs = abd.getConversationStats(list);
            ms = abd.getMessageStats();
            fill();
        }
    }

    synchronized void jButton3_actionPerformed(ActionEvent e) {
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            if (windowChartPerfor != null) windowChartPerfor.end();
            windowChartPerfor = PieChart.execute("Distribution by performative (grouped by purpose)", ms, null, session);
        }
    }

    synchronized void jButton4_actionPerformed(ActionEvent e) {
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            if (timeSerie != null) timeSerie.end();
            timeSerie = TimeSerie.execute(abd, session);
        }
    }

    public synchronized void refresh() {
        String ses = abd.getSessionName();
        if (ses.equals(session)) {
            jButton2_actionPerformed(null);
        }
    }

    public void end() {
        if (windowChartPerfor != null) windowChartPerfor.end();
        if (windowChartProtocol != null) windowChartProtocol.end();
        if (timeSerie != null) timeSerie.end();
        setVisible(false);
        dispose();
    }
}