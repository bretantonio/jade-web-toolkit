package aclanalyser;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

import java.util.LinkedList;

import aclanalyser.Example1;

public class SelecLeader extends Agent {

    private int identifier;
    private int maxim;
    private int conv = 0;
    private LinkedList neighbors;
    private int number;
    private AID creator;

    protected void setup() {
        try {
            Thread.sleep(35000);
        } catch (Exception ec) {
            System.out.println("Error sleeping");
        }
        neighbors = new LinkedList();
        computeNeighbors();
        Double value = new Double(Math.random() * 1000);
        identifier = value.intValue();
        // Since there are 100 agents
        identifier = identifier * 100;
        identifier = identifier + number;
        maxim = identifier;

        addBehaviour(new SendNeighborsBehaviour(identifier, null));
        addBehaviour(new ReceiveIdent());
        addBehaviour(new informLeaderBehaviour(this, Example1.WAIT));
    }

    private void computeNeighbors() {
        String name = getName();
        int pos1 = name.indexOf("--");
        int pos2 = name.indexOf("@");
        String num = name.substring(pos1 + 2, pos2);
        String part1 = name.substring(0, pos1 + 2);
        String part2 = name.substring(pos2, name.length());

        // compute the creator
        String crea = name.substring(0, pos1).concat(part2);
        creator = new AID(crea, false);

        Integer n = Integer.valueOf(num);
        number = n.intValue();

        // lineal
        if (number > 0) {
            addNeighbor(part1, part2, number - 1);
        }

        if (number < (Example1.NUM_AGENTS - 1)) {
            addNeighbor(part1, part2, number + 1);
        }

        // circular
        /*if (number>0) addNeighbor(part1,part2,number-1);
        else addNeighbor(part1,part2,Example1.NUM_AGENTS-1);

        if (number<(Example1.NUM_AGENTS-1)) addNeighbor(part1,part2,number+1);
        else addNeighbor(part1,part2,0);*/

        // make 10 groups
        /*	int elem = Example1.NUM_AGENTS/10;
            int pos_rel = number%elem;

            if (number<Example1.NUM_AGENTS-1)
                addNeighbor(part1,part2,number+1);

               if (number>0)
                   addNeighbor(part1,part2,number-1);

            // random destination inside the group
               int pos_tot = number;
               while((pos_tot==number)||(pos_tot==number-1)||(pos_tot==number+1)){
                   Double value = new Double(Math.random()*elem);
                   int dest = value.intValue();
                   pos_tot = number-pos_rel+dest;
               }
               addNeighbor(part1,part2,pos_tot);*/
    }

    private void addNeighbor(String part1, String part2, int n) {
        Integer nei = new Integer(n);
        String neighbor = part1 + nei + part2;
        neighbors.add(new AID(neighbor, false));
    }

    private class SendNeighborsBehaviour extends OneShotBehaviour {

        private int deliver;
        private AID sender;

        public SendNeighborsBehaviour(int del, AID send) {
            super();
            deliver = del;
            sender = send;
        }

        public void action() {
            // send a message to its neighbors with the fact 'deliver'
            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
            AID receiv;
            int num_receiv = 0;

            // agent 23 does it wrong
            // if (number==23) deliver = 0;

            for (int i = 0; i < neighbors.size(); i++) {
                receiv = (AID) neighbors.get(i);
                message.addReceiver(receiv);
                num_receiv++;
            }
            if (sender != null) {
                if (message.removeReceiver(sender))
                    num_receiv--;
            }

            if (num_receiv > 0) {
                message.setContent("" + deliver);
                message.setProtocol("protocol-leader");
                message.setLanguage("l1");
                message.setOntology("o1");
                message.setConversationId(getLocalName() + "-" + (conv++));

                send(message);
            }
        }
    }

    private class ReceiveIdent extends CyclicBehaviour {

        public void action() {
            ACLMessage msg = receive(MessageTemplate.MatchPerformative(ACLMessage.INFORM));
            if (msg != null) {
                String number = msg.getContent();
                int num = Integer.valueOf(number).intValue();
                if (num > maxim) {
                    maxim = num;
                    addBehaviour(new SendNeighborsBehaviour(maxim, msg.getSender()));
                }
                // deliver agreement
                try {
                    Thread.sleep(800);
                } catch (Exception ex) {
                }
                ACLMessage response = msg.createReply();
                response.setPerformative(ACLMessage.AGREE);

                send(response);

            } else // if no message has arrived, block the behaviour
                block();
        }
    }

    private class informLeaderBehaviour extends WakerBehaviour {
        // informs about selected leader and finishes the agent
        Agent agent;

        public informLeaderBehaviour(Agent a, long time) {
            super(a, time);
            agent = a;
        }

        public void handleElapsedTimeout() {
            int leader;
            int aux = maxim / 100;
            aux = aux * 100;
            leader = maxim - aux;

            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
            message.addReceiver(creator);

            message.setContent("" + leader);
            message.setProtocol("protocol-result");
            message.setLanguage("l1");
            message.setOntology("o1");
            message.setConversationId(getLocalName() + "-" + (conv++));

            send(message);
            agent.doDelete();
        }
    }

}