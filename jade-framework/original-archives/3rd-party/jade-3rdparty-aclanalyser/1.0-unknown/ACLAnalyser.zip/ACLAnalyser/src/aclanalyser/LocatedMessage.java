package aclanalyser;

import java.util.*;

public class LocatedMessage {
    private String id;
    private String date;
    private String valid;
    private String performative;
    private String encoding;
    private String sender;
    private String content;
    private String ontology;
    private String language;
    private String protocol = null;
    private long size;
    private long idMessage;
    private String late;
    private Vector receivers;

    public LocatedMessage(long idMessage, String iden, String date, String val, String perform, String encod, String sender, String cont, String onto, String lang, String proto, long size, String late) {
        this.idMessage = idMessage;
        id = iden;
        this.date = date;
        valid = val;
        performative = perform;
        encoding = encod;
        this.sender = sender;
        content = cont;
        ontology = onto;
        language = lang;
        protocol = proto;
        this.size = size;
        this.late = late;
    }

    public String toString() {
        return (id + " - " + date);
    }

    public long getIdMessage() {
        return idMessage;
    }

    public String getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getOntology() {
        return ontology;
    }

    public String getProtocol() {
        return protocol;
    }

    public String getLanguage() {
        return language;
    }

    public String getSender() {
        return sender;
    }

    public String getLate() {
        return late;
    }

    public String getEncoding() {
        return encoding;
    }

    public String getPerformative() {
        return performative;
    }

    public String getContent() {
        return content;
    }

    public String getValid() {
        return valid;
    }

    public long getSize() {
        return size;
    }

    public Vector getReceivers() {
        return receivers;
    }

    public void setReceivers(Vector aux) {
        receivers = (Vector) aux.clone();
    }
}