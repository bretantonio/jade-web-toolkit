package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class WindowIntroOnto extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();

    private WindowSearchConv window;

    // Build the frame
    public WindowIntroOnto(WindowSearchConv win) {
        window = win;
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "searchConv.gif"));
        contentPane = (JPanel) this.getContentPane();
        jLabel1.setText("Introduce ontology name:");
        jLabel1.setBounds(new Rectangle(47, 46, 194, 21));
        contentPane.setLayout(null);
        this.setSize(new Dimension(355, 194));
        this.setTitle("Introduction ontology");
        jTextField1.setBounds(new Rectangle(49, 78, 266, 24));
        jButton1.setBounds(new Rectangle(54, 140, 111, 27));
        jButton1.setText("Accept");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(197, 139, 111, 27));
        contentPane.add(jLabel1, null);
        contentPane.add(jTextField1, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    void jButton2_actionPerformed(ActionEvent e) {
        end();
    }

    void jButton1_actionPerformed(ActionEvent e) {
        String onto = jTextField1.getText();
        jTextField1.setText("");
        window.getOntology(onto);
        end();
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}