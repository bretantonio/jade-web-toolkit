package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import java.io.*;

public class WindowInfConv extends JFrame implements Termination {
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JLabel jLabel9 = new JLabel();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JButton jButton3 = new JButton();
    private JButton jButton4 = new JButton();
    private JLabel jLabel10 = new JLabel();
    private JLabel jLabel11 = new JLabel();
    private JList jList1 = new JList();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JLabel jLabel12 = new JLabel();
    private JLabel jLabel13 = new JLabel();
    private JLabel jLabel14 = new JLabel();
    private JLabel jLabel15 = new JLabel();
    private JLabel jLabel16 = new JLabel();
    private JLabel jLabel17 = new JLabel();
    private JLabel jLabel18 = new JLabel();
    private JLabel jLabel19 = new JLabel();
    private JLabel jLabel110 = new JLabel();
    private JLabel jLabel111 = new JLabel();

    private LocatedConversation lc;
    private Vector messages;
    private Vector participants;
    private WindowMessage windowMessages = null;
    private WindowDiagram windowDiagram = null;
    private DBAccess abd;
    private WindowMain main;

    // Build the frame
    public WindowInfConv(LocatedConversation conv, DBAccess access, WindowMain win) {
        main = win;
        lc = conv;
        abd = access;
        update();
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
            fill();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "searchConv.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(643, 414));
        this.setTitle("Information of conversation " + lc.getId());
        jLabel1.setText("Conversation-id:");
        jLabel1.setBounds(new Rectangle(32, 20, 110, 20));
        jLabel2.setBounds(new Rectangle(32, 50, 110, 20));
        jLabel2.setText("Protocol:");
        jLabel3.setBounds(new Rectangle(32, 80, 110, 20));
        jLabel3.setText("Language:");
        jLabel4.setBounds(new Rectangle(32, 110, 110, 20));
        jLabel4.setText("Ontology:");
        jLabel5.setBounds(new Rectangle(32, 140, 110, 20));
        jLabel5.setText("Initial date:");
        jLabel6.setBounds(new Rectangle(32, 170, 110, 20));
        jLabel6.setText("Final date:");
        jLabel7.setText("First performative:");
        jLabel7.setBounds(new Rectangle(32, 200, 110, 20));
        jLabel8.setText("Last performative:");
        jLabel8.setBounds(new Rectangle(32, 230, 110, 20));
        jLabel9.setBounds(new Rectangle(32, 260, 110, 20));
        jLabel9.setText("Result:");

        jButton1.setBounds(new Rectangle(80, 345, 146, 29));
        jButton1.setText("Show messages");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setText("Show diagram");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(250, 345, 146, 29));
        jButton3.setText("Refresh");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton3.setBounds(new Rectangle(420, 345, 146, 29));
        jButton4.setText("Show Agent");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jButton4.setBounds(new Rectangle(420, 265, 120, 29));

        jLabel10.setText("Initiator:");
        jLabel10.setBounds(new Rectangle(356, 20, 48, 20));
        jLabel11.setText("Participants:");
        jLabel11.setBounds(new Rectangle(356, 65, 89, 20));
        jList1.setBounds(new Rectangle(360, 105, 242, 150));
        jScrollPane1.setBounds(new Rectangle(360, 105, 242, 150));
        jLabel12.setText("");
        jLabel12.setBounds(new Rectangle(152, 20, 182, 20));
        jLabel13.setBounds(new Rectangle(152, 50, 182, 20));
        jLabel13.setText("");
        jLabel14.setBounds(new Rectangle(152, 80, 182, 20));
        jLabel14.setText("");
        jLabel15.setBounds(new Rectangle(152, 110, 182, 20));
        jLabel15.setText("");
        jLabel16.setBounds(new Rectangle(152, 140, 182, 20));
        jLabel16.setText("");
        jLabel17.setBounds(new Rectangle(152, 170, 182, 20));
        jLabel17.setText("");
        jLabel18.setBounds(new Rectangle(152, 200, 182, 20));
        jLabel18.setText("");
        jLabel19.setBounds(new Rectangle(152, 230, 182, 20));
        jLabel19.setText("");
        jLabel110.setBounds(new Rectangle(152, 260, 182, 20));
        jLabel110.setText("");
        jLabel111.setText("");
        jLabel111.setBounds(new Rectangle(420, 20, 188, 20));
        contentPane.add(jLabel1, null);
        contentPane.add(jLabel2, null);
        contentPane.add(jLabel3, null);
        contentPane.add(jLabel4, null);
        contentPane.add(jLabel5, null);
        contentPane.add(jLabel6, null);
        contentPane.add(jLabel7, null);
        contentPane.add(jLabel8, null);
        contentPane.add(jLabel9, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
        contentPane.add(jButton3, null);
        contentPane.add(jButton4, null);
        contentPane.add(jLabel10, null);
        contentPane.add(jLabel11, null);
        contentPane.add(jList1, null);
        contentPane.add(jScrollPane1, null);
        contentPane.add(jLabel12, null);
        contentPane.add(jLabel13, null);
        contentPane.add(jLabel14, null);
        contentPane.add(jLabel15, null);
        contentPane.add(jLabel16, null);
        contentPane.add(jLabel17, null);
        contentPane.add(jLabel18, null);
        contentPane.add(jLabel19, null);
        contentPane.add(jLabel110, null);
        contentPane.add(jLabel111, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private void update() {
        messages = abd.searchMessagesConv(lc.getId());
        participants = abd.searchParticipants(lc.getId());
    }

    private void fill() {
        jLabel12.setText(lc.getId());
        jLabel13.setText(lc.getProtocol());
        jLabel14.setText(lc.getLanguage());
        jLabel15.setText(lc.getOntology());
        jLabel16.setText("" + new java.util.Date(lc.getInitialDate()).toString());
        jLabel17.setText("" + new java.util.Date(lc.getFinalDate()).toString());
        jLabel18.setText(lc.getInitialPerf());
        jLabel19.setText(lc.getFinalPerf());
        String res = lc.getStat();
        if (res.equals("T"))
            jLabel110.setText("Successful");
        else
            jLabel110.setText("Unsuccessful");
        jLabel111.setText(lc.getInitiator());
        jList1.setListData(participants);
        jScrollPane1.getViewport().setView(jList1);
    }

    void jButton2_actionPerformed(ActionEvent e) {
        update();
        if (windowDiagram != null) windowDiagram.end();

        windowDiagram = new WindowDiagram(participants, messages, lc.getId());
        windowDiagram.validate();
        // Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = windowDiagram.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        windowDiagram.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        windowDiagram.setVisible(true);

    }

    void jButton1_actionPerformed(ActionEvent e) {
        update();
        if (windowMessages == null) {
            windowMessages = new WindowMessage(main);
            windowMessages.validate();
            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = windowMessages.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            windowMessages.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        }
        windowMessages.fill(messages);
        windowMessages.setVisible(true);
    }

    void jButton3_actionPerformed(ActionEvent e) {
        SearchConversation sc = new SearchConversation();
        sc.setIdentifier(lc.getId());
        Vector aux = abd.searchConversation(sc);
        lc = (LocatedConversation) aux.get(0);
        update();
        fill();
    }

    void jButton4_actionPerformed(ActionEvent e) {
        // pick agent from the list
        Object obj = jList1.getSelectedValue();
        if ((obj != null) && (obj instanceof String)) {
            String agent = (String) obj;

            WindowInfAgent frame = new WindowInfAgent(agent, abd, main);
            // Validate frames with preset sizes.
            // Pack frames with important size information. For instance about its design.
            frame.validate();

            // Center the window
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = frame.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
            frame.setVisible(true);

            main.setWindowSession(frame);
        }
    }

    public void end() {
        if (windowMessages != null) windowMessages.end();
        if (windowDiagram != null) windowDiagram.end();
        setVisible(false);
        dispose();
    }
}