package aclanalyser;

import jade.core.*;

/**
 * Sets a timeout for any conversation (or participant in the conversation)
 * in order to force its ending.
 */
public class Alarm extends Thread {

    private long time;
    private State obj;
    private AID agent;

    /**
     * Sets an Alarm by initializing all its fields.
     * @param time Duration of the alarm.
     * @param object State to be notified on expiration.
     * @param ag Relate agent.
     */
    public Alarm(long time, State object, AID ag) {
        super();
        this.time = time;
        obj = object;
        if (ag != null) agent = (AID) ag.clone();
    }

    /**
     * Removes all the alarm's references, in order to be able to destroy it.
     */
    public void clean() {
        obj = null;
        agent = null;
    }

    /**
     * Runs the alarm.
     */
    public void run() {
        try {
            sleep(time);
            if (obj != null) {
                obj.waitBlocking();
                obj.notification(agent);
            } else
                return;
        } catch (InterruptedException ie) {
            System.err.println("Alarm stopped");
        }
    }
}