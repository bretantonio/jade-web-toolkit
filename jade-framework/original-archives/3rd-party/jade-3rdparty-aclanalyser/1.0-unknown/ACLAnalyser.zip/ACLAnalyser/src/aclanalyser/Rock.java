package aclanalyser;

import java.util.*;

public class Rock {
    static double K = 0.6;
    static double bound = 0.08;

    private DBAccess abd;
    private int[][] link;
    private LinkedList agents = new LinkedList();
    private int num_agents;
    LinkedList clusters = new LinkedList();

    public Rock(DBAccess access) {
        abd = access;
    }

    private void compute_links() {
        Matrix matrix = abd.getMatrix();
        num_agents = matrix.getNumAgents();
        LinkedList[] neighbors = new LinkedList[num_agents];

        for (int i = 0; i < num_agents; i++)
            agents.add(matrix.getAgent(i));

        // get lists of neighbors
        for (int i = 0; i < num_agents; i++) {
            neighbors[i] = new LinkedList();
            for (int j = 0; j < num_agents; j++) {
                if (matrix.getMesssage(i, j) + matrix.getMesssage(j, i) > 0)
                    neighbors[i].add(new Integer(j));
            }
        }

        link = new int[num_agents][num_agents];
        Integer aux1,aux2;

        for (int k = 0; k < num_agents; k++) {
            for (int i = 0; i < neighbors[k].size() - 1; i++) {
                for (int j = i + 1; j < neighbors[k].size(); j++) {
                    aux1 = (Integer) neighbors[k].get(i);
                    aux2 = (Integer) neighbors[k].get(j);
                    link[aux1.intValue()][aux2.intValue()] = link[aux1.intValue()][aux2.intValue()] + 1;
                }
            }
        }
    }

    public void algorithm() {
        compute_links();

        for (int i = 0; i < num_agents; i++) {
            Cluster c = new Cluster(i);
            add(c);
        }
        for (int i = 0; i < clusters.size(); i++) {
            Cluster auxi = (Cluster) clusters.get(clusters.size() - 1);
            auxi.initialize();
            add(auxi);
            clusters.removeLast();
        }

        while ((clusters.size() > 1) && (!end())) {
            Cluster first = (Cluster) clusters.removeFirst();
            Cluster second = getCluster(first.getMaxCluster());
            del(second);
            Cluster mix = first.medge(second);
            add(mix);

            LinkedList firstList = first.getClust();
            LinkedList secondList = second.getClust();

            ClusterCell cell;
            for (int i = 0; i < firstList.size(); i++) {
                cell = (ClusterCell) firstList.get(i);
                if (!belongs(cell.getId(), mix)) {
                    Cluster aux = getCluster(cell.getId());
                    aux.remove(mix.getList());
                    aux.add(new ClusterCell(goodness(aux.getId(), mix.getId()), mix.getId()));
                    mix.add(new ClusterCell(goodness(mix.getId(), aux.getId()), aux.getId()));
                }
            }

            for (int i = 0; i < secondList.size(); i++) {
                cell = (ClusterCell) secondList.get(i);
                if ((!belongs(cell.getId(), mix)) && (!clusterBelongs(cell.getId(), mix))) {
                    Cluster aux = getCluster(cell.getId());
                    aux.remove(mix.getList());
                    aux.add(new ClusterCell(goodness(aux.getId(), mix.getId()), mix.getId()));
                    mix.add(new ClusterCell(goodness(mix.getId(), aux.getId()), aux.getId()));
                }
            }

            Collections.sort(clusters);
        }
    }

    private boolean end() {
        Cluster cl = (Cluster) clusters.get(0);
        if (cl.getValue() < bound)
            return true;
        else
            return false;
    }

    private boolean belongs(int i, Cluster cl) {
        LinkedList lis = cl.getList();
        for (int j = 0; j < lis.size(); j++) {
            Integer integ = (Integer) lis.get(j);
            if (integ.intValue() == i) return true;
        }
        return false;
    }

    private boolean clusterBelongs(int n, Cluster cl) {
        LinkedList lis = cl.getClust();
        for (int i = 0; i < lis.size(); i++) {
            ClusterCell cc = (ClusterCell) lis.get(i);
            if (cc.getId() == n) return true;
        }
        return false;
    }

    private void print_clusters() {
        for (int i = 0; i < clusters.size(); i++) {
            Cluster aux = (Cluster) clusters.get(i);
            System.out.println(aux);
        }
    }

    private void add(Cluster c) {
        double value = c.getValue();

        Cluster cl;
        int i;
        for (i = 0; i < clusters.size(); i++) {
            cl = (Cluster) clusters.get(i);
            if (value >= cl.getValue()) break;
        }
        clusters.add(i, c);
    }

    private void del(Cluster c) {
        Cluster cl;

        for (int i = 0; i < clusters.size(); i++) {
            cl = (Cluster) clusters.get(i);
            if (cl.getId() == c.getId()) {
                clusters.remove(i);
                break;
            }
        }
    }

    private double goodness(int n1, int n2) {
        Cluster cl1 = getCluster(n1);
        Cluster cl2 = getCluster(n2);

        // get links between them
        int links = 0;
        LinkedList list1 = cl1.getList();
        LinkedList list2 = cl2.getList();
        Integer aux1,aux2;

        for (int i = 0; i < list1.size(); i++) {
            aux1 = (Integer) list1.get(i);
            for (int j = 0; j < list2.size(); j++) {
                aux2 = (Integer) list2.get(j);
                links = links + link[aux1.intValue()][aux2.intValue()] + link[aux2.intValue()][aux1.intValue()];
            }
        }

        double den = getDenominator(list1.size(), list2.size());

        return (links / den);
    }

    private double getDenominator(int n1, int n2) {
        return Math.pow(n1 + n2, 1 + 2 * K) - Math.pow(n1, 1 + 2 * K) - Math.pow(n2, 1 + 2 * K);
    }

    private Cluster getCluster(int n) {
        Cluster cl;
        for (int i = 0; i < clusters.size(); i++) {
            cl = (Cluster) clusters.get(i);
            if (cl.getId() == n) return cl;
        }
        return null;
    }

    public LinkedList[] getGroups() {
        LinkedList[] groups = new LinkedList[clusters.size()];

        for (int i = 0; i < clusters.size(); i++) {
            groups[i] = new LinkedList();
            Cluster cl = (Cluster) clusters.get(i);
            LinkedList list = cl.getList();
            for (int j = 0; j < list.size(); j++) {
                Integer integ = (Integer) list.get(j);
                groups[i].add(agents.get(integ.intValue()));
            }
        }

        return groups;
    }

    private class Cluster implements Comparable {

        private LinkedList list;
        private LinkedList clusters;
        private int id;

        public Cluster(int i) {
            id = i;
            list = new LinkedList();
            clusters = new LinkedList();
            list.add(new Integer(id));
        }

        public int compareTo(Object o) {
            Cluster aux = (Cluster) o;
            if (getValue() > aux.getValue())
                return -1;
            else if (getValue() < aux.getValue())
                return 1;
            else
                return 0;
        }

        public void initialize() {
            for (int j = 0; j < num_agents; j++) {
                if (link[id][j] + link[j][id] > 0) add(new ClusterCell(goodness(id, j), j));
            }
        }

        private void add(ClusterCell cell) {
            ClusterCell ccell;
            int i;
            for (i = 0; i < clusters.size(); i++) {
                ccell = (ClusterCell) clusters.get(i);
                if (ccell.getVal() <= cell.getVal())
                    break;
            }
            clusters.add(i, cell);
        }

        public void remove(LinkedList lis) {
            ClusterCell ccell;
            for (int j = 0; j < lis.size(); j++) {
                Integer integ = (Integer) lis.get(j);
                int n = integ.intValue();
                for (int i = 0; i < clusters.size(); i++) {
                    ccell = (ClusterCell) clusters.get(i);
                    if (ccell.getId() == n)
                        clusters.remove(i);
                }
            }
        }

        public int getId() {
            return id;
        }

        public LinkedList getList() {
            return (LinkedList) list.clone();
        }

        public LinkedList getClust() {
            return (LinkedList) clusters.clone();
        }

        public double getValue() {
            if ((clusters == null) || (clusters.size() == 0))
                return 0;
            else {
                ClusterCell cell = (ClusterCell) clusters.get(0);
                return cell.getVal();
            }
        }

        public int getMaxCluster() {
            ClusterCell cc = (ClusterCell) clusters.get(0);
            return cc.getId();
        }

        public void setList(LinkedList l) {
            list = l;
        }

        public void setClusters(LinkedList l) {
            clusters = l;
        }

        public Cluster medge(Cluster c) {
            Cluster newer = new Cluster(id);

            LinkedList lis = new LinkedList();
            for (int i = 0; i < list.size(); i++)
                lis.add(list.get(i));
            LinkedList lis2 = c.getList();
            for (int i = 0; i < lis2.size(); i++)
                lis.add(lis2.get(i));

            newer.setList(lis);

            return newer;
        }

        public String toString() {
            String st;
            st = "Cluster: " + id + " with value: " + getValue() + " and next: ";
            for (int i = 0; i < clusters.size(); i++) {
                ClusterCell cell = (ClusterCell) clusters.get(i);
                st = st + " " + cell.getId() + " ";
            }
            st = st + " and values " + list;

            return st;
        }
    }

    private class ClusterCell {
        private double value;
        private int id;

        public ClusterCell(double val, int iden) {
            value = val;
            id = iden;
        }

        public double getVal() {
            return value;
        }

        public int getId() {
            return id;
        }
    }

}