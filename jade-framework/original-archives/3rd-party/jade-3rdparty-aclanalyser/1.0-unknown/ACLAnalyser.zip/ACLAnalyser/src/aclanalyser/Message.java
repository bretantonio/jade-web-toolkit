package aclanalyser;

import java.util.LinkedList;

import jade.core.AID;

public class Message extends jade.lang.acl.ACLMessage {

    private int x1,x2,y;

    public static final int step = 80;
    public static final int offset = 45;
    public static final int r = 8;
    private int messageNumber = 0;
    private String perform;
    private int type;

    public Message(String source, LinkedList destination, String performative, int type) {
        super();
        // performative
        perform = performative;
        // whether it's correct or not
        this.type = type;
        // source
        this.setSender(new AID(source, AID.ISLOCALNAME));
        // destinations
        String dest;
        AID aux;
        for (int i = 0; i < destination.size(); i++) {
            dest = (String) destination.get(i);
            aux = new AID(dest, AID.ISLOCALNAME);
            this.addReceiver(aux);
        }
        this.setContent(null);
        this.setReplyWith(null);
        this.setInReplyTo(null);
        this.setLanguage(null);
        this.setOntology(null);
        this.setReplyByDate(null);
        this.setProtocol(null);
        this.setConversationId("c1");
        this.setEnvelope(null);
    }

    public int getInitSec(int xS) {
        x1 = xS * step + offset + 4;
        return x1;
    }

    public int getEndSec(int xD) {
        x2 = xD * step + offset;
        return x2;
    }

    public int getOrdSec(int yDim) {
        y = (yDim * 20) + step - 50;
        return y;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public void setMessageNumber(int n) {
        messageNumber = n;
    }

    public String getPerform() {
        return perform;
    }

    public int getType() {
        return type;
    }
}
