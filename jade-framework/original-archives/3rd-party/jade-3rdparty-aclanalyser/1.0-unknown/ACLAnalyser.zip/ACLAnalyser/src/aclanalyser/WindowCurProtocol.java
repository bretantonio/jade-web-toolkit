package aclanalyser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import java.io.*;
import java.io.*;

public class WindowCurProtocol extends JFrame implements Termination {
    private ControlProtocol control;
    private WindowProtocol win;
    private JFileChooser jFileChooser1;
    private Vector protocols;
    private JPanel contentPane;
    private JList jList1;
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JButton jButton3 = new JButton();

    // Build the frame
    public WindowCurProtocol(ControlProtocol cp, JFileChooser jfc, WindowProtocol w) {
        win = w;
        control = cp;
        jFileChooser1 = jfc;
        fill();
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialization of components
    private void jbInit() throws Exception {
        setIconImage(Toolkit.getDefaultToolkit().createImage("images" + File.separator + "tie.gif"));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(null);
        this.setSize(new Dimension(310, 355));
        this.setTitle("Active Protocols");
        jList1.setBounds(new Rectangle(37, 32, 236, 230));
        jScrollPane1.setBounds(new Rectangle(37, 32, 236, 230));
        jButton1.setBounds(new Rectangle(116, 290, 81, 25));
        jButton1.setText("Remove");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton2_actionPerformed(e);
            }
        });
        jButton2.setBounds(new Rectangle(38, 290, 72, 25));
        jButton3.setBounds(new Rectangle(203, 290, 72, 25));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jButton3.setText("Show");
        contentPane.add(jList1, null);
        contentPane.add(jScrollPane1, null);
        contentPane.add(jButton1, null);
        contentPane.add(jButton2, null);
        contentPane.add(jButton3, null);
    }

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            end();
        }
    }

    private void fill() {
        protocols = control.getListProt();
        jList1 = new JList(protocols);
        jScrollPane1.getViewport().setView(jList1);
    }

    void jButton1_actionPerformed(ActionEvent e) {
        int num = jList1.getSelectedIndex();
        if ((num != -1) && (control.delProtocol((Protocol) jList1.getSelectedValue()))) {
            protocols.removeElementAt(num);
            jList1.setListData(protocols);
            jScrollPane1.getViewport().setView(jList1);
        }

    }

    void jButton2_actionPerformed(ActionEvent e) {
        int a = jFileChooser1.showOpenDialog(this);
        if (a == JFileChooser.APPROVE_OPTION) {
            File file = jFileChooser1.getSelectedFile();
            if ((file.isFile()) && (jFileChooser1.getFileFilter().accept(file))) {
                // Open file
                Protocol prot = Protocol.loadProtocol(file.toString());

                control.addProtocol(prot);
                protocols.add(prot);
                jList1.setListData(protocols);
                jScrollPane1.getViewport().setView(jList1);
            }
        }
    }

    void jButton3_actionPerformed(ActionEvent e) {
        if (!jList1.isSelectionEmpty())
            win.show((Protocol) jList1.getSelectedValue());
    }

    public void end() {
        setVisible(false);
        dispose();
    }
}